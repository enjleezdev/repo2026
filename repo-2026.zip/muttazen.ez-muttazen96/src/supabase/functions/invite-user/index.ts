
// /supabase/functions/invite-user/index.ts
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient, SupabaseClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
};

// Main function to handle requests
serve(async (req: Request) => {
  // ✅ Handle CORS preflight request
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    // ✅ Parse body safely
    let body;
    try {
      body = await req.json();
    } catch (e) {
      console.error('Failed to parse request body as JSON:', e);
      return new Response(
        JSON.stringify({ error: 'Invalid or missing JSON in request body.' }),
        { status: 400, headers: corsHeaders }
      );
    }

    const { email, role, organization_id } = body;

    if (!email || !role || !organization_id) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: email, role, or organization_id.' }),
        { status: 400, headers: corsHeaders }
      );
    }

    // ✅ Read environment variables
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!supabaseUrl || !serviceRoleKey) {
      throw new Error('Server configuration error: Missing Supabase URL or Service Role Key.');
    }

    // ✅ Create Supabase Admin client
    const supabaseAdmin: SupabaseClient = createClient(
      supabaseUrl,
      serviceRoleKey,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );
    
    // As per the user's correct diagnosis, the redirectTo should point to the client-side page
    // which can handle the URL fragment (#).
    const redirectTo = 'https://ezinv4.netlify.app/update-password';


    const { data, error: inviteError } = await supabaseAdmin.auth.admin.inviteUserByEmail(
      email,
      { 
        data: { role, organization_id },
        redirectTo: redirectTo
      }
    );

    if (inviteError) {
      if (inviteError.message.includes('User already registered')) {
        return new Response(JSON.stringify({ error: 'This user is already registered in the system.' }), {
          status: 409,
          headers: corsHeaders,
        });
      }
      throw inviteError;
    }

    if (!data.user) {
      throw new Error("Invitation may have been sent, but no user data was returned from the service.");
    }

    // ✅ Success
    return new Response(
      JSON.stringify({ message: `Invitation sent successfully to ${email}.` }),
      { status: 200, headers: corsHeaders }
    );

  } catch (err: unknown) {
    const error = err instanceof Error ? err : new Error(String(err));
    console.error('Error in invite-user function:', error.message);

    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: corsHeaders }
    );
  }
});
