
import { config } from 'dotenv';
config();

import '@/ai/flows/stock-level-suggestions.ts';
import '@/ai/flows/demand-forecasting.ts';
import '@/ai/flows/dashboard-insights.ts';
