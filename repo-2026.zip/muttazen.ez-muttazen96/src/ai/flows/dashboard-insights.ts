// src/ai/flows/dashboard-insights.ts
'use server';
/**
 * @fileOverview An AI agent that analyzes the overall inventory state and provides actionable insights for the dashboard.
 *
 * - dashboardInsights - A function that generates high-level insights.
 * - DashboardInsightsInput - The input type for the dashboardInsights function.
 * - DashboardInsightsOutput - The return type for the dashboardInsights function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'zod';

const DashboardInsightsInputSchema = z.object({
  inventorySummary: z.string().describe('A JSON string representing a summary of all warehouses, items, quantities, and recent transaction history.'),
});
export type DashboardInsightsInput = z.infer<typeof DashboardInsightsInputSchema>;

const DashboardInsightSchema = z.object({
    insightId: z.string().describe('A unique, URL-friendly ID for the insight (e.g., "stockout-risk-cement", "cost-saving-opportunity-wires").'),
    title: z.object({
        en: z.string().describe('A short, descriptive title for the insight in English (e.g., "Stockout Prediction").'),
        ar: z.string().describe('A short, descriptive title for the insight in Arabic (e.g., "توقع نفاد المخزون").'),
    }),
    description: z.object({
        en: z.string().describe('A concise, one-sentence explanation of the insight in English.'),
        ar: z.string().describe('A concise, one-sentence explanation of the insight in Arabic.'),
    }),
    details: z.object({
        en: z.string().describe('A detailed, multi-sentence analytical paragraph in English explaining the reasoning, the data points considered, and the suggested course of action.'),
        ar: z.string().describe('A detailed, multi-sentence analytical paragraph in Arabic explaining the reasoning, the data points considered, and the suggested course of action.'),
    }),
    priority: z.enum(['high', 'medium', 'low']).describe('The priority of the insight, which will determine its presentation (e.g., color). "high" for urgent issues, "medium" for important but not critical, "low" for informational.'),
});
export type DashboardInsight = z.infer<typeof DashboardInsightSchema>;

const DashboardInsightsOutputSchema = z.object({
  insights: z.array(DashboardInsightSchema).length(3).describe('An array of exactly three key insights for the dashboard.'),
});
export type DashboardInsightsOutput = z.infer<typeof DashboardInsightsOutputSchema>;

export async function dashboardInsights(input: DashboardInsightsInput): Promise<DashboardInsightsOutput> {
  return dashboardInsightsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'dashboardInsightsPrompt',
  input: {schema: DashboardInsightsInputSchema},
  output: {schema: DashboardInsightsOutputSchema},
  prompt: `You are an expert inventory analyst and supply chain consultant. Your task is to analyze a complete summary of a company's inventory and generate exactly three actionable, high-level insights for a dashboard. The company uses these items for internal projects and operations, not for retail.

Your insights must be diverse and cover different strategic areas. Generate one of each of the following types:
1.  **A "high" priority insight:** This must be the most critical issue you can find, such as a potential stockout of a vital item, a major inefficiency, or a significant risk.
2.  **A "medium" priority insight:** This should be an important observation that suggests an opportunity for improvement or cost savings, like consolidating purchases.
3.  **A "low" priority insight:** This can be a general observation, a positive trend, or a long-term planning suggestion, such as a potential for optimizing distribution between warehouses.

**IMPORTANT: You must provide the 'title', 'description', and 'details' fields in both English (en) and Arabic (ar).** The 'details' field must be a thorough paragraph.

**Inventory Data (JSON Summary):**
{{{inventorySummary}}}

**Instructions:**
- Analyze the consumption trends, stock levels, item locations, and any historical data patterns.
- Ensure your insights are specific, data-driven, and easy to understand for a manager.
- For each of the three insights, provide: a unique 'insightId', a 'title' (en/ar), a 'description' (en/ar), a detailed analytical 'details' paragraph (en/ar), and a 'priority' level.
- Do not repeat insights. Each of the three must be unique.
- Your final response must be a JSON object that adheres to the defined output schema, containing an array of exactly three insight objects.
`,
});

const dashboardInsightsFlow = ai.defineFlow(
  {
    name: 'dashboardInsightsFlow',
    inputSchema: DashboardInsightsInputSchema,
    outputSchema: DashboardInsightsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    
    if (!output || !output.insights || output.insights.length !== 3) {
      // Fallback in case the AI doesn't return exactly 3 insights
      return {
        insights: [
          {
            insightId: 'fallback-high',
            title: { en: "Analysis Incomplete", ar: "التحليل غير مكتمل" },
            description: { en: "AI could not generate a full report. Please check data.", ar: "لم يتمكن الذكاء الاصطناعي من إنشاء تقرير كامل. يرجى التحقق من البيانات." },
            details: { en: "The AI model failed to produce a valid set of three insights. This could be due to malformed input data or a temporary issue with the AI service. Please verify the inventory summary and try again.", ar: "فشل نموذج الذكاء الاصطناعي في إنتاج مجموعة صالحة من ثلاث رؤى. قد يكون هذا بسبب بيانات إدخال غير صالحة أو مشكلة مؤقتة في خدمة الذكاء الاصطناعي. يرجى التحقق من ملخص المخزون والمحاولة مرة أخرى." },
            priority: 'high',
          },
          {
            insightId: 'fallback-medium',
            title: { en: "System Status", ar: "حالة النظام" },
            description: { en: "All systems are online.", ar: "جميع الأنظمة تعمل." },
            details: { en: "This is a placeholder insight indicating that the system is operational but could not generate a specific medium-priority insight.", ar: "هذه رؤية بديلة تشير إلى أن النظام يعمل ولكنه لم يتمكن من إنشاء رؤية متوسطة الأولوية محددة." },
            priority: 'medium',
          },
          {
            insightId: 'fallback-low',
            title: { en: "Data Loaded", ar: "تم تحميل البيانات" },
            description: { en: "Successfully connected to inventory data.", ar: "تم الاتصال ببيانات المخزون بنجاح." },
            details: { en: "This is a placeholder insight confirming that the data connection is stable, but a specific low-priority insight could not be generated.", ar: "هذه رؤية بديلة تؤكد أن اتصال البيانات مستقر، ولكن لم يتمكن من إنشاء رؤية منخفضة الأولوية محددة." },
            priority: 'low',
          }
        ]
      };
    }

    return output;
  }
);
