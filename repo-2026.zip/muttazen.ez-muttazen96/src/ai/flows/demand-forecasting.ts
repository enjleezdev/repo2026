
'use server';
/**
 * @fileOverview An AI agent that forecasts demand for inventory items.
 *
 * - forecastDemand - A function that predicts future demand based on historical data.
 * - DemandForecastInput - The input type for the forecastDemand function.
 * - DemandForecastOutput - The return type for the forecastDemand function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const DemandForecastInputSchema = z.object({
  itemName: z.string().describe('The name of the item to be forecasted.'),
  currentStock: z.number().describe('The current quantity of the item in stock.'),
  forecastPeriod: z.number().describe('The number of days into the future to forecast demand for (e.g., 30, 90).'),
  historicalData: z.string().describe('A JSON string representing an array of historical consumption and addition transactions. Each object should have a date, type, and change quantity.'),
});
type DemandForecastInput = z.infer<typeof DemandForecastInputSchema>;

const DemandForecastOutputSchema = z.object({
  forecastPeriod: z.number().describe('The period in days for which the forecast is made.'),
  predictedDemand: z.number().describe('The total predicted demand for the item over the forecast period.'),
  confidenceLevel: z.string().describe('A qualitative description of the confidence in the forecast (e.g., "High confidence due to stable consumption patterns").'),
  trendAnalysis: z.string().describe('A brief analysis of the consumption trends, seasonality, and any detected patterns.'),
  reorderRecommendation: z.string().describe('A specific recommendation on when and how much to reorder to avoid stockouts.'),
  riskAlert: z.string().optional().describe('An optional alert for potential risks, such as imminent stockout or significant overstock.'),
});
type DemandForecastOutput = z.infer<typeof DemandForecastOutputSchema>;

export async function forecastDemand(input: DemandForecastInput): Promise<DemandForecastOutput> {
  return demandForecastingFlow(input);
}

const prompt = ai.definePrompt({
  name: 'demandForecastPrompt',
  input: {schema: DemandForecastInputSchema},
  output: {schema: DemandForecastOutputSchema},
  prompt: `You are an expert demand forecasting analyst for an inventory management system. Your task is to predict future demand for a given item based on its historical data and current stock levels.

Analyze the provided data to identify consumption trends, seasonality, and any anomalies. Use this analysis to generate a precise demand forecast for the specified period. Provide actionable insights to help with inventory planning.

**Item Information:**
- Item Name: {{{itemName}}}
- Current Stock: {{{currentStock}}}
- Forecast Period: {{{forecastPeriod}}} days

**Historical Data (JSON format):**
{{{historicalData}}}

**Your Analysis Must Include:**
1.  **Predicted Demand:** An integer representing the total expected consumption for the forecast period.
2.  **Confidence Level:** A statement on how confident you are in this prediction and why.
3.  **Trend Analysis:** A concise summary of the data patterns. Is consumption increasing, decreasing, or stable? Are there seasonal spikes?
4.  **Reorder Recommendation:** Based on the forecast and current stock, when should the user reorder? Suggest a safety stock level.
5.  **Risk Alert:** If the current stock is critically low and likely to run out before a new order can be placed, issue a clear risk alert. Otherwise, this can be omitted.

Provide your response in a structured JSON format adhering to the defined output schema. Ensure the analysis is logical and data-driven.
`,
});

const demandForecastingFlow = ai.defineFlow(
  {
    name: 'demandForecastingFlow',
    inputSchema: DemandForecastInputSchema,
    outputSchema: DemandForecastOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
