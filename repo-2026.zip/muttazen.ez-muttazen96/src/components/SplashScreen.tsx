
'use client';

import React from 'react';
import Image from 'next/image';
import { cn } from '@/lib/utils';
import { Loader2 } from 'lucide-react';

export function SplashScreen() {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-white animate-fadeIn">
      <div className="w-48 h-48 relative">
         <Image
            src="/logos/ez.png"
            alt="App Logo"
            width={300}
            height={300}
            className="w-full h-full object-contain"
            data-ai-hint="warehouse logistics"
            priority 
          />
      </div>
      <div className="mt-6 text-center text-lg font-semibold">
          <span className="text-[#ff3131]">POWERD BY </span>
          <span className="text-[#311955]">ENJLEEZ TECH</span>
      </div>
      <Loader2 className="h-6 w-6 text-muted-foreground animate-spin mt-8" />
    </div>
  );
}
