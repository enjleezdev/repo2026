
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Warehouse, Package, ArrowRightLeft } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface SearchResult {
  type: 'warehouse' | 'item' | 'operation';
  id: string;
  name: string;
  context: string;
  path: string;
}

interface SearchResultsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  results: SearchResult[];
  searchTerm: string;
}

const getIconForType = (type: SearchResult['type']) => {
    switch (type) {
        case 'warehouse':
            return <Warehouse className="mr-2 h-4 w-4" />;
        case 'item':
            return <Package className="mr-2 h-4 w-4" />;
        case 'operation':
            return <ArrowRightLeft className="mr-2 h-4 w-4 text-blue-500" />;
        default:
            return <Package className="mr-2 h-4 w-4" />;
    }
};

export function SearchResultsDialog({ isOpen, onClose, results, searchTerm }: SearchResultsDialogProps) {
  const router = useRouter();
  const { t } = useLanguage();

  const handleSelect = (path: string) => {
    onClose();
    router.push(path);
  };
  
  React.useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        // This is a common pattern, but we are triggering with search button, so we might not need it.
        // For now, let's just handle closing.
      }
      if (e.key === "Escape") {
        onClose();
      }
    }
    document.addEventListener("keydown", down)
    return () => document.removeEventListener("keydown", down)
  }, [onClose])

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="p-0 gap-0">
          <Command shouldFilter={false} className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground [&_[cmdk-group]:not([hidden])_~[cmdk-group]]:pt-0 [&_[cmdk-group]]:px-2 [&_[cmdk-input-wrapper]_svg]:h-5 [&_[cmdk-input-wrapper]_svg]:w-5 [&_[cmdk-input]]:h-12 [&_[cmdk-item]]:px-2 [&_[cmdk-item]]:py-3 [&_[cmdk-item]_svg]:h-5 [&_[cmdk-item]_svg]:w-5">
            <DialogHeader className="p-4 pb-0">
                <DialogTitle>{t('searchResultsTitle')}</DialogTitle>
                <DialogDescription>
                    {t('searchResultsDesc', results.length, searchTerm)}
                </DialogDescription>
            </DialogHeader>
            <CommandList>
              <CommandEmpty>{t('noResults')}</CommandEmpty>
              <CommandGroup>
                {results.map((result) => (
                  <CommandItem
                    key={result.id}
                    value={`${result.type}-${result.name}-${result.context}`}
                    onSelect={() => handleSelect(result.path)}
                    className="cursor-pointer"
                  >
                    {getIconForType(result.type)}
                    <div className="flex flex-col">
                        <span>{result.name}</span>
                        <span className="text-xs text-muted-foreground">{result.context}</span>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
      </DialogContent>
    </Dialog>
  );
}
