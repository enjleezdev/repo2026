
// src/components/PrintableWarehouseReport.tsx
'use client';

import type { Warehouse } from '@/lib/types';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface PrintableWarehouseReportProps {
  warehouse: Warehouse;
  items: { name: string; quantity: number }[];
  printedBy: string;
  printDate: Date;
}

export function PrintableWarehouseReport({ warehouse, items, printedBy, printDate }: PrintableWarehouseReportProps) {
  return (
    <div
      id="printable-content"
      style={{
        fontFamily: 'Arial, sans-serif',
        direction: 'ltr',
        padding: '0',
        width: '100%',
        height: 'auto',
        margin: '0 auto',
        backgroundColor: 'white',
        color: 'black',
      }}
    >
      <div className="print-header" style={{ textAlign: 'center', marginBottom: '20px' }}>
        <div>
          <h1 style={{ fontSize: '18pt', margin: '0 0 5px 0' }}>Warehouse Inventory Summary</h1>
          <p style={{ fontSize: '12pt', margin: '0' }}>Warehouse: {warehouse.name}</p>
        </div>
      </div>

      <div style={{ marginBottom: '15px', fontSize: '11pt' }}>
        {warehouse.description && <p><strong>Description:</strong> {warehouse.description}</p>}
        <p><strong>Print Date:</strong> {format(printDate, "yyyy-MM-dd HH:mm:ss")}</p>
        <p><strong>Printed By:</strong> {printedBy}</p>
      </div>

      <h2 style={{ fontSize: '14pt', marginTop: '20px', marginBottom: '10px', borderBottom: '1px solid #eee', paddingBottom: '5px' }}>
        Items List
      </h2>

      {items.length > 0 ? (
        <table className="print-table" style={{ width: '100%', borderCollapse: 'collapse', fontSize: '10pt' }}>
          <thead>
            <tr>
              <th style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'left', backgroundColor: '#f0f0f0' }}>Item Name</th>
              <th style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'right', backgroundColor: '#f0f0f0' }}>Quantity</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={index}>
                <td style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'left' }}>{item.name}</td>
                <td style={{ border: '1px solid #ccc', padding: '8px', textAlign: 'right' }}>{item.quantity}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p style={{ fontSize: '11pt', textAlign: 'center', marginTop: '20px' }}>No items in this warehouse.</p>
      )}

      <div className="print-footer" style={{ textAlign: 'center', marginTop: '30px', fontSize: '9pt', borderTop: '1px solid #eee', paddingTop: '10px' }}>
      </div>
    </div>
  );
}
