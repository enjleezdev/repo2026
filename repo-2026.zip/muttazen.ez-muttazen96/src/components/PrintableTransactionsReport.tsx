
// src/components/PrintableTransactionsReport.tsx
'use client';

import React from 'react';
import { HistoryEntry, Warehouse, Item } from '@/lib/types';
import { format } from 'date-fns';
import { translations, TranslationKey } from '@/lib/translations';

type TranslationDict = typeof translations['en'];

interface Props {
  filteredHistory: HistoryEntry[];
  warehouses: Warehouse[];
  items: Item[];
  printedBy: string;
  printDate: Date;
  t: TranslationDict;
}

const isValidDate = (date: any) => date && !isNaN(new Date(date).getTime());

// Shared cell styles
const headerCellStyle: React.CSSProperties = {
  border: '1px solid #ddd',
  padding: '8px',
  textAlign: 'left',
  backgroundColor: '#f9f9f9',
  fontWeight: 'bold',
  fontSize: '10pt',
};

const bodyCellStyle: React.CSSProperties = {
  border: '1px solid #ddd',
  padding: '8px',
  textAlign: 'left',
  fontSize: '9pt',
  verticalAlign: 'top',
};

export default function PrintableTransactionsReport({
  filteredHistory,
  warehouses,
  items,
  printedBy,
  printDate,
  t,
}: Props) {
  const getChangeColor = (change: number) => {
    if (change > 0) return 'green';
    if (change < 0) return 'red';
    return 'black';
  };

  return (
    <div
      id="printable-content"
      style={{
        fontFamily: 'Arial, sans-serif',
        direction: 'ltr',
        padding: '0',
        width: '100%',
        height: 'auto',
        margin: '0 auto',
        backgroundColor: 'white',
        color: 'black',
      }}
    >
      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h1 style={{ fontSize: '16pt', margin: '0 0 5px 0' }}>
          {t.reportsTitle}
        </h1>
        <p style={{ fontSize: '11pt', margin: '0' }}>Transaction History Report</p>
      </div>

      <div style={{ marginBottom: '15px', fontSize: '10pt' }}>
        <p><strong>Print Date:</strong> {format(printDate, 'yyyy-MM-dd HH:mm:ss')}</p>
        <p><strong>Printed By:</strong> {printedBy}</p>
      </div>

      <h2
        style={{
          fontSize: '13pt',
          marginTop: '20px',
          marginBottom: '10px',
          borderBottom: '1px solid #eee',
          paddingBottom: '5px',
        }}
      >
        Transactions
      </h2>

      {filteredHistory.length > 0 ? (
        <table
          style={{
            width: '100%',
            borderCollapse: 'collapse',
            fontSize: '9pt',
          }}
        >
          <thead>
            <tr>
              <th style={{...headerCellStyle, width: '35%'}}>{t.itemName} / {t.warehouse}</th>
              <th style={{...headerCellStyle, width: '20%'}}>{t.date}</th>
              <th style={{...headerCellStyle, width: '20%'}}>{t.historyType_title}</th>
              <th style={{...headerCellStyle, width: '25%'}}>{t.quantity}</th>
            </tr>
          </thead>
          <tbody>
            {filteredHistory.map((h) => (
              <tr key={h.id}>
                <td style={bodyCellStyle}>
                  <div style={{ fontWeight: 'bold' }}>{items.find((i) => i.id === h.itemId)?.name || 'N/A'}</div>
                  <div style={{ fontSize: '8pt', color: '#555' }}>{warehouses.find((w) => w.id === h.warehouseId)?.name || 'N/A'}</div>
                </td>
                <td style={bodyCellStyle}>
                   {isValidDate(h.timestamp) ? (
                    <div>
                      <div>{format(new Date(h.timestamp), 'yyyy-MM-dd')}</div>
                      <div style={{ fontSize: '8pt', color: '#555' }}>{format(new Date(h.timestamp), 'HH:mm:ss')}</div>
                    </div>
                  ) : 'N/A'}
                </td>
                <td style={{ ...bodyCellStyle, whiteSpace: 'nowrap' }}>
                  {t[`historyType_${h.type}` as TranslationKey] || h.type.replace('_', ' ')}
                </td>
                <td style={bodyCellStyle}>
                  <div style={{display: 'flex', flexDirection: 'column', gap: '2px'}}>
                    <div style={{color: getChangeColor(h.change), fontWeight: 'bold'}}>
                      <span style={{ minWidth: '50px', display: 'inline-block' }}>{t.change_label}:</span>
                      {h.change > 0 ? `+${h.change}` : h.change}
                    </div>
                    <div style={{ color: '#555' }}>
                      <span style={{ minWidth: '50px', display: 'inline-block' }}>{t.before_label}:</span>
                      {h.quantityBefore}
                    </div>
                    <div style={{ color: '#000', fontWeight: 'bold' }}>
                      <span style={{ minWidth: '50px', display: 'inline-block' }}>{t.after_label}:</span>
                      {h.quantityAfter}
                    </div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p
          style={{
            fontSize: '11pt',
            textAlign: 'center',
            marginTop: '20px',
          }}
        >
          {t.noTransactionsFound}
        </p>
      )}

      <div
        style={{
          textAlign: 'center',
          marginTop: '30px',
          fontSize: '9pt',
          borderTop: '1px solid #eee',
          paddingTop: '10px',
        }}
      />
    </div>
  );
}
