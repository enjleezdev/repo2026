
"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import * as React from "react";
import { 
  LayoutDashboard, 
  Warehouse, 
  AreaChart,
  Archive as ArchiveIcon, 
  UserCircle, 
  LogOut, 
  HelpCircle, 
  Info,
  Sparkles,
  Bell,
  Languages,
  ArrowRightLeft,
  Brain,
  Truck
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { createClient } from "@/lib/supabase";
import type { User } from "@supabase/supabase-js";
import { useSidebar } from "@/components/ui/sidebar";
import { useLanguage } from "@/contexts/LanguageContext";
import Image from 'next/image';

export function AppSidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { toast } = useToast();
  const { isMobile, state, openMobile, setOpenMobile, dir } = useSidebar();
  const { language, setLanguage, t } = useLanguage();
  
  const [currentUser, setCurrentUser] = React.useState<User | null>(null);
  const [profileUsername, setProfileUsername] = React.useState<string | null>("User");
  const [profileEmail, setProfileEmail] = React.useState<string | null>("user@example.com");
  const [isClient, setIsClient] = React.useState(false);
  const supabase = createClient();
  
  const navIcons = {
    [t('dashboard')]: LayoutDashboard,
    [t('warehouses')]: Warehouse,
    [t('inventoryOps')]: ArrowRightLeft,
    [t('archive')]: ArchiveIcon,
    [t('profile')]: UserCircle,
    [t('aiAssistant')]: Sparkles,
    [t('howToUse')]: HelpCircle,
    [t('about')]: Info,
    'Dashboard': LayoutDashboard,
    'Warehouses': Warehouse,
    'Inventory Ops': ArrowRightLeft,
    'Archive': ArchiveIcon,
    'Profile': UserCircle,
    'Enjleez AI': Sparkles,
    'How to Use': HelpCircle,
    'About': Info,
    'Forecasting': Brain,
  };

  const loadUserData = React.useCallback(async (user: User | null) => {
    if (user) {
      setCurrentUser(user);
      setProfileEmail(user.email || "user@example.com");
      
      const { data: profile } = await supabase.from('profiles').select('username').eq('id', user.id).single();
      setProfileUsername(profile?.username || user.email?.split('@')[0] || "User");
      
    } else {
      setCurrentUser(null);
      setProfileUsername("User");
      setProfileEmail("user@example.com");
    }
  }, [supabase]);


  React.useEffect(() => {
    setIsClient(true);
    
    const handleAuthChange = (_event: string, session: any) => {
      const user = session?.user ?? null;
      loadUserData(user);
      if (_event === 'SIGNED_IN' || _event === 'USER_UPDATED') {
        router.refresh(); 
      }
    };

    const { data: authListener } = supabase.auth.onAuthStateChange(handleAuthChange);
    
    supabase.auth.getUser().then(({ data: { user } }) => {
        loadUserData(user);
    });
    
    return () => {
      authListener.subscription.unsubscribe();
    }
  }, [supabase, loadUserData, router]);


  const isActive = (path: string) => {
    if (path.includes("[") && path.includes("]")) {
      const basePath = path.substring(0, path.indexOf("["));
      return pathname.startsWith(basePath);
    }
    return pathname === path;
  };

  const handleLinkClick = () => {
    if (isMobile) {
      setOpenMobile(false);
    }
  };

  const handleSignOut = async () => {
    if (isMobile) {
      setOpenMobile(false);
    }
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error("Error signing out: ", error);
      toast({
        title: "Logout Failed",
        description: "Could not log out. Please try again.",
        variant: "destructive",
      });
    } else {
      toast({
        title: t('logout'),
        description: t('logoutSuccessDesc'),
      });
      router.push('/signin');
      router.refresh();
    }
  };

  const toggleLanguage = () => {
    const newLang = language === 'en' ? 'ar' : 'en';
    setLanguage(newLang);
  };

  const navigationLinks = [
    { href: "/dashboard", labelKey: "dashboard", originalLabel: "Dashboard" },
    { href: "/warehouses", labelKey: "warehouses", originalLabel: "Warehouses" },
    { href: "/inventory-ops", labelKey: "inventoryOps", originalLabel: "Inventory Ops" },
    { href: "/archive", labelKey: "archive", originalLabel: "Archive" },
    { href: "/ai/stock-suggestions", labelKey: "aiAssistant", originalLabel: "Enjleez AI" },
    { href: "/forecasting", labelKey: "forecasting" as any, originalLabel: "Forecasting" },
  ] as const;

  const secondaryLinks = [
    { href: "/how-to-use", labelKey: "howToUse", originalLabel: "How to Use" },
    { href: "/about", labelKey: "about", originalLabel: "About" },
  ] as const;
  
  const renderLink = (link: typeof navigationLinks[number] | typeof secondaryLinks[number]) => {
    const label = t(link.labelKey);
    const Icon = navIcons[link.originalLabel as keyof typeof navIcons] || HelpCircle;
    const active = isActive(link.href);

    return (
      <li key={link.href}>
        <Link
          href={link.href}
          onClick={handleLinkClick}
          className={cn(
            "flex h-10 items-center gap-3 rounded-md px-3 relative text-sm font-medium transition-colors",
            "justify-start",
            state === "collapsed" && "justify-center w-12 h-12 mx-auto px-0",
            active ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
          )}
        >
          <Icon className="shrink-0" size={20} />
          <span className={cn(
            "truncate",
            state === "collapsed" && "hidden"
          )}>{label}</span>
        </Link>
      </li>
    );
  };

  const sidebarContent = (isDesktop: boolean) => (
    <div className={cn("flex flex-col h-full bg-card border-r")}>
      <div className={cn("flex items-center gap-2 p-4 border-b h-20", state === 'collapsed' ? 'justify-center' : 'justify-between')}>
         <div className={cn("flex items-center gap-2 ml-2", state === 'collapsed' && 'hidden')}>
            <Image
              src="/logos/muttazen-removebg-preview.png"
              alt="EZ Inventory Logo"
              width={200}
              height={120}
              className="h-auto"
              priority
            />
          </div>
          <div className={cn("flex items-center", state === 'expanded' && 'hidden')}>
             <Image src="/logos/ez.png" alt="Logo" width={40} height={40} className="h-10 w-auto rounded-md" />
          </div>
      </div>
      
      <nav className="flex-1 overflow-y-auto p-2 space-y-4">
        <ul className="flex flex-col gap-1">
          {navigationLinks.map(renderLink)}
        </ul>
        <ul className="flex flex-col gap-1">
          {secondaryLinks.map(renderLink)}
        </ul>
      </nav>

      <div className={cn("border-t p-2", state === 'collapsed' ? 'space-y-2' : 'space-y-3')}>
         <div className={cn("flex items-center gap-3 p-2", state === 'collapsed' && 'hidden')}>
          <UserCircle className="h-10 w-10 text-muted-foreground" strokeWidth={1.5} />
          <div className="flex flex-col justify-center overflow-hidden">
            <p className="text-sm font-medium leading-normal truncate">{profileUsername || "User"}</p>
            <p className="text-xs text-muted-foreground leading-normal truncate">{profileEmail || "user@example.com"}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
           <Button variant="ghost" className="flex-1" onClick={toggleLanguage}>
            <Languages className="mr-2 h-4 w-4" />
            <span className={cn(state === 'collapsed' && "hidden")}>{t('toggleLanguage')}</span>
          </Button>
           <Button variant="ghost" className={cn(state === 'collapsed' ? "flex-1" : "")} onClick={handleSignOut}>
            <LogOut className="h-4 w-4" />
            <span className={cn(state === 'collapsed' && "hidden", "ml-2")}>{t('logout')}</span>
          </Button>
        </div>
      </div>
    </div>
  );


  if (!isClient) {
    return null;
  }

  if (isMobile) {
    return (
      <Sheet open={openMobile} onOpenChange={setOpenMobile}>
        <SheetContent
          side={dir === 'ltr' ? 'left' : 'right'}
          className="w-10/12 p-0 border-0"
        >
          <SheetHeader>
            <SheetTitle className="sr-only">{t('menu')}</SheetTitle>
          </SheetHeader>
          {sidebarContent(false)}
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <div
      data-state={state}
      className={cn(
        "hidden md:block fixed top-0 h-full z-40 transition-all duration-300",
        dir === 'ltr' ? 'left-0' : 'right-0',
        state === 'expanded' ? 'w-64' : 'w-20'
      )}
    >
      {sidebarContent(true)}
    </div>
  );
}

    
