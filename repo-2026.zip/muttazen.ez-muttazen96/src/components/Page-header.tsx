import type { PropsWithChildren, ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface PageHeaderProps {
  title: string;
  description?: string;
  actions?: ReactNode;
  className?: string; // Allow className to be passed
}

export function PageHeader({ title, description, actions, children, className }: PropsWithChildren<PageHeaderProps>) {
  return (
    <div className={cn("flex flex-col gap-4 mb-6", className)}> {/* Added mb-6 for bottom margin */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">{title}</h1>
          {description && (
            <p className="mt-1 text-sm text-muted-foreground">{description}</p>
          )}
        </div>
        {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
      </div>
      {children}
    </div>
  );
}
