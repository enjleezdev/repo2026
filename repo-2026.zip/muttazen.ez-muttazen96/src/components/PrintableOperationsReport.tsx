
// src/components/PrintableOperationsReport.tsx
'use client';

import type { InventoryOperation } from '@/lib/types';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import type { TranslationKey } from '@/lib/translations';

interface PrintableOperationsReportProps {
  operations: InventoryOperation[];
  reportTitle: string;
  printedBy: string;
  printDate: Date;
  t: (key: TranslationKey, ...args: (string | number)[]) => string;
}

const isValidDate = (date: any) => date && !isNaN(new Date(date).getTime());

export function PrintableOperationsReport({ operations, reportTitle, printedBy, printDate, t }: PrintableOperationsReportProps) {
  return (
    <div
      id="printable-content"
      style={{
        fontFamily: 'Arial, sans-serif',
        direction: 'ltr',
        padding: '0',
        width: '100%',
        height: 'auto',
        margin: '0 auto',
        backgroundColor: 'white',
        color: 'black',
      }}
    >
      <div className="print-header" style={{ textAlign: 'center', marginBottom: '20px' }}>
        <div>
          <h1 style={{ fontSize: '16pt', margin: '0 0 5px 0' }}>{reportTitle}</h1>
          <p style={{ fontSize: '11pt', margin: '0' }}>Operations Log Report</p>
        </div>
      </div>

      <div style={{ marginBottom: '15px', fontSize: '10pt' }}>
        <p><strong>Print Date:</strong> {format(printDate, "yyyy-MM-dd HH:mm:ss")}</p>
        <p><strong>Printed By:</strong> {printedBy}</p>
      </div>

      <h2 style={{ fontSize: '13pt', marginTop: '20px', marginBottom: '10px', borderBottom: '1px solid #eee', paddingBottom: '5px' }}>
        Operations
      </h2>
      
      {operations.length > 0 ? (
        <table className="print-table" style={{ width: '100%', borderCollapse: 'collapse', fontSize: '9pt' }}>
          <thead>
            <tr>
              <th style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left', backgroundColor: '#f0f0f0' }}>Date</th>
              <th style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left', backgroundColor: '#f0f0f0' }}>Item Name</th>
              <th style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left', backgroundColor: '#f0f0f0' }}>Warehouse</th>
               <th style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left', backgroundColor: '#f0f0f0' }}>Supplier</th>
              <th style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left', backgroundColor: '#f0f0f0' }}>Type</th>
              <th style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'center', backgroundColor: '#f0f0f0' }}>Quantity</th>
              <th style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left', backgroundColor: '#f0f0f0' }}>User</th>
              <th style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left', backgroundColor: '#f0f0f0', minWidth: '80px' }}>Invoice #</th>
            </tr>
          </thead>
          <tbody>
            {operations.map((op) => (
              <tr key={op.id}>
                <td style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left', whiteSpace: 'nowrap' }}>
                  {isValidDate(op.created_at)
                    ? format(new Date(op.created_at), "yyyy-MM-dd HH:mm")
                    : 'Invalid Date'}
                </td>
                <td style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left' }}>{op.item_name}</td>
                <td style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left' }}>{op.warehouse_name}</td>
                <td style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left' }}>{op.supplier_name || 'N/A'}</td>
                <td style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left', whiteSpace: 'nowrap' }}>
                   {t(`opType_${op.type}` as TranslationKey)}
                </td>
                <td style={{ 
                    border: '1px solid #ccc', 
                    padding: '6px', 
                    textAlign: 'center', 
                    whiteSpace: 'nowrap', 
                    color: op.type === 'purchase' ? 'green' : 'red' 
                }}>
                  {op.quantity}
                </td>
                <td style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left' }}>{op.user_name}</td>
                <td style={{ border: '1px solid #ccc', padding: '6px', textAlign: 'left' }}>{op.invoice_number || 'N/A'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p style={{ fontSize: '11pt', textAlign: 'center', marginTop: '20px' }}>No operations found for this selection.</p>
      )}
      
      <div className="print-footer" style={{ textAlign: 'center', marginTop: '30px', fontSize: '9pt', borderTop: '1px solid #eee', paddingTop: '10px' }}>
      </div>
    </div>
  );
}
