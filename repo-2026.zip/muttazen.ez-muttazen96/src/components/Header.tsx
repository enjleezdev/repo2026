
"use client";

import * as React from "react";
import Link from "next/link";
import { Bell, Menu, Search, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useSidebar } from "@/components/ui/sidebar";
import { useLanguage } from "@/contexts/LanguageContext";
import { createClient } from "@/lib/supabase";
import { cn } from "@/lib/utils";
import { SearchResultsDialog } from "@/components/SearchResultsDialog";
import type { Item, Warehouse } from "@/lib/types";

interface SearchResult {
  type: 'warehouse' | 'item' | 'operation';
  id: string;
  name: string;
  context: string;
  path: string;
}

function NotificationsButton() {
  const [unreadCount, setUnreadCount] = React.useState(0);
  const supabase = createClient();

  React.useEffect(() => {
    const fetchUnreadCount = async (userId: string) => {
      const { count, error } = await supabase
        .from("notifications")
        .select("*", { count: "exact", head: true })
        .eq("owner_id", userId)
        .eq("is_read", false);
      
      if (error) {
        console.error("Error fetching unread count:", error.message || "RLS policy might be missing.");
        setUnreadCount(0);
      } else {
        setUnreadCount(count ?? 0);
      }
    };

    const handleAuthAndNotifications = (user: any) => {
      if (user) {
        fetchUnreadCount(user.id);
        const channel = supabase
          .channel(`realtime-header-notifications-${user.id}`)
          .on(
            "postgres_changes",
            {
              event: "*",
              schema: "public",
              table: "notifications",
              filter: `owner_id=eq.${user.id}`,
            },
            () => fetchUnreadCount(user.id)
          )
          .subscribe();
        return () => {
          supabase.removeChannel(channel);
        };
      }
    };

    let unsubscribe: (() => void) | undefined;
    supabase.auth.getUser().then(({ data: { user } }) => {
      unsubscribe = handleAuthAndNotifications(user) ?? undefined;
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (unsubscribe) unsubscribe();
      unsubscribe = handleAuthAndNotifications(session?.user) ?? undefined;
    });

    return () => {
      subscription?.unsubscribe();
      if (unsubscribe) unsubscribe();
    };
  }, [supabase]);

  return (
    <Button asChild variant="ghost" size="icon" className="relative">
      <Link href="/notifications">
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <span className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
        <span className="sr-only">Notifications</span>
      </Link>
    </Button>
  );
}

export function Header() {
  const { toggleSidebar } = useSidebar();
  const { t, dir } = useLanguage();
  const supabase = createClient();
  const [searchTerm, setSearchTerm] = React.useState('');
  const [isSearching, setIsSearching] = React.useState(false);
  const [searchResults, setSearchResults] = React.useState<SearchResult[]>([]);
  const [isResultsOpen, setIsResultsOpen] = React.useState(false);
  
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTerm.trim()) return;

    setIsSearching(true);
    try {
      const { data, error } = await supabase.rpc('search_all', { keyword: searchTerm.trim() });
      if (error) {
        console.error("Search RPC error. Check RLS policies for warehouses and items.", error);
        throw error;
      }
      
      const formattedResults: SearchResult[] = data.map((item: any) => ({
        type: item.type,
        id: item.id,
        name: item.name,
        context: item.context,
        path: item.type === 'warehouse' 
                ? `/warehouses/${item.id}` 
                : item.type === 'item'
                ? `/warehouses/${item.warehouse_id}/items/${item.id}`
                : '/inventory-ops', // Path for 'operation' type
      }));
      setSearchResults(formattedResults);
      setIsResultsOpen(true);

    } catch (err: any) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <>
    <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background px-4 sm:px-6">
      <Button
        variant="ghost"
        size="icon"
        className="md:hidden"
        onClick={toggleSidebar}
      >
        <Menu className="h-6 w-6" />
        <span className="sr-only">Toggle Menu</span>
      </Button>

      <div className="flex w-full items-center justify-end gap-2 md:gap-4">
        <form onSubmit={handleSearch} className="relative ml-auto flex-1 md:grow-0">
          <Search className={cn("absolute top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground", dir === 'ltr' ? 'left-2.5' : 'right-2.5')} />
          <Input
            type="search"
            placeholder={t("search")}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={cn(
              "w-full rounded-lg bg-muted",
              dir === 'ltr' ? 'pl-8 pr-20' : 'pr-8 pl-20',
              "md:w-[200px] lg:w-[320px]"
            )}
          />
           <Button 
              type="submit" 
              size="sm"
              className={cn(
                "absolute top-1/2 -translate-y-1/2 h-7 bg-blue-400 text-white hover:bg-blue-500",
                dir === 'ltr' ? 'right-1.5' : 'left-1.5'
              )}
              disabled={isSearching}
            >
              {isSearching ? '...' : t('searchBtn')}
          </Button>
        </form>
        <NotificationsButton />
        <Button asChild variant="ghost" size="icon">
          <Link href="/profile">
            <Settings className="h-5 w-5" />
            <span className="sr-only">{t("settings")}</span>
          </Link>
        </Button>
      </div>
    </header>
    <SearchResultsDialog
        isOpen={isResultsOpen}
        onClose={() => setIsResultsOpen(false)}
        results={searchResults}
        searchTerm={searchTerm}
    />
    </>
  );
}
