
'use client';

import * as React from 'react';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Building, Mail, Globe } from 'lucide-react';
import Link from 'next/link';
import { useLanguage } from '@/contexts/LanguageContext';

export default function AboutPage() {
  const { t } = useLanguage();
  return (
    <>
      <PageHeader
        title={t('aboutTitle')}
        description={t('aboutDescription')}
      />
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Building className="h-6 w-6 text-primary" />
              <span>{t('developedByTitle')}</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="text-muted-foreground">
            <p>
              {t('developedByDesc')}
            </p>
          </CardContent>
        </Card>

        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-3">
                <Mail className="h-6 w-6 text-primary" />
                <span>{t('contactSupport')}</span>
                </CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground space-y-3">
                <p>
                    {t('contactSupportDesc')}
                </p>
                <div className="flex items-center gap-3">
                    <Mail className="h-4 w-4"/>
                    <a href="mailto:contact@enjleez.com" className="text-primary hover:underline">
                        contact@enjleez.com
                    </a>
                </div>
                 <div className="flex items-center gap-3">
                    <Globe className="h-4 w-4"/>
                    <Link href="https://enjleez.tech/en" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                        {t('visitWebsite')}
                    </Link>
                </div>
            </CardContent>
        </Card>
      </div>
    </>
  );
}
