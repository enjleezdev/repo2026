
'use client';

import * as React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { createClient } from '@/lib/supabase';
import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { useToast } from '@/hooks/use-toast';
import { Download, PlusCircle, CalendarIcon, ListChecks, PackagePlus, Truck } from 'lucide-react';
import type { Item, Warehouse, HistoryEntry, UserProfile, InventoryOperation, Supplier } from '@/lib/types';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { EmptyState } from '@/components/EmptyState';
import { format, formatDistanceToNow } from 'date-fns';
import { useRouter } from 'next/navigation';
import { cn } from '@/lib/utils';
import { useLanguage } from '@/contexts/LanguageContext';
import html2pdf from 'html2pdf.js';
import type { User } from '@supabase/supabase-js';
import { PrintableOperationsReport } from '@/components/PrintableOperationsReport';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogClose, DialogTrigger } from '@/components/ui/dialog';
import { translations, TranslationKey } from '@/lib/translations';
import { renderToStaticMarkup } from 'react-dom/server';


const generateFilename = (parts: string[]) => {
  const now = new Date();
  const timestamp = `${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}${now.getHours().toString().padStart(2, '0')}${now.getMinutes().toString().padStart(2, '0')}${now.getSeconds().toString().padStart(2, '0')}`;
  return [...parts, timestamp].join('-').replace(/[^a-zA-Z0-9-]/g, '_');
};

const itemFormSchema = z.object({
  name: z.string().min(2, { message: 'Item name must be at least 2 characters.' }),
  low_stock_threshold: z.coerce.number().int().min(0).optional(),
  location: z.string().optional(),
});
type ItemFormValues = z.infer<typeof itemFormSchema>;

const supplierFormSchema = z.object({
  name: z.string().min(2, { message: 'Supplier name must be at least 2 characters.' }),
  phone: z.string().min(1, { message: 'Please enter a valid phone number.' }),
  email: z.string().email({ message: 'Please enter a valid email address.' }).optional().or(z.literal('')),
  address: z.string().optional(),
});
type SupplierFormValues = z.infer<typeof supplierFormSchema>;


export default function InventoryOpsPage() {
  const { toast } = useToast();
  const router = useRouter();
  const { t } = useLanguage();
  const supabase = createClient();
  
  const [warehouses, setWarehouses] = React.useState<Warehouse[]>([]);
  const [suppliers, setSuppliers] = React.useState<Supplier[]>([]);
  const [allItems, setAllItems] = React.useState<Item[]>([]);
  const [itemsInSelectedWarehouse, setItemsInSelectedWarehouse] = React.useState<Item[]>([]);
  const [purchaseOperations, setPurchaseOperations] = React.useState<InventoryOperation[]>([]);
  const [operations, setOperations] = React.useState<InventoryOperation[]>([]);
  const [filteredOperations, setFilteredOperations] = React.useState<InventoryOperation[]>([]);
  const [filterType, setFilterType] = React.useState<string>('all');
  
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isDownloading, setIsDownloading] = React.useState(false);
  const [isAddItemDialogOpen, setIsAddItemDialogOpen] = React.useState(false);
  const [isAddSupplierDialogOpen, setIsAddSupplierDialogOpen] = React.useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = React.useState(false);

  
  const [currentUser, setCurrentUser] = React.useState<User | null>(null);
  const [userProfile, setUserProfile] = React.useState<UserProfile | null>(null);
  
  const formSchema = z.object({
    operationType: z.enum(['purchase', 'return', 'damaged'], { required_error: 'Operation type is required.' }),
    warehouseId: z.string().optional(),
    itemId: z.string().optional(),
    quantity: z.coerce.number().int().positive({ message: 'Quantity must be a positive number.' }).optional(),
    invoiceNumber: z.string().optional(),
    purchaseDate: z.date().optional(),
    comment: z.string().optional(),
    linkedPurchaseId: z.string().optional(),
    supplierId: z.string().optional(),
  }).superRefine((data, ctx) => {
    if (data.operationType === 'purchase') {
      if (!data.invoiceNumber || data.invoiceNumber.trim() === '') {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Invoice number is required for a purchase.', path: ['invoiceNumber'] });
      }
      if (!data.purchaseDate) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Invoice date is required for a purchase.', path: ['purchaseDate'] });
      }
      if (!data.warehouseId) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Warehouse is required.', path: ['warehouseId']});
      }
      if (!data.itemId) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Item is required.', path: ['itemId']});
      }
       if (!data.supplierId) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Supplier is required.', path: ['supplierId']});
      }
      if (!data.quantity) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Quantity must be a positive number.', path: ['quantity']});
      }
    }
    if (data.operationType === 'return') {
      if (!data.linkedPurchaseId) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'The selected purchase invoice was not found.', path: ['linkedPurchaseId'] });
      }
      if (!data.quantity || data.quantity <= 0) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Quantity must be a positive number.', path: ['quantity'] });
      }
    }
    if (data.operationType === 'damaged') {
      if (!data.warehouseId) {
         ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Warehouse is required.', path: ['warehouseId']});
      }
       if (!data.itemId) {
         ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Item is required.', path: ['itemId']});
      }
       if (!data.quantity) {
         ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Quantity must be a positive number.', path: ['quantity']});
      }
    }
  });

  type FormValues = z.infer<typeof formSchema>;
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { 
      operationType: 'purchase',
      warehouseId: '',
      itemId: '',
      quantity: 1,
      invoiceNumber: '',
      purchaseDate: undefined,
      comment: '',
      linkedPurchaseId: '',
      supplierId: '',
    },
  });
  
  const addItemForm = useForm<ItemFormValues>({
    resolver: zodResolver(itemFormSchema),
    defaultValues: { name: '', location: '', low_stock_threshold: 10 },
  });

  const addSupplierForm = useForm<SupplierFormValues>({
    resolver: zodResolver(supplierFormSchema),
    defaultValues: { name: '', phone: '', email: '', address: '' },
  });


  const selectedWarehouseId = form.watch('warehouseId');
  const operationType = form.watch('operationType');
  const selectedPurchaseToReturnId = form.watch('linkedPurchaseId');
  const selectedPurchaseToReturn = purchaseOperations.find(p => p.id === selectedPurchaseToReturnId);

  React.useEffect(() => {
    if (selectedPurchaseToReturn) {
      form.setValue('quantity', selectedPurchaseToReturn.quantity);
    }
  }, [selectedPurchaseToReturn, form]);

  const loadInitialData = React.useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      router.push('/signin');
      return;
    }
    setCurrentUser(user);
    setIsLoading(true);

    try {
      const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single();
      setUserProfile(profile as UserProfile);

      const [whRes, itemRes, opsRes, supRes] = await Promise.all([
        supabase.from('warehouses').select('*').eq('is_archived', false),
        supabase.from('items').select('*').eq('is_archived', false),
        supabase.from('inventory_operations').select('*').order('created_at', { ascending: false }),
        supabase.from('suppliers').select('*').eq('is_archived', false)
      ]);

      if (whRes.error) throw whRes.error;
      setWarehouses(whRes.data as Warehouse[]);
      
      if (supRes.error) throw supRes.error;
      setSuppliers(supRes.data as Supplier[]);

      if (itemRes.error) throw itemRes.error;
      setAllItems(itemRes.data.map(item => ({...item, history: item.history || []})) as Item[]);
      
      if (opsRes.error) throw opsRes.error;
      const opsData = opsRes.data as InventoryOperation[];
      setOperations(opsData);
      setFilteredOperations(opsData);
      setPurchaseOperations(opsData.filter(op => op.type === 'purchase'));

    } catch (err: any) {
        toast({ title: t('error'), description: err.message, variant: 'destructive' });
    } finally {
        setIsLoading(false);
    }
  }, [supabase, router, toast, t]);

  React.useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  React.useEffect(() => {
    form.reset({
      operationType: form.getValues('operationType'),
      quantity: 1, 
      invoiceNumber: '',
      purchaseDate: undefined,
      comment: '',
      linkedPurchaseId: '',
      warehouseId: '',
      itemId: '',
      supplierId: '',
    });
    setItemsInSelectedWarehouse([]);
  }, [operationType, form]);

  React.useEffect(() => {
    if (selectedWarehouseId) {
      const filtered = allItems.filter(item => item.warehouse_id === selectedWarehouseId);
      setItemsInSelectedWarehouse(filtered);
      form.resetField('itemId');
    } else {
      setItemsInSelectedWarehouse([]);
    }
  }, [selectedWarehouseId, allItems, form]);

  React.useEffect(() => {
    if (filterType === 'all') {
      setFilteredOperations(operations);
    } else {
      setFilteredOperations(operations.filter(op => op.type === filterType));
    }
  }, [filterType, operations]);
  
  async function onAddNewItemSubmit(data: ItemFormValues) {
    if (!selectedWarehouseId || !currentUser) {
      toast({ title: 'Error', description: 'Warehouse is required.', variant: 'destructive' });
      return;
    }

    const newItemData = {
      warehouse_id: selectedWarehouseId,
      name: data.name,
      quantity: 0, // Item is created with 0 quantity, purchase operation will add it.
      history: [{
        id: Date.now().toString() + '-hist', type: 'CREATE_ITEM', change: 0,
        quantityBefore: 0, quantityAfter: 0, timestamp: new Date().toISOString(),
        comment: 'Item created via Purchase Operation form',
      }],
      is_archived: false,
      owner_id: currentUser.id,
      low_stock_threshold: data.low_stock_threshold ?? 10,
      location: data.location || ''
    };

    const { data: insertedItem, error } = await supabase.from('items').insert(newItemData).select().single();
    if (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
      return;
    }

    toast({ title: 'Success', description: 'Item added successfully.' });
    setIsAddItemDialogOpen(false);
    addItemForm.reset({ name: '', location: '', low_stock_threshold: 10 });
    
    const newItem = {...insertedItem, history: insertedItem.history || []} as Item;
    setAllItems(prev => [...prev, newItem]);
    setItemsInSelectedWarehouse(prev => [...prev, newItem]);
    form.setValue('itemId', newItem.id);
  }

  async function onAddSupplierSubmit(data: SupplierFormValues) {
    if (!currentUser) return;

    const submissionData = {
      name: data.name,
      phone: data.phone,
      email: data.email || null,
      address: data.address || null,
      owner_id: currentUser.id,
    };

    const { data: insertedSupplier, error } = await supabase.from('suppliers').insert(submissionData).select().single();
    if (error) {
        toast({ title: 'Error', description: error.message, variant: 'destructive' });
        return;
    }

    toast({ title: 'Success', description: `Supplier ${data.name} added successfully.` });
    setIsAddSupplierDialogOpen(false);
    addSupplierForm.reset({ name: '', phone: '', email: '', address: '' });
    
    const newSupplier = insertedSupplier as Supplier;
    setSuppliers(prev => [...prev, newSupplier]);
    form.setValue('supplierId', newSupplier.id);
  }


  async function onSubmit(data: FormValues) {
    if (!currentUser) return;
    setIsSubmitting(true);
    
    try {
      const { operationType, comment } = data;
      const userName = userProfile?.username || currentUser.email || 'System';

      let item: Item | undefined;
      let quantityChange: number;
      let historyType: HistoryEntry['type'];

      if (operationType === 'return') {
        if (!selectedPurchaseToReturn) throw new Error('The selected purchase invoice was not found.');
        item = allItems.find(i => i.id === selectedPurchaseToReturn.item_id);
        if (!item) throw new Error('The selected item could not be found.');
        const returnQuantity = data.quantity!;
        if (returnQuantity > selectedPurchaseToReturn.quantity) {
          form.setError("quantity", { type: "manual", message: `Return quantity cannot exceed original purchase quantity (${selectedPurchaseToReturn.quantity}).` });
          setIsSubmitting(false);
          return;
        }
        quantityChange = -returnQuantity;
        historyType = 'return';
      } else { // Purchase or Damaged
        item = allItems.find(i => i.id === data.itemId);
        if (!item) throw new Error('The selected item could not be found.');
        const opQuantity = data.quantity!;
        quantityChange = operationType === 'purchase' ? opQuantity : -opQuantity;
        historyType = operationType;
      }
      
      const newQuantity = item.quantity + quantityChange;
      if (newQuantity < 0) {
        form.setError("quantity", { type: "manual", message: `Cannot log damage for a quantity greater than available stock (${item.quantity}).` });
        setIsSubmitting(false);
        return;
      }

      let autoComment = `[${operationType}] by ${userName}.`;
      if (operationType === 'purchase') {
        autoComment += ` Invoice: ${data.invoiceNumber || 'N/A'}. Date: ${data.purchaseDate ? format(data.purchaseDate, 'P') : 'N/A'}.`;
      } else if (operationType === 'damaged' && data.linkedPurchaseId) {
        const linkedPurchase = purchaseOperations.find(p => p.id === data.linkedPurchaseId);
        autoComment += ` Linked to invoice #${linkedPurchase?.invoice_number || 'N/A'}.`;
      } else if (operationType === 'return' && selectedPurchaseToReturn) {
         autoComment += ` for invoice #${selectedPurchaseToReturn.invoice_number || 'N/A'}.`;
      }
      if (comment) {
        autoComment += ` Comment: ${comment}`;
      }

      const newHistoryEntry: HistoryEntry = {
        id: Date.now().toString() + '-hist',
        type: historyType,
        change: quantityChange,
        quantityBefore: item.quantity,
        quantityAfter: newQuantity,
        comment: autoComment,
        timestamp: new Date().toISOString(),
      };
      
      await supabase.from('items').update({ quantity: newQuantity, history: [...item.history, newHistoryEntry] }).eq('id', item.id);

      const selectedSupplier = data.supplierId ? suppliers.find(s => s.id === data.supplierId) : null;

      const newOperation: Omit<InventoryOperation, 'id' | 'created_at'> = {
        type: operationType,
        item_id: item.id,
        item_name: item.name,
        warehouse_id: item.warehouse_id,
        warehouse_name: warehouses.find(w => w.id === item.warehouse_id)?.name || 'Unknown',
        quantity: Math.abs(quantityChange),
        user_id: currentUser.id,
        user_name: userName,
        invoice_number: data.invoiceNumber,
        purchase_date: data.purchaseDate?.toISOString(),
        comment,
        original_purchase_id: operationType === 'damaged' ? data.linkedPurchaseId : (operationType === 'return' ? selectedPurchaseToReturn!.id : undefined),
        supplier_id: selectedSupplier?.id,
        supplier_name: selectedSupplier?.name,
      };
      await supabase.from('inventory_operations').insert(newOperation);

      toast({ title: 'Success', description: 'Operation logged successfully.' });
      form.reset({
        operationType: form.getValues('operationType'),
        quantity: 1, 
        comment: '', 
        invoiceNumber: '',
        purchaseDate: undefined,
        linkedPurchaseId: '',
        warehouseId: data.warehouseId, // Keep warehouse selected
        itemId: '', // Clear selected item
        supplierId: ''
      });
      loadInitialData();
    } catch (err: any) {
      console.error(err);
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  }

  const getCurrentReportTitle = () => {
    let title = 'Operations Log Report';
    if (filterType !== 'all') {
      title = `${filterType.charAt(0).toUpperCase() + filterType.slice(1)} Operations Report`;
    }
    return title;
  };
  
  const t_report = (key: TranslationKey, ...args: (string | number)[]): string => {
      let translation = translations['en'][key] || key;
      if (args.length > 0) {
          args.forEach((arg, index) => {
              translation = translation.replace(`{${index}}`, String(arg));
          });
      }
      return translation;
  };


  const handleDownloadReport = () => {
    if (filteredOperations.length === 0) {
      toast({ title: 'No transactions found.', description: 'Try adjusting your filters.', variant: "default" });
      return;
    }
    
    setIsDownloading(true);

    const reportTitle = "Operations Log Report";
    const filename = generateFilename(['Inv-Ops', reportTitle]);
    
    const htmlString = renderToStaticMarkup(
      <PrintableOperationsReport
        operations={filteredOperations}
        reportTitle={reportTitle}
        printedBy={userProfile?.username || currentUser?.email || 'User'}
        printDate={new Date()}
        t={t_report}
      />
    );

    const container = document.createElement('div');
    container.innerHTML = htmlString;
    document.body.appendChild(container);

    html2pdf().from(container).set({
      margin: [15, 15, 15, 15],
      filename: `${filename}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true, logging: false },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    }).save().then(() => {
        document.body.removeChild(container);
        setIsDownloading(false);
    }).catch(err => {
        document.body.removeChild(container);
        setIsDownloading(false);
        toast({ title: 'Error', description: 'Failed to generate PDF.', variant: 'destructive'});
        console.error(err);
    });
  };


  return (
    <>
      <PageHeader
        title="Inventory Operations"
        description="Log purchases, returns, and damages in one place."
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>New Operation</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField control={form.control} name="operationType" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Operation Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl><SelectTrigger><SelectValue placeholder="Select operation type..." /></SelectTrigger></FormControl>
                        <SelectContent>
                          <SelectItem value="purchase">Purchase</SelectItem>
                          <SelectItem value="return">Return to Supplier</SelectItem>
                          <SelectItem value="damaged">Damaged</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                  
                  {operationType === 'return' ? (
                    <>
                      <FormField control={form.control} name="linkedPurchaseId" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Select Purchase Invoice to Return</FormLabel>
                           <Select onValueChange={field.onChange} defaultValue={field.value || ''} disabled={purchaseOperations.length === 0}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Select an invoice..." /></SelectTrigger></FormControl>
                            <SelectContent>
                              {purchaseOperations.length > 0 ? purchaseOperations.map(op => (
                                <SelectItem key={op.id} value={op.id}>
                                  {op.invoice_number || `Purchase on ${format(new Date(op.created_at), 'P')}`} ({op.item_name})
                                </SelectItem>
                              )) : <div className="p-4 text-sm text-muted-foreground">No previous purchases found.</div>}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )} />
                      {selectedPurchaseToReturn && (
                        <>
                          <div className="text-sm p-3 bg-muted rounded-md space-y-1">
                            <p><strong>Item Name:</strong> {selectedPurchaseToReturn.item_name}</p>
                            <p><strong>Warehouse:</strong> {selectedPurchaseToReturn.warehouse_name}</p>
                            <p><strong>Return quantity cannot exceed original purchase quantity ({selectedPurchaseToReturn.quantity})</strong></p>
                          </div>
                          <FormField control={form.control} name="quantity" render={({ field }) => (
                            <FormItem>
                              <FormLabel>Quantity to Return</FormLabel>
                              <FormControl><Input type="number" {...field} /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )} />
                        </>
                      )}
                    </>
                  ) : (
                    <>
                      <FormField control={form.control} name="warehouseId" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Warehouse</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value || ''}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Select a warehouse" /></SelectTrigger></FormControl>
                            <SelectContent>
                              {warehouses.map(wh => <SelectItem key={wh.id} value={wh.id}>{wh.name}</SelectItem>)}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )} />

                      <FormField control={form.control} name="itemId" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Item Name</FormLabel>
                          <div className="flex gap-2">
                            <Select onValueChange={field.onChange} value={field.value || ''} disabled={!selectedWarehouseId}>
                                <FormControl><SelectTrigger><SelectValue placeholder="Select an item" /></SelectTrigger></FormControl>
                                <SelectContent>
                                {itemsInSelectedWarehouse.map(item => <SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                            {operationType === 'purchase' && selectedWarehouseId && (
                                <Dialog open={isAddItemDialogOpen} onOpenChange={setIsAddItemDialogOpen}>
                                    <DialogTrigger asChild>
                                        <Button type="button" variant="outline" size="icon" aria-label="Add new item">
                                            <PackagePlus className="h-4 w-4" />
                                        </Button>
                                    </DialogTrigger>
                                    <DialogContent>
                                        <DialogHeader>
                                            <DialogTitle>Add Item</DialogTitle>
                                        </DialogHeader>
                                        <Form {...addItemForm}>
                                            <form onSubmit={addItemForm.handleSubmit(onAddNewItemSubmit)} className="space-y-4">
                                                <FormField control={addItemForm.control} name="name" render={({ field }) => (
                                                    <FormItem><FormLabel>Item Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                                                )} />
                                                <FormField control={addItemForm.control} name="low_stock_threshold" render={({ field }) => (
                                                    <FormItem><FormLabel>Low Stock Threshold</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                                                )} />
                                                <FormField control={addItemForm.control} name="location" render={({ field }) => (
                                                    <FormItem><FormLabel>Item Location</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                                                )} />
                                                <DialogFooter>
                                                    <DialogClose asChild><Button type="button" variant="ghost">Cancel</Button></DialogClose>
                                                    <Button type="submit">Save Item</Button>
                                                </DialogFooter>
                                            </form>
                                        </Form>
                                    </DialogContent>
                                </Dialog>
                            )}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )} />
                      
                      {operationType === 'purchase' && (
                        <>
                          <FormField control={form.control} name="supplierId" render={({ field }) => (
                            <FormItem>
                              <FormLabel>Supplier</FormLabel>
                              <div className="flex gap-2">
                                <Select onValueChange={field.onChange} value={field.value || ''} disabled={suppliers.length === 0}>
                                  <FormControl><SelectTrigger><SelectValue placeholder="Select a supplier..." /></SelectTrigger></FormControl>
                                  <SelectContent>
                                    {suppliers.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                                  </SelectContent>
                                </Select>
                                <Dialog open={isAddSupplierDialogOpen} onOpenChange={setIsAddSupplierDialogOpen}>
                                  <DialogTrigger asChild>
                                    <Button type="button" variant="outline" size="icon" aria-label="Add new supplier">
                                      <Truck className="h-4 w-4" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent>
                                    <DialogHeader><DialogTitle>Add New Supplier</DialogTitle></DialogHeader>
                                    <Form {...addSupplierForm}>
                                      <form onSubmit={addSupplierForm.handleSubmit(onAddSupplierSubmit)} className="space-y-4">
                                        <FormField control={addSupplierForm.control} name="name" render={({ field }) => (
                                            <FormItem><FormLabel>Supplier Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                                        )} />
                                        <FormField control={addSupplierForm.control} name="phone" render={({ field }) => (
                                            <FormItem><FormLabel>Phone</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                                        )} />
                                        <FormField control={addSupplierForm.control} name="email" render={({ field }) => (
                                            <FormItem><FormLabel>Email (Optional)</FormLabel><FormControl><Input type="email" {...field} /></FormControl><FormMessage /></FormItem>
                                        )} />
                                        <FormField control={addSupplierForm.control} name="address" render={({ field }) => (
                                            <FormItem><FormLabel>Address (Optional)</FormLabel><FormControl><Textarea {...field} /></FormControl><FormMessage /></FormItem>
                                        )} />
                                        <DialogFooter>
                                          <DialogClose asChild><Button type="button" variant="ghost">Cancel</Button></DialogClose>
                                          <Button type="submit">Save Supplier</Button>
                                        </DialogFooter>
                                      </form>
                                    </Form>
                                  </DialogContent>
                                </Dialog>
                              </div>
                              <FormMessage />
                            </FormItem>
                          )} />

                          <FormField control={form.control} name="invoiceNumber" render={({ field }) => (
                            <FormItem><FormLabel>Invoice Number</FormLabel><FormControl><Input {...field} value={field.value || ''} placeholder="e.g., INV-12345" /></FormControl><FormMessage /></FormItem>
                          )} />
                           <FormField control={form.control} name="purchaseDate" render={({ field }) => (
                            <FormItem className="flex flex-col"><FormLabel>Invoice/Purchase Date</FormLabel>
                              <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
                                <PopoverTrigger asChild>
                                  <Button variant="outline" className={cn("justify-start text-left font-normal", !field.value && "text-muted-foreground")}>
                                    <CalendarIcon className="mr-2 h-4 w-4" />{field.value ? format(field.value, 'P') : <span>Select a date</span>}
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0">
                                  <Calendar 
                                    mode="single" 
                                    selected={field.value} 
                                    onSelect={(date) => {
                                      field.onChange(date);
                                      setIsCalendarOpen(false);
                                    }} 
                                    initialFocus 
                                  />
                                </PopoverContent>
                              </Popover>
                            <FormMessage /></FormItem>
                          )} />
                        </>
                      )}
                      
                      {operationType === 'damaged' && (
                          <FormField control={form.control} name="linkedPurchaseId" render={({ field }) => (
                            <FormItem>
                              <FormLabel>Link to Purchase Invoice (Optional)</FormLabel>
                               <Select onValueChange={field.onChange} defaultValue={field.value || ''} disabled={purchaseOperations.length === 0}>
                                <FormControl><SelectTrigger><SelectValue placeholder="Select an invoice..." /></SelectTrigger></FormControl>
                                <SelectContent>
                                  {purchaseOperations.length > 0 ? purchaseOperations.map(op => (
                                    <SelectItem key={op.id} value={op.id}>
                                      {op.invoice_number || `Purchase on ${format(new Date(op.created_at), 'P')}`} ({op.item_name})
                                    </SelectItem>
                                  )) : <div className="p-4 text-sm text-muted-foreground">No previous purchases found.</div>}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )} />
                      )}

                      <FormField control={form.control} name="quantity" render={({ field }) => (
                        <FormItem><FormLabel>Quantity</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                    </>
                  )}
                  
                  <FormField control={form.control} name="comment" render={({ field }) => (
                    <FormItem><FormLabel>Comment (Optional)</FormLabel><FormControl><Textarea {...field} value={field.value || ''} placeholder="Add any relevant notes..." /></FormControl><FormMessage /></FormItem>
                  )} />

                  <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? <LoadingSpinner className="mr-2" size={16} /> : null}
                    Log Operation
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row justify-between items-start gap-2">
                <div>
                  <CardTitle>Operations Log</CardTitle>
                  <CardDescription>A record of all purchases, returns, and damages.</CardDescription>
                </div>
                <div className="flex gap-2 w-full sm:w-auto">
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-full sm:w-[180px]"><SelectValue placeholder="Filter by type..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="purchase">Purchase</SelectItem>
                      <SelectItem value="return">Return to Supplier</SelectItem>
                      <SelectItem value="damaged">Damaged</SelectItem>
                    </SelectContent>
                  </Select>
                   <Button 
                      variant="outline"
                      onClick={handleDownloadReport} 
                      disabled={(filteredOperations.length === 0 && !isLoading) || isDownloading}
                      className="w-full sm:w-auto"
                  >
                      {isDownloading ? <LoadingSpinner size={16} className="mr-2"/> : <Download className="mr-2 h-4 w-4" />}
                      Download PDF
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="h-96 flex items-center justify-center"><LoadingSpinner size={32} /></div>
              ) : filteredOperations.length === 0 ? (
                <div className="h-96">
                  <EmptyState IconComponent={ListChecks} title="No Operations Logged" description="Use the form to log your first operation." />
                </div>
              ) : (
                <div className="h-96 overflow-auto">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm min-w-[600px]">
                      <thead>
                        <tr className="border-b">
                          <th className="p-2 text-left font-semibold">Item Name</th>
                          <th className="p-2 text-left font-semibold">Warehouse</th>
                          <th className="p-2 text-left font-semibold">Supplier</th>
                          <th className="p-2 text-center font-semibold">Operation Type</th>
                          <th className="p-2 text-center font-semibold">Quantity</th>
                          <th className="p-2 text-left font-semibold">User Name</th>
                          <th className="p-2 text-left font-semibold">Date</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredOperations.map(op => (
                          <tr key={op.id} className="border-b">
                            <td className="p-2">{op.item_name}</td>
                            <td className="p-2">{op.warehouse_name}</td>
                            <td className="p-2">{op.supplier_name || 'N/A'}</td>
                            <td className="p-2 text-center">
                              <span className={cn('px-2 py-0.5 rounded-full text-xs capitalize', 
                                op.type === 'purchase' ? 'bg-blue-100 text-blue-800' :
                                op.type === 'return' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-red-100 text-red-800'
                              )}>
                                {op.type}
                              </span>
                            </td>
                            <td className="p-2 text-center">{op.quantity}</td>
                            <td className="p-2">{op.user_name}</td>
                            <td className="p-2 text-muted-foreground">{formatDistanceToNow(new Date(op.created_at), { addSuffix: true })}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
