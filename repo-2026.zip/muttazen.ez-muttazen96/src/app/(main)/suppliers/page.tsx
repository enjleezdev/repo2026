
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { format } from 'date-fns';
import { createClient } from '@/lib/supabase';
import type { User } from '@supabase/supabase-js';
import { useRouter } from 'next/navigation';

import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Truck, PlusCircle, Trash2, Edit, Search } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { EmptyState } from '@/components/EmptyState';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import type { Supplier } from '@/lib/types';
import { useLanguage } from '@/contexts/LanguageContext';
import { cn } from '@/lib/utils';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";


export default function SuppliersPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { t } = useLanguage();
  const supabase = createClient();
  
  const supplierFormSchema = z.object({
    name: z.string().min(2, { message: t('supplierNameLengthError') }),
    phone: z.string().min(1, { message: t('supplierPhoneRequired') }),
    email: z.string().email({ message: t('supplierEmailInvalid') }).optional().or(z.literal('')),
    address: z.string().optional(),
  });
  
  type SupplierFormValues = z.infer<typeof supplierFormSchema>;

  const [suppliers, setSuppliers] = React.useState<Supplier[]>([]);
  const [filteredSuppliers, setFilteredSuppliers] = React.useState<Supplier[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [dialogMode, setDialogMode] = React.useState<'add' | 'edit'>('add');
  const [selectedSupplier, setSelectedSupplier] = React.useState<Supplier | null>(null);
  const [supplierToArchive, setSupplierToArchive] = React.useState<Supplier | null>(null);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [currentUser, setCurrentUser] = React.useState<User | null>(null);

  const form = useForm<SupplierFormValues>({
    resolver: zodResolver(supplierFormSchema),
  });

  const loadSuppliers = React.useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      router.push('/signin');
      return;
    }
    setCurrentUser(user);
    setIsLoading(true);

    try {
      const { data, error } = await supabase
        .from('suppliers')
        .select('*')
        .eq('is_archived', false)
        .order('name', { ascending: true });
      if (error) throw error;
      setSuppliers(data as Supplier[]);
      setFilteredSuppliers(data as Supplier[]);
    } catch (error: any) {
      toast({ title: t('error'), description: error.message, variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  }, [supabase, router, t, toast]);

  React.useEffect(() => {
    loadSuppliers();
  }, [loadSuppliers]);
  
  React.useEffect(() => {
    const results = suppliers.filter(supplier =>
      supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      supplier.phone.includes(searchTerm)
    );
    setFilteredSuppliers(results);
  }, [searchTerm, suppliers]);

  const handleOpenDialog = (mode: 'add' | 'edit', supplier: Supplier | null = null) => {
    setDialogMode(mode);
    setSelectedSupplier(supplier);
    form.reset(
      mode === 'edit' && supplier
        ? {
            name: supplier.name,
            phone: supplier.phone,
            email: supplier.email || '',
            address: supplier.address || '',
          }
        : {
            name: '',
            phone: '',
            email: '',
            address: '',
          }
    );
    setIsDialogOpen(true);
  };

  const onSubmit = async (data: SupplierFormValues) => {
    if (!currentUser) return;
    setIsSubmitting(true);
    
    // Construct data to be inserted/updated, ensuring optional fields are handled
    const submissionData = {
      name: data.name,
      phone: data.phone,
      email: data.email || null, // Set to null if empty
      address: data.address || null, // Set to null if empty
    };

    try {
      if (dialogMode === 'edit' && selectedSupplier) {
        // Update
        const { error } = await supabase.from('suppliers').update(submissionData).eq('id', selectedSupplier.id);
        if (error) throw error;
        toast({ title: t('supplierUpdated'), description: t('supplierUpdatedSuccess', data.name) });
      } else {
        // Add
        const { error } = await supabase.from('suppliers').insert({ ...submissionData, owner_id: currentUser.id });
        if (error) throw error;
        toast({ title: t('supplierAdded'), description: t('supplierAddedSuccess', data.name) });
      }
      setIsDialogOpen(false);
      loadSuppliers();
    } catch (error: any) {
      toast({ title: t('error'), description: error.message, variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleArchiveSupplier = async () => {
    if (!supplierToArchive) return;
    try {
      const { error } = await supabase.from('suppliers').update({ is_archived: true }).eq('id', supplierToArchive.id);
      if (error) throw error;
      toast({ title: t('supplierArchived'), description: t('supplierArchivedSuccess', supplierToArchive.name) });
      setSupplierToArchive(null);
      loadSuppliers();
    } catch (error: any) {
      toast({ title: t('error'), description: error.message, variant: 'destructive' });
    }
  };

  return (
    <AlertDialog>
      <PageHeader
        title={t('suppliersTitle')}
        description={t('suppliersDescription')}
        actions={
          <div className="flex w-full flex-col sm:max-w-xs gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder={t('searchSuppliers')}
                className="w-full pl-8 h-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button onClick={() => handleOpenDialog('add')} className="w-full">
              <PlusCircle className="mr-2 h-4 w-4" />
              {t('addNewSupplier')}
            </Button>
          </div>
        }
      />
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex justify-center items-center h-[400px]">
              <LoadingSpinner size={48} />
            </div>
          ) : filteredSuppliers.length === 0 ? (
            <div className="p-6">
              <EmptyState
                IconComponent={Truck}
                title={searchTerm ? t('noSuppliersFound') : t('noActiveSuppliers')}
                description={searchTerm ? t('searchSuppliersNoMatch', searchTerm) : t('noActiveSuppliersDesc')}
                action={!searchTerm ? {
                  label: t('addSupplierAction'),
                  onClick: () => handleOpenDialog('add'),
                  icon: PlusCircle,
                } : undefined}
              />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t('supplierName')}</TableHead>
                    <TableHead>{t('phone')}</TableHead>
                    <TableHead>{t('email')}</TableHead>
                    <TableHead className="text-right">{t('actions')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSuppliers.map((supplier) => (
                    <TableRow key={supplier.id}>
                      <TableCell className="font-medium">{supplier.name}</TableCell>
                      <TableCell>{supplier.phone}</TableCell>
                      <TableCell>{supplier.email || 'N/A'}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => handleOpenDialog('edit', supplier)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <AlertDialogTrigger asChild>
                           <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => setSupplierToArchive(supplier)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{dialogMode === 'edit' ? t('editSupplierTitle') : t('addSupplierTitle')}</DialogTitle>
            <DialogDescription>{dialogMode === 'edit' ? t('editSupplierDesc') : t('addSupplierDesc')}</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="name" render={({ field }) => (
                <FormItem><FormLabel>{t('supplierName')}</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="phone" render={({ field }) => (
                <FormItem><FormLabel>{t('phone')}</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="email" render={({ field }) => (
                <FormItem><FormLabel>{t('emailOptional')}</FormLabel><FormControl><Input type="email" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="address" render={({ field }) => (
                <FormItem><FormLabel>{t('addressOptional')}</FormLabel><FormControl><Textarea {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <DialogFooter>
                <DialogClose asChild><Button type="button" variant="outline">{t('cancel')}</Button></DialogClose>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting && <LoadingSpinner className="mr-2" size={16}/>}
                  {t('save')}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Archive Alert Dialog */}
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{t('archiveSupplierTitle', supplierToArchive?.name || '')}</AlertDialogTitle>
          <AlertDialogDescription>{t('archiveSupplierDesc')}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={() => setSupplierToArchive(null)}>{t('cancel')}</AlertDialogCancel>
          <AlertDialogAction onClick={handleArchiveSupplier} className="bg-destructive hover:bg-destructive/90">{t('archive')}</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
