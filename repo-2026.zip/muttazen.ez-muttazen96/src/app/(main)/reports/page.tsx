// src/app/(main)/reports/page.tsx
'use client';

import { useEffect, useMemo, useState, useRef, useCallback } from 'react';
import { format } from 'date-fns';
import { ar, enUS } from 'date-fns/locale';
import { Calendar as CalendarIcon, Download } from 'lucide-react';
import html2pdf from 'html2pdf.js';
import { useRouter } from 'next/navigation';
import { renderToStaticMarkup } from 'react-dom/server';


import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import PrintableTransactionsReport from '@/components/PrintableTransactionsReport';
import { Calendar } from '@/components/ui/calendar';
import type { HistoryEntry, Item, Warehouse, UserProfile } from '@/lib/types';
import { useLanguage } from '@/contexts/LanguageContext';
import { useToast } from '@/hooks/use-toast';
import { translations, TranslationKey } from '@/lib/translations';
import { createClient } from '@/lib/supabase';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { cn } from '@/lib/utils';
import type { User } from '@supabase/supabase-js';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";


// Define a unified type for all transactions/operations
interface UnifiedOperation extends HistoryEntry {
  itemId: string;
  warehouseId: string;
  itemName: string;
  warehouseName: string;
}

export default function ReportsPage() {
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [history, setHistory] = useState<UnifiedOperation[]>([]);
  const { language, t } = useLanguage();
  const [isLoading, setIsLoading] = useState(true);
  const [isDownloading, setIsDownloading] = useState(false);
  const supabase = createClient();
  const router = useRouter();
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  const [selectedWarehouse, setSelectedWarehouse] = useState<string>('');
  const [selectedItem, setSelectedItem] = useState<string>('');
  const [dateRange, setDateRange] = useState<{ from?: Date; to?: Date }>({});
  
  const { toast } = useToast();

  const checkUserAndLoad = useCallback(async () => {
    setIsLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      router.push('/signin');
      return;
    }
    
    const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single();
    setUserProfile(profile as UserProfile);

    try {
        const { data, error } = await supabase.rpc('get_all_operations_in_range', {
          start_date: '1970-01-01T00:00:00Z', 
          end_date: new Date().toISOString()
        });

        if (error) {
          console.error("RPC Error:", error);
          throw error;
        }

        const { data: whData, error: whError } = await supabase.from('warehouses').select('id, name').eq('is_archived', false);
        if(whError) throw whError;
        setWarehouses(whData || []);

        const { data: itemData, error: itemError } = await supabase.from('items').select('id, name, warehouse_id').eq('is_archived', false);
        if(itemError) throw itemError;
        setItems(itemData || []);

        setHistory(data as UnifiedOperation[]);

    } catch (error) {
      console.error("Error loading report data:", error);
      toast({ title: t('error'), description: 'Failed to load report data.' });
    } finally {
      setIsLoading(false);
    }
  }, [supabase, router, t, toast]);

  useEffect(() => {
    checkUserAndLoad();
  }, [checkUserAndLoad]);


  const itemsInSelectedWarehouse = useMemo(() => {
    if (!selectedWarehouse) return items;
    return items.filter((item) => item.warehouse_id === selectedWarehouse);
  }, [selectedWarehouse, items]);

  useEffect(() => {
    if (selectedWarehouse) {
      setSelectedItem('');
    }
  }, [selectedWarehouse]);

  const filteredHistory = useMemo(() => {
    return history.filter((entry) => {
      const matchWarehouse = !selectedWarehouse || entry.warehouseId === selectedWarehouse;
      const matchItem = !selectedItem || entry.itemId === selectedItem;
      const entryDate = new Date(entry.timestamp);
      const matchDate =
        (!dateRange.from || entryDate >= dateRange.from) &&
        (!dateRange.to || entryDate <= dateRange.to);
      return matchWarehouse && matchItem && matchDate;
    }).sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [history, selectedWarehouse, selectedItem, dateRange]);

  const handleResetFilters = () => {
    setSelectedWarehouse('');
    setSelectedItem('');
    setDateRange({});
  };
  
  const t_report = (key: TranslationKey, ...args: (string | number)[]): string => {
      let translation = translations['en'][key] || key;
      if (args.length > 0) {
          args.forEach((arg, index) => {
              translation = translation.replace(`{${index}}`, String(arg));
          });
      }
      return translation;
  };

  const handleDownloadPdf = () => {
    if (filteredHistory.length === 0) {
      toast({ title: t('noTransactionsFound'), description: t('tryAdjustingFilters'), variant: "default" });
      return;
    }
    
    setIsDownloading(true);
    
    const htmlString = renderToStaticMarkup(
      <PrintableTransactionsReport
        filteredHistory={filteredHistory}
        warehouses={warehouses}
        items={items}
        printedBy={userProfile?.username || "System User"}
        printDate={new Date()}
        t={t_report}
      />
    );
  
    const container = document.createElement('div');
    container.innerHTML = htmlString;
    document.body.appendChild(container);
  
    html2pdf()
      .from(container)
      .set({
        margin: [15, 15, 15, 15],
        filename: `Transactions-Report-${format(new Date(), 'yyyy-MM-dd')}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, logging: false },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
      })
      .save()
      .then(() => {
        document.body.removeChild(container);
        setIsDownloading(false);
      })
      .catch((err) => {
        console.error("Failed to generate PDF", err);
        document.body.removeChild(container);
        setIsDownloading(false);
        toast({ title: 'Error', description: 'Failed to generate PDF.', variant: 'destructive'});
      });
  };

  const translateHistoryType = (type: string) => {
      return type.replace(/_/g, ' ');
  };


  return (
    <>
      <div className="space-y-4">
        <PageHeader
          title={t('reportsTitle')}
          description={t('reportsDescription')}
          actions={
            <Button disabled={filteredHistory.length === 0 || isDownloading} onClick={handleDownloadPdf}>
              {isDownloading ? <LoadingSpinner size={16} className="mr-2" /> : <Download className="mr-2 h-4 w-4" />}
              {t('printFilteredReport')}
            </Button>
          }
        />

        <Card>
          <CardHeader>
            <CardTitle>{t('filterTransactions')}</CardTitle>
            <CardDescription>{t('filterTransactionsDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Select onValueChange={setSelectedWarehouse} value={selectedWarehouse}>
                <SelectTrigger>
                  <SelectValue placeholder={t('allWarehouses')} />
                </SelectTrigger>
                <SelectContent>
                  {warehouses.map((w) => (
                    <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select onValueChange={setSelectedItem} value={selectedItem}>
                <SelectTrigger>
                  <SelectValue placeholder={selectedWarehouse ? t('report_item_filter_placeholder_in_wh') : t('report_item_filter_placeholder_all_wh')} />
                </SelectTrigger>
                <SelectContent>
                  {itemsInSelectedWarehouse.map((i) => (
                    <SelectItem key={i.id} value={i.id}>{i.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateRange.from ? format(dateRange.from, 'PPP', { locale: language === 'ar' ? ar : enUS }) : <span>{t('report_start_date')}</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={dateRange.from}
                    onSelect={(day) => setDateRange((prev) => ({ ...prev, from: day }))}
                    disabled={(date) => date > (dateRange.to || new Date()) || date < new Date('1900-01-01')}
                    initialFocus
                    captionLayout="dropdown-buttons"
                    fromYear={2020}
                    toYear={new Date().getFullYear() + 1}
                  />
                </PopoverContent>
              </Popover>

              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateRange.to ? format(dateRange.to, 'PPP', { locale: language === 'ar' ? ar : enUS }) : <span>{t('report_end_date')}</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={dateRange.to}
                    onSelect={(day) => setDateRange((prev) => ({ ...prev, to: day }))}
                    disabled={(date) => date < (dateRange.from || new Date('1900-01-01'))}
                    initialFocus
                    captionLayout="dropdown-buttons"
                    fromYear={2020}
                    toYear={new Date().getFullYear() + 1}
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="mt-4 text-end">
              <Button variant="ghost" onClick={handleResetFilters}>{t('resetFilters')}</Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t('allTransactions')}</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center items-center h-64"><LoadingSpinner size={32} /></div>
            ) : filteredHistory.length === 0 ? (
              <div className="text-center text-muted-foreground py-10">{t('noTransactionsFound')}</div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50 dark:bg-muted/20">
                      <TableHead className="py-2 px-1 md:px-2">
                        <div className="font-bold">Item Name / Warehouse</div>
                      </TableHead>
                      <TableHead className="py-2 px-1 md:px-2">Date</TableHead>
                      <TableHead className="py-2 px-1 md:px-2">Type</TableHead>
                      <TableHead className="py-2 px-1 md:px-2">Quantity</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredHistory.map((h, index) => (
                      <TableRow key={`${h.id}-${index}`}>
                        <TableCell className="py-2 px-1 md:px-2 align-top">
                          <div className="font-medium text-xs md:text-sm">{h.itemName || 'N/A'}</div>
                          <div className="text-xs text-muted-foreground">{h.warehouseName || 'N/A'}</div>
                        </TableCell>
                        <TableCell className="py-2 px-1 md:px-2 align-top">
                          <div className="text-xs md:text-sm">{format(new Date(h.timestamp), 'yyyy-MM-dd')}</div>
                          <div className="text-xs text-muted-foreground">{format(new Date(h.timestamp), 'p')}</div>
                        </TableCell>
                        <TableCell className="py-2 px-1 md:px-2 align-top text-xs md:text-sm">{translateHistoryType(h.type)}</TableCell>
                        <TableCell className="py-2 px-1 md:px-2 align-top text-xs md:text-sm">
                          <div className="space-y-0.5">
                            <div className={cn('font-bold', h.change > 0 ? 'text-green-600' : 'text-red-600')}>
                              Change: {h.change > 0 ? `+${h.change}` : h.change}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              Before: {h.quantityBefore}
                            </div>
                            <div className="text-xs font-semibold">
                              After: {h.quantityAfter}
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
