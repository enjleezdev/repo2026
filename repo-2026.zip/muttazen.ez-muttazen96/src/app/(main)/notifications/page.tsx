
'use client';

import * as React from 'react';
import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCheck, Bell, BellOff, AlertTriangle, Info, BellRing } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Notification } from '@/lib/types';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { EmptyState } from '@/components/EmptyState';
import { formatDistanceToNow } from 'date-fns';
import { createClient } from '@/lib/supabase';
import type { User } from '@supabase/supabase-js';
import { useRouter } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useLanguage } from '@/contexts/LanguageContext';

const getNotificationIcon = (type: Notification['type']) => {
  switch (type) {
    case 'LOW_STOCK':
      return <AlertTriangle className="h-5 w-5 text-destructive" />;
    case 'SUCCESS':
      return <CheckCheck className="h-5 w-5 text-green-600" />;
    case 'INFO':
      return <Info className="h-5 w-5 text-blue-600" />;
    case 'AI_SUGGESTION':
      return <BellRing className="h-5 w-5 text-primary" />;
    default:
      return <Bell className="h-5 w-5 text-muted-foreground" />;
  }
};

export default function NotificationsPage() {
  const { toast } = useToast();
  const router = useRouter();
  const { t } = useLanguage();
  const [notifications, setNotifications] = React.useState<Notification[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const supabase = createClient();
  const [currentUser, setCurrentUser] = React.useState<User | null>(null);

  const loadNotifications = React.useCallback(async () => {
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      router.push('/signin');
      return;
    }
    setCurrentUser(user);
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setNotifications(data as Notification[]);

    } catch (error: any) {
      console.error("Failed to load notifications from Supabase", error);
      toast({ title: t('error'), description: error.message || "Failed to load notifications.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }, [toast, supabase, router, t]);

  React.useEffect(() => {
    loadNotifications();
  }, [loadNotifications]);

  const handleMarkAllAsRead = async () => {
    if (!currentUser) return;
    const unreadIds = notifications.filter(n => !n.is_read).map(n => n.id);
    if (unreadIds.length === 0) {
        toast({ title: t('noUnreadNotifications') });
        return;
    }
    
    try {
        const { error } = await supabase
            .from('notifications')
            .update({ is_read: true })
            .in('id', unreadIds);
        if (error) throw error;
        toast({ title: t('success'), description: t('allNotificationsMarkedRead') });
        loadNotifications();
    } catch(error: any) {
        toast({ title: t('error'), description: error.message || "Could not mark all as read.", variant: "destructive" });
    }
  };
  
  const handleClearAll = async () => {
    if (!currentUser) return;
     if (notifications.length === 0) {
        toast({ title: t('noNotificationsToClear') });
        return;
    }
    try {
        const { error } = await supabase
            .from('notifications')
            .delete()
            .eq('owner_id', currentUser.id);
        if (error) throw error;
        toast({ title: t('success'), description: t('allNotificationsCleared') });
        loadNotifications();
    } catch(error: any) {
        toast({ title: t('error'), description: error.message || "Could not clear notifications.", variant: "destructive" });
    }
  };


  return (
    <TooltipProvider>
      <PageHeader
        title={t('notificationsTitle')}
        description={t('notificationsDescription')}
        actions={
            !isLoading && notifications.length > 0 ? (
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleMarkAllAsRead}>
                <CheckCheck className="mr-2 h-4 w-4" /> {t('markAllAsRead')}
              </Button>
               <Button variant="destructive" onClick={handleClearAll}>
                <BellOff className="mr-2 h-4 w-4" /> {t('clearAll')}
              </Button>
            </div>
            ) : null
        }
      />
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex justify-center items-center h-[400px]">
              <LoadingSpinner size={48} />
            </div>
          ) : notifications.length === 0 ? (
            <div className="p-6">
                <EmptyState
                    IconComponent={BellOff}
                    title={t('noNotificationsYet')}
                    description={t('noNotificationsDesc')}
                />
            </div>
          ) : (
            <ul className="divide-y">
              {notifications.map((notif) => (
                <li key={notif.id} className={cn(
                    "flex items-start gap-4 p-4",
                    !notif.is_read && "bg-primary/5"
                )}>
                  <div className="mt-1">
                    {getNotificationIcon(notif.type)}
                  </div>
                  <div className="flex-1">
                    <p className={cn(
                        "font-semibold",
                        !notif.is_read && "text-foreground"
                    )}>
                        {notif.title}
                    </p>
                    <p className="text-sm text-muted-foreground">{notif.message}</p>
                  </div>
                  <div className="text-right">
                     <Tooltip>
                        <TooltipTrigger asChild>
                           <p className="text-xs text-muted-foreground whitespace-nowrap">
                                {formatDistanceToNow(new Date(notif.created_at), { addSuffix: true })}
                           </p>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>{new Date(notif.created_at).toLocaleString()}</p>
                        </TooltipContent>
                      </Tooltip>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </TooltipProvider>
  );
}
