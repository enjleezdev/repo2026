
// src/app/(main)/forecasting/page.tsx
'use client';

import * as React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Brain, Lightbulb, LineChart, AlertTriangle, TrendingUp, TrendingDown, Package, Warehouse as WarehouseIcon } from 'lucide-react';
import type { Item, Warehouse } from '@/lib/types';
import { forecastDemand } from '@/ai/flows/demand-forecasting';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { createClient } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/contexts/LanguageContext';

// Define types locally since they are not exported from the 'use server' file
export interface DemandForecastInput {
  itemName: string;
  currentStock: number;
  forecastPeriod: number;
  historicalData: string;
}

export interface DemandForecastOutput {
  forecastPeriod: number;
  predictedDemand: number;
  confidenceLevel: string;
  trendAnalysis: string;
  reorderRecommendation: string;
  riskAlert?: string;
}


const forecastingFormSchema = z.object({
  warehouseId: z.string().min(1, { message: 'الرجاء اختيار مستودع.' }),
  itemId: z.string().min(1, { message: 'الرجاء اختيار عنصر.' }),
  forecastPeriod: z.coerce.number().int().positive(),
});

type ForecastingFormValues = z.infer<typeof forecastingFormSchema>;

export default function ForecastingPage() {
  const { toast } = useToast();
  const router = useRouter();
  const { t } = useLanguage();
  const [warehouses, setWarehouses] = React.useState<Warehouse[]>([]);
  const [allItems, setAllItems] = React.useState<Item[]>([]);
  const [itemsInSelectedWarehouse, setItemsInSelectedWarehouse] = React.useState<Item[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);
  const [isLoadingData, setIsLoadingData] = React.useState(true);
  const [forecastResult, setForecastResult] = React.useState<DemandForecastOutput | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const supabase = createClient();
  
  const form = useForm<ForecastingFormValues>({
    resolver: zodResolver(forecastingFormSchema),
    defaultValues: {
      warehouseId: '',
      itemId: '',
      forecastPeriod: 30,
    },
  });

  const selectedWarehouseId = form.watch('warehouseId');

  React.useEffect(() => {
    async function loadInitialData() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/signin');
        return;
      }
      setIsLoadingData(true);

      try {
        const { data: whData, error: whError } = await supabase.from('warehouses').select('*').eq('is_archived', false);
        if (whError) throw whError;
        setWarehouses(whData as Warehouse[]);

        const { data: itemData, error: itemError } = await supabase.from('items').select('*').eq('is_archived', false);
        if (itemError) throw itemError;
        setAllItems(itemData.map(item => ({...item, history: item.history || []})) as Item[]);

      } catch (err: any) {
        setError(err.message || "Failed to load warehouse/item data.");
      } finally {
        setIsLoadingData(false);
      }
    }
    loadInitialData();
  }, [supabase, router]);

  React.useEffect(() => {
    if (selectedWarehouseId) {
      const filteredItems = allItems.filter(item => item.warehouse_id === selectedWarehouseId);
      setItemsInSelectedWarehouse(filteredItems);
      form.setValue('itemId', '');
    } else {
      setItemsInSelectedWarehouse([]);
    }
  }, [selectedWarehouseId, allItems, form]);

  async function onSubmit(data: ForecastingFormValues) {
    setIsLoading(true);
    setForecastResult(null);
    setError(null);
    try {
      const selectedItem = itemsInSelectedWarehouse.find(item => item.id === data.itemId);
      if (!selectedItem) {
        setError("لم يتم العثور على العنصر المختار.");
        setIsLoading(false);
        return;
      }
      
      const historicalDataSummary = selectedItem.history
        ?.filter(h => ['CONSUME_STOCK', 'ADD_STOCK'].includes(h.type))
        .slice(-50) // Use last 50 transactions as a sample
        .map(h => ({ date: h.timestamp, type: h.type, change: h.change })) || [];

      const input: DemandForecastInput = {
        itemName: selectedItem.name,
        currentStock: selectedItem.quantity,
        forecastPeriod: data.forecastPeriod,
        historicalData: JSON.stringify(historicalDataSummary),
      };

      const result = await forecastDemand(input);
      setForecastResult(result);

    } catch (err) {
      console.error("Error getting forecast:", err);
      const errorMessage = err instanceof Error ? err.message : "حدث خطأ غير متوقع.";
      setError(errorMessage);
      toast({ title: "خطأ في التنبؤ", description: errorMessage, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <>
      <PageHeader
        title="نظام التنبؤ الذكي بالطلب"
        description="استخدم الذكاء الاصطناعي لتحليل البيانات وتوقع الطلب المستقبلي."
      />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
            <Card>
                <CardHeader>
                    <CardTitle>تحليل التنبؤ</CardTitle>
                    <CardDescription>اختر عنصراً لتوقع الطلب عليه.</CardDescription>
                </CardHeader>
                <CardContent>
                    {isLoadingData ? <LoadingSpinner /> : (
                    <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                        control={form.control}
                        name="warehouseId"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>المستودع</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                <SelectTrigger><SelectValue placeholder="اختر مستودعاً" /></SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                {warehouses.map(wh => (
                                    <SelectItem key={wh.id} value={wh.id}>{wh.name}</SelectItem>
                                ))}
                                </SelectContent>
                            </Select>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                        <FormField
                        control={form.control}
                        name="itemId"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>العنصر</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value} disabled={!selectedWarehouseId || itemsInSelectedWarehouse.length === 0}>
                                <FormControl>
                                <SelectTrigger><SelectValue placeholder="اختر عنصراً" /></SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                {itemsInSelectedWarehouse.map(item => (
                                    <SelectItem key={item.id} value={item.id}>{item.name} (المتوفر: {item.quantity})</SelectItem>
                                ))}
                                </SelectContent>
                            </Select>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                        <FormField
                        control={form.control}
                        name="forecastPeriod"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>فترة التنبؤ (بالأيام)</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={String(field.value)}>
                                <FormControl>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    <SelectItem value="30">30 يوم</SelectItem>
                                    <SelectItem value="60">60 يوم</SelectItem>
                                    <SelectItem value="90">90 يوم</SelectItem>
                                </SelectContent>
                            </Select>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                        <Button type="submit" disabled={isLoading} className="w-full">
                        {isLoading ? <LoadingSpinner size={16} className="ml-2" /> : <Brain className="ml-2 h-4 w-4" />}
                        تنبؤ بالطلب
                        </Button>
                    </form>
                    </Form>
                    )}
                </CardContent>
            </Card>
        </div>

        <div className="md:col-span-2">
            <Card className="h-full">
            <CardHeader>
                <CardTitle>نتائج التنبؤ</CardTitle>
                <CardDescription>ستظهر هنا تحليلات وتوصيات الذكاء الاصطناعي.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center min-h-[400px]">
                {isLoading && <LoadingSpinner size={32} />}
                {!isLoading && error && (
                <div className="text-center text-destructive">
                    <AlertTriangle className="mx-auto h-12 w-12 mb-2" />
                    <p className="font-semibold">حدث خطأ</p>
                    <p className="text-sm">{error}</p>
                </div>
                )}
                {!isLoading && !error && forecastResult && (
                <div className="space-y-6 w-full text-right">
                    <div className="p-4 bg-primary/10 rounded-lg text-center">
                        <p className="text-sm font-medium text-primary">الطلب المتوقع خلال {forecastResult.forecastPeriod} يوم</p>
                        <p className="text-3xl font-bold text-primary">{forecastResult.predictedDemand.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">{forecastResult.confidenceLevel}</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <Card>
                            <CardHeader className="pb-2">
                                <CardTitle className="text-base flex items-center"><TrendingUp className="ml-2 h-5 w-5 text-green-500" /> تحليل الاتجاه</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-sm text-muted-foreground">{forecastResult.trendAnalysis}</p>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardHeader className="pb-2">
                                <CardTitle className="text-base flex items-center"><Package className="ml-2 h-5 w-5 text-blue-500" /> توصيات المخزون</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-sm text-muted-foreground">{forecastResult.reorderRecommendation}</p>
                            </CardContent>
                        </Card>
                    </div>
                    
                    {forecastResult.riskAlert && (
                         <Card className="border-amber-500 bg-amber-50">
                            <CardHeader className="pb-2">
                                <CardTitle className="text-base flex items-center text-amber-700"><AlertTriangle className="ml-2 h-5 w-5" /> تنبيه المخاطر</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-sm text-amber-800">{forecastResult.riskAlert}</p>
                            </CardContent>
                        </Card>
                    )}
                </div>
                )}
                {!isLoading && !error && !forecastResult && (
                <div className="text-center text-muted-foreground">
                    <Lightbulb className="mx-auto h-12 w-12 mb-2" />
                    <p>اختر عنصراً من القائمة لبدء التحليل.</p>
                </div>
                )}
            </CardContent>
            </Card>
        </div>
      </div>
    </>
  );
}
