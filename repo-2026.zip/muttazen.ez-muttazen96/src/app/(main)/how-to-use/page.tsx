
'use client';

import * as React from 'react';
import { PageHeader } from '@/components/PageHeader';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import {
  Warehouse,
  PackagePlus,
  PlusCircle,
  MinusCircle,
  History,
  Bot,
  FileText,
  Archive,
  UserCircle,
  Package,
  Search,
  BookOpen,
  HelpCircle as HelpCircleIcon,
  ArrowRightLeft,
  Truck,
  Brain,
  Sparkles
} from 'lucide-react';
import { cn } from '@/lib/utils';
import Link from 'next/link';
import { useLanguage } from '@/contexts/LanguageContext';
import { translations } from '@/lib/translations';

const featureIcons = {
  [translations.en.aiAssistant]: Bot,
  [translations.en.reports]: FileText,
  [translations.en.archive]: Archive,
  [translations.en.profile]: UserCircle,
  [translations.en.inventoryOps]: ArrowRightLeft,
  [translations.en.suppliers]: Truck,
  [translations.en.forecasting]: Brain,

  [translations.ar.aiAssistant]: Bot,
  [translations.ar.reports]: FileText,
  [translations.ar.archive]: Archive,
  [translations.ar.profile]: UserCircle,
  [translations.ar.inventoryOps]: ArrowRightLeft,
  [translations.ar.suppliers]: Truck,
  [translations.ar.forecasting]: Brain,
};


export default function HowToUsePage() {
  const { t, language, dir } = useLanguage();
  const [searchTerm, setSearchTerm] = React.useState('');
  const [openItems, setOpenItems] = React.useState<string[]>([]);
  
  const lowerCaseSearchTerm = searchTerm.toLowerCase();

  const warehouseSteps = [
    { icon: Warehouse, titleKey: "htu_wh_step1_title", descKey: "htu_wh_step1_desc" },
    { icon: PackagePlus, titleKey: "htu_item_step1_title", descKey: "htu_item_step1_desc" },
    { icon: PlusCircle, titleKey: "htu_item_step2_title", descKey: "htu_item_step2_desc" },
    { icon: MinusCircle, titleKey: "htu_item_step3_title", descKey: "htu_item_step3_desc" },
  ];

  const opsSteps = [
    { icon: ArrowRightLeft, titleKey: "htu_ops_step1_title", descKey: "htu_ops_step1_desc" },
    { icon: PlusCircle, titleKey: "htu_ops_step2_title", descKey: "htu_ops_step2_desc" },
    { icon: MinusCircle, titleKey: "htu_ops_step3_title", descKey: "htu_ops_step3_desc" },
    { icon: Package, titleKey: "htu_ops_step4_title", descKey: "htu_ops_step4_desc" },
  ];
  
  const supplierSteps = [
    { icon: Truck, titleKey: "htu_sup_step1_title", descKey: "htu_sup_step1_desc" },
    { icon: PlusCircle, titleKey: "htu_sup_step2_title", descKey: "htu_sup_step2_desc" },
  ];

  const aiSteps = [
    { icon: Bot, titleKey: "htu_ai_step1_title", descKey: "htu_ai_step1_desc" },
    { icon: Brain, titleKey: "htu_ai_step2_title", descKey: "htu_ai_step2_desc" },
  ];
  
  const otherFeatures = [
     { icon: FileText, titleKey: "reports", descKey: "htu_feat_row2_desc" },
     { icon: History, titleKey: "htu_item_step4_title", descKey: "htu_feat_row_history_desc" },
     { icon: Archive, titleKey: "archive", descKey: "htu_feat_row3_desc" },
     { icon: UserCircle, titleKey: "profile", descKey: "htu_feat_row4_desc" },
  ];


  const sections = [
    { id: 'warehouses', titleKey: 'htu_wh_title', icon: Warehouse, steps: warehouseSteps },
    { id: 'operations', titleKey: 'htu_ops_title', icon: ArrowRightLeft, steps: opsSteps },
    { id: 'suppliers', titleKey: 'suppliersTitle', icon: Truck, steps: supplierSteps },
    { id: 'ai', titleKey: 'htu_ai_title', icon: Sparkles, steps: aiSteps },
    { id: 'other', titleKey: 'htu_feat_title', icon: HelpCircleIcon, steps: otherFeatures }
  ];

  const filteredSections = sections.map(section => ({
      ...section,
      steps: section.steps.filter(step =>
          t(step.titleKey as any).toLowerCase().includes(lowerCaseSearchTerm) ||
          t(step.descKey as any).toLowerCase().includes(lowerCaseSearchTerm)
      )
  })).filter(section => section.steps.length > 0);


  React.useEffect(() => {
    if (searchTerm) {
        setOpenItems(filteredSections.map(s => s.id));
    } else {
        setOpenItems([]);
    }
  }, [searchTerm, filteredSections.length]);

  return (
    <div dir={dir}>
      <PageHeader
        title={t('howToUseTitle')}
        description={t('howToUseDescription')}
      >
        <div className="flex w-full flex-col sm:flex-row gap-2 mt-4">
            <div className="relative w-full sm:flex-1">
                <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" style={language === 'ar' ? { left: 'auto', right: '0.75rem' } : {}}/>
                <Input 
                    type="text"
                    placeholder={t('searchFeature')}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className={cn("h-12 text-base", language === 'ar' ? 'pr-11' : 'pl-11')}
                />
            </div>
        </div>
      </PageHeader>

      <div className="space-y-8">
        <Accordion type="multiple" value={openItems} onValueChange={setOpenItems} className="w-full">
            {filteredSections.map(section => (
                <AccordionItem key={section.id} value={section.id}>
                    <AccordionTrigger className="text-xl font-semibold">
                        <div className="flex items-center gap-3">
                            <section.icon className="h-7 w-7 text-primary" /> {t(section.titleKey as any)}
                        </div>
                    </AccordionTrigger>
                    <AccordionContent>
                        <div className="space-y-6 pt-4">
                            {section.steps.map((step, index) => (
                                <div key={index} className="flex items-start gap-4">
                                    <div className="flex-shrink-0">
                                        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                                            <step.icon className="h-7 w-7" />
                                        </div>
                                    </div>
                                    <div>
                                        <h4 className="font-semibold text-lg text-foreground">{t(step.titleKey as any)}</h4>
                                        <p className="text-muted-foreground mt-1 text-base">{t(step.descKey as any)}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </AccordionContent>
                </AccordionItem>
            ))}
        </Accordion>

        {searchTerm && filteredSections.length === 0 && (
            <div className="text-center py-10">
                <p className="text-muted-foreground">{t('noResults')}</p>
            </div>
        )}

        <Card className="bg-primary/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
               <BookOpen className="h-6 w-6" /> {t('htu_conclusion_title')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-base">{t('htu_conclusion_desc')}</p>
            <p className="text-muted-foreground text-base mt-4 italic">{t('htu_conclusion_footer')}</p>
            <div className="mt-4 pt-4 border-t border-border/50 flex items-center gap-2 text-sm text-muted-foreground">
                <HelpCircleIcon className="h-5 w-5" />
                <span>{t('htu_conclusion_help')}</span>
                <Link href="https://enjleez.tech/en" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline font-medium">
                    {t('visitWebsite')}
                </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
