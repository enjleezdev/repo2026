
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Bot, Lightbulb, AlertTriangle, Languages } from 'lucide-react';
import type { Item, Warehouse } from '@/lib/types';
import { stockLevelSuggestions, type StockLevelSuggestionsInput, type StockLevelSuggestionsOutput } from '@/ai/flows/stock-level-suggestions';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { createClient } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useLanguage } from '@/contexts/LanguageContext';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';

export default function EnjleezAIAssistantPage() {
  const { toast } = useToast();
  const router = useRouter();
  const { t, language } = useLanguage();
  const [warehouses, setWarehouses] = React.useState<Warehouse[]>([]);
  const [allItems, setAllItems] = React.useState<Item[]>([]);
  const [itemsInSelectedWarehouse, setItemsInSelectedWarehouse] = React.useState<Item[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);
  const [isLoadingData, setIsLoadingData] = React.useState(true);
  const [suggestionResult, setSuggestionResult] = React.useState<StockLevelSuggestionsOutput & { itemNameAnalyzed?: string } | null>(null);
  const [displayLanguage, setDisplayLanguage] = React.useState<"en" | "ar">(language);
  const [error, setError] = React.useState<string | null>(null);
  const supabase = createClient();
  
  const suggestionFormSchema = z.object({
    warehouseId: z.string().min(1, { message: t('ai_wh_required') }),
    itemId: z.string().min(1, { message: t('ai_item_required') }),
    historicalData: z.string().min(10, { message: t('ai_data_required') }),
  });

  type SuggestionFormValues = z.infer<typeof suggestionFormSchema>;
  
  const form = useForm<SuggestionFormValues>({
    resolver: zodResolver(suggestionFormSchema),
    defaultValues: {
      warehouseId: '',
      itemId: '',
      historicalData: '',
    },
  });

  const selectedWarehouseId = form.watch('warehouseId');

  React.useEffect(() => {
    setDisplayLanguage(language);
  }, [language]);

  React.useEffect(() => {
    async function loadInitialData() {
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/signin');
        return;
      }
      setIsLoadingData(true);

      try {
        const { data: whData, error: whError } = await supabase
          .from('warehouses')
          .select('*')
          .eq('is_archived', false);
        if (whError) throw whError;
        setWarehouses(whData as Warehouse[]);

        const { data: itemData, error: itemError } = await supabase
          .from('items')
          .select('*')
          .eq('is_archived', false);
        if (itemError) throw itemError;
        setAllItems(itemData.map(item => ({...item, history: item.history || []})) as Item[]);

      } catch (err: any) {
        console.error("Failed to load initial data from Supabase", err);
        toast({ title: t("error"), description: err.message || "Failed to load warehouse/item data.", variant: "destructive" });
      } finally {
        setIsLoadingData(false);
      }
    }
    loadInitialData();
  }, [toast, supabase, router, t]);

  React.useEffect(() => {
    if (selectedWarehouseId) {
      const filteredItems = allItems.filter(item => item.warehouse_id === selectedWarehouseId);
      setItemsInSelectedWarehouse(filteredItems);
      form.setValue('itemId', '');
    } else {
      setItemsInSelectedWarehouse([]);
    }
  }, [selectedWarehouseId, allItems, form]);

  async function onSubmit(data: SuggestionFormValues) {
    setIsLoading(true);
    setSuggestionResult(null);
    setError(null);
    try {
      const selectedItem = itemsInSelectedWarehouse.find(item => item.id === data.itemId);
      if (!selectedItem) {
        setError(t('ai_item_not_found'));
        setIsLoading(false);
        return;
      }

      const input: StockLevelSuggestionsInput = {
        itemId: selectedItem.name,
        historicalData: `Item: ${selectedItem.name}. User input: ${data.historicalData}. Current Stock: ${selectedItem.quantity}. Item History (last 5 if available): ${
          selectedItem.history?.slice(-5).map(h =>
            `${h.type.replace('_', ' ')} of ${h.change} on ${new Date(h.timestamp).toLocaleDateString()}. Comment: ${h.comment || 'N/A'}`
          ).join('; ') || 'No detailed history available.'
        }`,
      };

      const result = await stockLevelSuggestions(input);
      setSuggestionResult({...result, itemNameAnalyzed: selectedItem.name});
      setDisplayLanguage(language);

    } catch (err) {
      console.error("Error getting stock suggestion:", err);
      const errorMessage = err instanceof Error ? err.message : t('ai_unexpected_error');
      setError(errorMessage);
      toast({ title: t('ai_error_title'), description: t('ai_error_desc'), variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }
  
  const toggleDisplayLanguage = () => {
    setDisplayLanguage(prev => prev === 'en' ? 'ar' : 'en');
  }

  if (isLoadingData) {
    return <LoadingSpinner className="mx-auto my-10" size={48} />;
  }

  return (
    <TooltipProvider>
      <PageHeader
        title={t('ai_title')}
        description={t('ai_description')}
      >
        <Alert variant="default" className="mt-4">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            {t('ai_disclaimer')}
          </AlertDescription>
        </Alert>
      </PageHeader>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>{t('ai_form_title')}</CardTitle>
            <CardDescription>{t('ai_form_desc')}</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="warehouseId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('warehouse')}</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder={t('ai_select_wh')} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {warehouses.map(wh => (
                            <SelectItem key={wh.id} value={wh.id}>{wh.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="itemId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('itemName')}</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value} disabled={!selectedWarehouseId || itemsInSelectedWarehouse.length === 0}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder={!selectedWarehouseId ? t('ai_select_wh_first') : t('ai_select_item')} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {itemsInSelectedWarehouse.map(item => (
                            <SelectItem key={item.id} value={item.id}>{item.name} ({t('ai_current_stock')}: {item.quantity})</SelectItem>
                          ))}
                           {selectedWarehouseId && itemsInSelectedWarehouse.length === 0 && (
                            <div className="p-4 text-sm text-muted-foreground">{t('ai_no_items_in_wh')}</div>
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="historicalData"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('ai_historical_data')}</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder={t('ai_historical_data_placeholder')}
                          className="resize-y min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={isLoading} className="w-full">
                  {isLoading ? <LoadingSpinner size={16} className="mr-2" /> : <Lightbulb className="mr-2 h-4 w-4" />}
                  {t('ai_get_suggestion')}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>{t('ai_suggestion_title')}</CardTitle>
            <CardDescription>{t('ai_suggestion_desc')}</CardDescription>
          </CardHeader>
          <CardContent className="flex-grow flex flex-col items-center justify-center">
            {isLoading && <LoadingSpinner size={32} />}
            {!isLoading && error && (
              <div className="text-center text-destructive">
                <AlertTriangle className="mx-auto h-12 w-12 mb-2" />
                <p className="font-semibold">{t('error')}</p>
                <p className="text-sm">{error}</p>
              </div>
            )}
            {!isLoading && !error && suggestionResult && (
              <div className="space-y-4 text-center w-full">
                <Lightbulb className="mx-auto h-12 w-12 text-primary mb-2" />
                <p className="text-2xl font-bold text-primary">
                  {t('ai_suggested_stock')}: {suggestionResult.suggestedStockLevel}
                </p>
                <div className="relative text-left space-y-3 bg-muted p-4 rounded-md text-sm">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" onClick={toggleDisplayLanguage} className="absolute top-2 right-2 h-7 w-7">
                        <Languages className="h-4 w-4"/>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent><p>{t('ai_toggle_language')}</p></TooltipContent>
                  </Tooltip>
                  <div dir={displayLanguage === 'ar' ? 'rtl' : 'ltr'}>
                    <strong className="font-medium text-foreground block mb-1">{t('ai_reasoning_label')}:</strong>
                    <p>{suggestionResult.reasoning[displayLanguage]}</p>
                  </div>

                  {suggestionResult.alert && (suggestionResult.alert[displayLanguage]) && (
                    <div dir={displayLanguage === 'ar' ? 'rtl' : 'ltr'} className="text-amber-700 dark:text-amber-500 mt-2">
                       <strong className="font-medium">{t('ai_alert_label')}:</strong> {suggestionResult.alert[displayLanguage]}
                    </div>
                  )}
                </div>
                 <p className="text-xs text-muted-foreground pt-4">
                    {t('ai_item_analyzed')}: {suggestionResult.itemNameAnalyzed || "N/A"}
                </p>
              </div>
            )}
            {!isLoading && !error && !suggestionResult && (
              <div className="text-center text-muted-foreground">
                <Bot className="mx-auto h-12 w-12 mb-2" />
                <p>{t('ai_form_prompt')}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </TooltipProvider>
  );
}
