
'use client'; 

import type { PropsWithChildren } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { Header } from "@/components/Header";
import { SidebarProvider, useSidebar } from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import { useLanguage } from "@/contexts/LanguageContext";

function MainLayoutContent({ children }: PropsWithChildren) {
    const { isMobile, state } = useSidebar();
    const { dir } = useLanguage();
    const [isClient, setIsClient] = useState(false);

    useEffect(() => {
        setIsClient(true);
    }, []);

    if (!isClient) {
        return null;
    }

    return (
        <div 
            dir={dir}
            className={cn(
                "flex flex-col flex-1 transition-all duration-300",
                !isMobile && (state === 'expanded' ? (dir === 'ltr' ? "md:ml-64" : "md:mr-64") : (dir === 'ltr' ? "md:ml-20" : "md:mr-20"))
            )}
        >
            <Header />
            <main className="flex-1 overflow-auto p-4 md:p-6">
                {children}
            </main>
        </div>
    );
}

export default function MainAppLayout({ children }: PropsWithChildren) {
  return (
    <SidebarProvider>
      <AppSidebar />
      <MainLayoutContent>
        {children}
      </MainLayoutContent>
    </SidebarProvider>
  );
}
