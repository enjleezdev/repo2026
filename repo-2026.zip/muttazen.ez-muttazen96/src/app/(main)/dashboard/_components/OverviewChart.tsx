
// src/app/(main)/dashboard/_components/OverviewChart.tsx
import * as React from 'react';
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltipContent } from '@/components/ui/chart';
import type { FlattenedHistoryEntry } from '@/lib/types';
import { subDays, format, startOfDay, eachDayOfInterval, eachMonthOfInterval, getDaysInMonth } from 'date-fns';
import { useLanguage } from '@/contexts/LanguageContext';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

type Period = '15d' | '30d' | '3m' | '6m';

const processChartData = (transactions: FlattenedHistoryEntry[], period: Period) => {
  let startDate: Date;
  let dataMap: Map<string, { date: string; added: number; consumed: number }>;
  let dateFormat: string;

  switch (period) {
    case '15d':
      startDate = startOfDay(subDays(new Date(), 14));
      dataMap = new Map(eachDayOfInterval({ start: startDate, end: new Date() }).map(d => [format(d, 'yyyy-MM-dd'), { date: format(d, 'MMM d'), added: 0, consumed: 0 }]));
      dateFormat = 'yyyy-MM-dd';
      break;
    case '30d':
      startDate = startOfDay(subDays(new Date(), 29));
      dataMap = new Map(eachDayOfInterval({ start: startDate, end: new Date() }).map(d => [format(d, 'yyyy-MM-dd'), { date: format(d, 'MMM d'), added: 0, consumed: 0 }]));
      dateFormat = 'yyyy-MM-dd';
      break;
    case '3m':
      startDate = startOfDay(subDays(new Date(), 90));
      dataMap = new Map(eachMonthOfInterval({ start: startDate, end: new Date() }).map(d => [format(d, 'yyyy-MM'), { date: format(d, 'MMM yyyy'), added: 0, consumed: 0 }]));
      dateFormat = 'yyyy-MM';
      break;
    case '6m':
      startDate = startOfDay(subDays(new Date(), 180));
      dataMap = new Map(eachMonthOfInterval({ start: startDate, end: new Date() }).map(d => [format(d, 'yyyy-MM'), { date: format(d, 'MMM yyyy'), added: 0, consumed: 0 }]));
      dateFormat = 'yyyy-MM';
      break;
    default:
      startDate = startOfDay(subDays(new Date(), 29));
      dataMap = new Map(eachDayOfInterval({ start: startDate, end: new Date() }).map(d => [format(d, 'yyyy-MM-dd'), { date: format(d, 'MMM d'), added: 0, consumed: 0 }]));
      dateFormat = 'yyyy-MM-dd';
  }

  transactions.forEach(t => {
    const transactionDate = new Date(t.timestamp);
    if (transactionDate >= startDate) {
      const key = format(transactionDate, dateFormat);
      if (dataMap.has(key)) {
        const dayData = dataMap.get(key)!;
        if (t.change > 0) {
          dayData.added += t.change;
        } else {
          dayData.consumed += Math.abs(t.change);
        }
      }
    }
  });

  return Array.from(dataMap.values());
};


export function OverviewChart({ transactions }: { transactions: FlattenedHistoryEntry[] }) {
  const { t } = useLanguage();
  const [period, setPeriod] = React.useState<Period>('30d');
  
  const chartConfig = {
    added: {
      label: t('stockAdded'),
      color: "hsl(var(--chart-2))",
    },
    consumed: {
      label: t('stockConsumed'),
      color: "hsl(var(--chart-1))",
    },
  };

  const chartData = React.useMemo(() => processChartData(transactions, period), [transactions, period]);

  const periodOptions: { value: Period, label: string }[] = [
      { value: '15d', label: 'Last 15 Days' },
      { value: '30d', label: 'Last 30 Days' },
      { value: '3m', label: 'Last 3 Months' },
      { value: '6m', label: 'Last 6 Months' },
  ];

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div>
              <CardTitle>{t('inventoryOverview')}</CardTitle>
              <CardDescription>{t('overviewDescription')}</CardDescription>
            </div>
            <Select value={period} onValueChange={(value) => setPeriod(value as Period)}>
                <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Select period" />
                </SelectTrigger>
                <SelectContent>
                    {periodOptions.map(option => (
                        <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                    ))}
                </SelectContent>
            </Select>
        </div>
      </CardHeader>
      <CardContent className="pb-4">
        <div className="overflow-x-auto">
          <ChartContainer config={chartConfig} className="h-[300px] w-full min-w-[600px]">
              <ResponsiveContainer>
                  <BarChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis 
                          dataKey="date" 
                          tickLine={false}
                          axisLine={false}
                          tickMargin={10}
                          fontSize={12}
                      />
                      <YAxis 
                          tickLine={false}
                          axisLine={false}
                          tickMargin={10}
                          fontSize={12}
                          allowDecimals={false}
                      />
                      <Tooltip
                          cursor={{ fill: 'hsl(var(--card-foreground) / 0.1)' }}
                          content={<ChartTooltipContent />} 
                      />
                      <Legend wrapperStyle={{paddingTop: '20px'}}/>
                      <Bar dataKey="added" fill="var(--color-added)" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="consumed" fill="var(--color-consumed)" radius={[4, 4, 0, 0]} />
                  </BarChart>
              </ResponsiveContainer>
          </ChartContainer>
        </div>
      </CardContent>
    </Card>
  );
}
