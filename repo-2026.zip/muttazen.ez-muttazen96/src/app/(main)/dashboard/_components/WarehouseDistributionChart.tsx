
// src/app/(main)/dashboard/_components/WarehouseDistributionChart.tsx
'use client';

import * as React from 'react';
import { Pie, PieChart, ResponsiveContainer, Tooltip, Legend, Cell } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltipContent } from '@/components/ui/chart';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PackageSearch, Warehouse as WarehouseIcon } from 'lucide-react';
import type { Item, Warehouse } from '@/lib/types';
import { useLanguage } from '@/contexts/LanguageContext';

const COLORS = [
  "hsl(var(--chart-1))",
  "hsl(var(--chart-2))",
  "hsl(var(--chart-3))",
  "hsl(var(--chart-4))",
  "hsl(var(--chart-5))",
  "hsl(220, 70%, 50%)",
  "hsl(160, 60%, 45%)",
  "hsl(30, 80%, 55%)",
];

export function WarehouseDistributionChart({ warehouses, items }: { warehouses: Warehouse[]; items: Item[] }) {
  const { t } = useLanguage();
  const [selectedWarehouseId, setSelectedWarehouseId] = React.useState<string | undefined>(warehouses[0]?.id);

  const chartData = React.useMemo(() => {
    if (!selectedWarehouseId) return [];
    
    return items
      .filter(item => item.warehouse_id === selectedWarehouseId && item.quantity > 0)
      .map(item => ({ name: item.name, value: item.quantity }));
  }, [selectedWarehouseId, items]);

  const chartConfig = chartData.reduce((acc, item, index) => {
    acc[item.name] = {
      label: item.name,
      color: COLORS[index % COLORS.length],
    };
    return acc;
  }, {} as any);

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div>
              <CardTitle>{t('warehouseDistribution')}</CardTitle>
              <CardDescription>{t('warehouseDistributionDesc')}</CardDescription>
            </div>
            <Select value={selectedWarehouseId} onValueChange={setSelectedWarehouseId} disabled={warehouses.length === 0}>
                <SelectTrigger className="w-full sm:w-[220px]">
                    <SelectValue placeholder={t('ai_select_wh')} />
                </SelectTrigger>
                <SelectContent>
                    {warehouses.map(wh => (
                        <SelectItem key={wh.id} value={wh.id}>{wh.name}</SelectItem>
                    ))}
                </SelectContent>
            </Select>
        </div>
      </CardHeader>
      <CardContent className="pb-4">
        <ChartContainer config={chartConfig} className="mx-auto aspect-square h-[300px]">
          {chartData.length > 0 ? (
            <ResponsiveContainer>
              <PieChart>
                <Tooltip 
                  cursor={{ fill: 'hsl(var(--card-foreground) / 0.1)' }}
                  content={<ChartTooltipContent nameKey="name" hideLabel />} 
                />
                <Pie
                  data={chartData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={110}
                  innerRadius={60}
                  labelLine={false}
                  label={false} // Removed the label to prevent overlap
                  className="stroke-background"
                >
                    {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                </Pie>
                <Legend content={({ payload }) => {
                   const total = payload?.reduce((sum, entry) => sum + (entry.payload?.value || 0), 0) || 1;
                   return (
                     <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-xs text-muted-foreground mt-4">
                       {payload?.map((entry, index) => {
                          const percentage = total > 0 ? (((entry.payload?.value || 0) / total) * 100).toFixed(0) : 0;
                          return (
                           <div key={`item-${index}`} className="flex items-center gap-1.5">
                             <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: entry.color }} />
                             <span>{entry.value} ({percentage}%)</span>
                           </div>
                          )
                       })}
                     </div>
                   );
                }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex flex-col items-center justify-center text-center h-full text-muted-foreground">
                {selectedWarehouseId ? (
                    <>
                        <PackageSearch className="h-10 w-10 mb-2" />
                        <p className="font-semibold">{t('noItemsYet')}</p>
                        <p className="text-sm">{t('noItemsInWhForChart')}</p>
                    </>
                ) : (
                    <>
                        <WarehouseIcon className="h-10 w-10 mb-2" />
                        <p className="font-semibold">{t('selectAWarehouse')}</p>
                        <p className="text-sm">{t('selectAWarehouseForChart')}</p>
                    </>
                )}
            </div>
          )}
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
