// src/app/(main)/dashboard/_components/StatCard.tsx
import type { LucideIcon } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import Link from 'next/link';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  description?: string;
  variant?: "default" | "destructive";
  href?: string;
}

export function StatCard({ title, value, icon: Icon, description, variant = "default", href }: StatCardProps) {
  const cardContent = (
    <Card className={cn(
      "flex flex-col flex-1", // Use flex-1 to fill grid space
      variant === "destructive" && "bg-destructive/10 border-destructive/30",
      href && "hover:shadow-md transition-shadow cursor-pointer"
    )}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <Icon className={cn("h-4 w-4 text-muted-foreground", variant === "destructive" && "text-destructive")} />
      </CardHeader>
      <CardContent className="flex flex-col justify-end flex-1 p-6 pt-0">
        <div className={cn(
          "text-2xl font-bold",
          variant === "destructive" && "text-destructive"
        )}>
          {value}
        </div>
        {description && (
          <p className="text-xs text-muted-foreground pt-1">{description}</p>
        )}
      </CardContent>
    </Card>
  );

  if (href) {
    return (
      <Link href={href} className="focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 rounded-lg flex">
        {cardContent}
      </Link>
    );
  }

  return cardContent;
}
