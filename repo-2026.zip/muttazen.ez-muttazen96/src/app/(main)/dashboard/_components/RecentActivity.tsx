
// src/app/(main)/dashboard/_components/RecentActivity.tsx
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { History, ListChecks } from 'lucide-react';
import type { FlattenedHistoryEntry } from '@/lib/types';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { ScrollArea } from '@/components/ui/scroll-area';
import { useLanguage } from '@/contexts/LanguageContext';


const formatActivityText = (entry: FlattenedHistoryEntry, t: (key: any, ...args: any[]) => string) => {
  const change = Math.abs(entry.change);
  switch (entry.type) {
    case 'ADD_STOCK':
      return t('activityAddStock', change, entry.itemName);
    case 'CONSUME_STOCK':
      return t('activityConsumeStock', change, entry.itemName);
    case 'ADJUST_STOCK':
      return t('activityAdjustStock', entry.itemName, entry.change);
    default:
      return t('activityUpdateStock', entry.itemName);
  }
};

export function RecentActivity({ transactions }: { transactions: FlattenedHistoryEntry[] }) {
  const { t } = useLanguage();
  const isValidDate = (date: any) => date && !isNaN(new Date(date).getTime());

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-3">
          <History className="h-6 w-6 text-primary" />
          <CardTitle>{t('recentActivity')}</CardTitle>
        </div>
        <CardDescription>{t('recentActivityDesc')}</CardDescription>
      </CardHeader>
      <CardContent>
        {transactions.length === 0 ? (
           <div className="flex flex-col items-center justify-center text-center h-[230px]">
            <ListChecks className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="font-semibold">{t('noRecentActivity')}</p>
            <p className="text-sm text-muted-foreground">{t('noRecentActivityDesc')}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <ScrollArea className="h-[230px] min-w-[350px]">
              <div className="space-y-4 pr-4">
                <TooltipProvider>
                  {transactions.map((entry) => (
                    <div key={entry.id} className="flex items-center gap-4">
                      <Avatar className="h-9 w-9">
                        {/* Placeholder for user avatar if available in the future */}
                        <AvatarFallback className={cn(
                           entry.change > 0 ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300' : 'bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300'
                        )}>
                          {entry.change > 0 ? '+' : '-'}
                        </AvatarFallback>
                      </Avatar>
                      <div className="grid gap-1 flex-1 min-w-0">
                        <p className="text-sm font-medium leading-none truncate">
                          {formatActivityText(entry, t)}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">
                          {t('inWarehouse', entry.warehouseName)}
                        </p>
                      </div>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <p className="text-xs text-muted-foreground whitespace-nowrap">
                            {isValidDate(entry.timestamp)
                              ? formatDistanceToNow(new Date(entry.timestamp), { addSuffix: true })
                              : t('invalidDate')}
                          </p>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>{isValidDate(entry.timestamp) ? new Date(entry.timestamp).toLocaleString() : t('noDateAvailable')}</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                  ))}
                </TooltipProvider>
              </div>
            </ScrollArea>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
