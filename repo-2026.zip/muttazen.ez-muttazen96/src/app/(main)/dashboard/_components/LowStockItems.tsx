
// src/app/(main)/dashboard/_components/LowStockItems.tsx
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, PackageSearch, ChevronRight } from 'lucide-react';
import type { Item } from '@/lib/types';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useLanguage } from '@/contexts/LanguageContext';

export function LowStockItems({ items }: { items: Item[] }) {
  const { t } = useLanguage();

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-3">
          <AlertCircle className="h-6 w-6 text-destructive" />
          <CardTitle>{t('lowStockItems')}</CardTitle>
        </div>
        <CardDescription>
          {t('lowStockItemsDesc')}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 text-center min-h-[230px]">
            <PackageSearch className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="font-semibold">{t('allStockHealthy')}</p>
            <p className="text-sm text-muted-foreground">{t('noLowStockItems')}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <ScrollArea className="h-auto max-h-[280px] pr-3 min-w-[350px]">
              <div className="space-y-2">
                {/* Custom Table Header (Desktop Only) */}
                <div className="hidden rounded-lg bg-muted/50 px-4 py-2 font-medium text-muted-foreground text-sm md:grid md:grid-cols-3 md:gap-4">
                  <div>{t('itemName')}</div>
                  <div className="text-center">{t('stockThreshold')}</div>
                  <div className="text-right">{t('actions')}</div>
                </div>

                {/* Data List */}
                <div className="space-y-1">
                  {items.map((item) => (
                    <Link
                      key={item.id}
                      href={`/warehouses/${item.warehouse_id}`}
                      className={cn(
                          "block rounded-lg p-3 transition-colors hover:bg-muted/50",
                          "md:grid md:grid-cols-3 md:items-center md:gap-4 md:p-2 md:px-4"
                      )}
                    >
                      {/* Item Name */}
                      <div className="font-medium break-words">{item.name}</div>
                      
                      {/* Stock and Threshold */}
                      <div className="flex items-center justify-between text-sm text-muted-foreground md:justify-center md:text-base">
                        <span>
                          <span className="font-bold text-destructive">{item.quantity}</span>
                          <span className="mx-1">/</span>
                          <span>{item.low_stock_threshold ?? 10}</span>
                        </span>
                        {/* Mobile-only Action Indicator */}
                        <ChevronRight className="h-5 w-5 text-muted-foreground md:hidden" />
                      </div>

                      {/* Desktop-only Action Button */}
                      <div className="hidden justify-end md:flex">
                         <Button asChild variant="ghost" size="sm">
                            {/* We use a div here because the parent is already a Link */}
                            <div>{t('viewItem')}</div>
                          </Button>
                      </div>

                    </Link>
                  ))}
                </div>
              </div>
            </ScrollArea>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
