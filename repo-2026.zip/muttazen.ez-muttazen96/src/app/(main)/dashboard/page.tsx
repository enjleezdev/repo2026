
// src/app/(main)/dashboard/page.tsx
'use client';

import * as React from 'react';
import dynamic from 'next/dynamic';
import { useToast } from '@/hooks/use-toast';
import { createClient } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { FullPageLoading } from '@/components/LoadingSpinner';
import { PageHeader } from '@/components/PageHeader';
import { Warehouse as WarehouseIcon, Package, BarChart, TrendingDown, Brain, AreaChart, Truck } from 'lucide-react';
import type { Item, FlattenedHistoryEntry, Warehouse } from '@/lib/types';
import { useLanguage } from '@/contexts/LanguageContext';
import { subDays } from 'date-fns';

import { StatCard } from './_components/StatCard';
import { LowStockItems } from './_components/LowStockItems';
import { RecentActivity } from './_components/RecentActivity';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { dashboardInsights, type DashboardInsight } from '@/ai/flows/dashboard-insights';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const OverviewChart = dynamic(() => import('./_components/OverviewChart').then(mod => mod.OverviewChart), {
  ssr: false,
  loading: () => <Skeleton className="h-[430px] w-full" />,
});

const WarehouseDistributionChart = dynamic(() => import('./_components/WarehouseDistributionChart').then(mod => mod.WarehouseDistributionChart), {
  ssr: false,
  loading: () => <Skeleton className="h-[430px] w-full" />,
});

const MemoizedLowStockItems = React.memo(LowStockItems);
const MemoizedRecentActivity = React.memo(RecentActivity);


export default function DashboardPage() {
  const { toast } = useToast();
  const router = useRouter();
  const supabase = createClient();
  const { t, language } = useLanguage();
  
  const [isLoading, setIsLoading] = React.useState({
    auth: true,
    stats: true,
    insights: true,
  });
  
  const [stats, setStats] = React.useState({
    warehouseCount: 0,
    itemCount: 0,
    totalStockQuantity: 0,
    lowStockItemCount: 0,
    supplierCount: 0,
  });
  
  const [warehouses, setWarehouses] = React.useState<Warehouse[]>([]);
  const [items, setItems] = React.useState<Item[]>([]);
  const [lowStockItems, setLowStockItems] = React.useState<Item[]>([]);
  const [recentTransactions, setRecentTransactions] = React.useState<FlattenedHistoryEntry[]>([]);
  const [username, setUsername] = React.useState('User');
  const [insights, setInsights] = React.useState<DashboardInsight[]>([]);

  React.useEffect(() => {
    const checkAuthAndFetchData = async () => {
      setIsLoading(prev => ({ ...prev, auth: true, stats: true }));

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/signin');
        return; 
      }
      
      setIsLoading(prev => ({ ...prev, auth: false }));

      try {
        const { data: profile } = await supabase.from('profiles').select('username').eq('id', user.id).single();
        setUsername(profile?.username || user.email?.split('@')[0] || 'User');

        const [
          { data: warehousesData, error: whError },
          { data: itemsData, error: itemError },
          { count: supplierCount, error: supplierError },
        ] = await Promise.all([
            supabase.from('warehouses').select('*').eq('is_archived', false),
            supabase.from('items').select('*').eq('is_archived', false),
            supabase.from('suppliers').select('*', { count: 'exact', head: true }).eq('is_archived', false)
        ]);
        
        if (whError) throw whError;
        if (itemError) throw itemError;
        if (supplierError) throw supplierError;
        
        const allWarehouses = warehousesData as Warehouse[];
        const allItems = itemsData.map(item => ({...item, history: item.history || []})) as Item[];

        setWarehouses(allWarehouses);
        setItems(allItems);

        const totalStock = allItems.reduce((acc, item) => acc + item.quantity, 0);
        const lowStock = allItems.filter(item => item.quantity <= (item.low_stock_threshold ?? 10))
            .sort((a, b) => a.quantity - b.quantity);

        setStats({
          warehouseCount: allWarehouses.length,
          itemCount: allItems.length,
          totalStockQuantity: totalStock,
          lowStockItemCount: lowStock.length,
          supplierCount: supplierCount ?? 0,
        });
        setLowStockItems(lowStock);

        const fromDate = subDays(new Date(), 180).toISOString(); 
        const toDate = new Date().toISOString();

        const { data: transactionsData, error: transactionsError } = await supabase.rpc('get_transactions_in_range', {
          start_date: fromDate,
          end_date: toDate
        });

        if (transactionsError) throw transactionsError;
        
        const flattenedTransactions = transactionsData.map((d: any) => ({
            ...d.history_entry,
            itemName: d.item_name,
            warehouseName: d.warehouse_name,
            itemId: d.item_id,
            warehouseId: d.warehouse_id
        })).sort((a: any,b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

        setRecentTransactions(flattenedTransactions);
        
      } catch (err: any) {
        console.error("Failed to load dashboard data:", err);
        toast({ title: t('error'), description: t('dashboardLoadError'), variant: "destructive" });
      } finally {
        setIsLoading(prev => ({ ...prev, stats: false }));
      }
    };
    
    checkAuthAndFetchData();
  }, [supabase, router, toast, t]);

  React.useEffect(() => {
    if (isLoading.stats) return; 

    const fetchInsights = async () => {
      setIsLoading(prev => ({ ...prev, insights: true }));
      try {
        const inventorySummary = JSON.stringify({
            warehouses: warehouses.map(w => ({id: w.id, name: w.name})),
            items: items.map(i => ({id: i.id, name: i.name, quantity: i.quantity, warehouse_id: i.warehouse_id, updated_at: i.updated_at})),
            recent_transactions_count: recentTransactions.length
        });

        const aiResult = await dashboardInsights({ inventorySummary });
        setInsights(aiResult.insights);
      } catch (err) {
        console.error("Failed to load AI insights:", err);
      } finally {
        setIsLoading(prev => ({ ...prev, insights: false }));
      }
    };

    fetchInsights();
  }, [isLoading.stats, warehouses, items, recentTransactions.length]);

  const memoizedRecentActivity = React.useMemo(() => recentTransactions.slice(0, 5), [recentTransactions]);


  if (isLoading.auth) {
    return <FullPageLoading />;
  }
  
  const insightStyles = {
    high: {
      card: 'bg-red-100/60 dark:bg-red-900/30 border-red-200 dark:border-red-900/50',
      title: 'text-red-800 dark:text-red-200',
      description: 'text-red-700 dark:text-red-200/80',
    },
    medium: {
      card: 'bg-purple-100/60 dark:bg-purple-900/30 border-purple-200 dark:border-purple-900/50',
      title: 'text-purple-800 dark:text-purple-200',
      description: 'text-purple-700 dark:text-purple-200/80',
    },
    low: {
      card: 'bg-green-100/60 dark:bg-green-900/30 border-green-200 dark:border-green-900/50',
      title: 'text-green-800 dark:text-green-200',
      description: 'text-green-700 dark:text-green-200/80',
    },
  };


  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title={t('welcomeBackUser', username)}
        description={t('dashboardDescription')}
      />
      
      {isLoading.stats ? (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
          <Skeleton className="h-[110px] w-full" />
          <Skeleton className="h-[110px] w-full" />
          <Skeleton className="h-[110px] w-full" />
          <Skeleton className="h-[110px] w-full" />
          <Skeleton className="h-[110px] w-full" />
          <Skeleton className="h-[110px] w-full" />
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
            <StatCard
              title={t('warehouses')}
              value={stats.warehouseCount}
              icon={WarehouseIcon}
              href="/warehouses"
            />
            <StatCard
              title={t('uniqueitems')}
              value={stats.itemCount}
              icon={Package}
            />
            <StatCard
              title={t('suppliers')}
              value={stats.supplierCount}
              icon={Truck}
              href="/suppliers"
            />
            <StatCard
              title={t('reports')}
              value={recentTransactions.length}
              icon={AreaChart}
              href="/reports"
            />
            <StatCard
              title={t('totalStock')}
              value={stats.totalStockQuantity}
              icon={BarChart}
            />
            <StatCard
              title={t('lowStock')}
              value={stats.lowStockItemCount}
              icon={TrendingDown}
              variant={stats.lowStockItemCount > 0 ? "destructive" : "default"}
            />
        </div>
      )}

       <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-6 w-6 text-primary" />
              <span>{t('ai_insights_title')}</span>
            </CardTitle>
          </div>
          <CardDescription>{t('ai_insights_desc')}</CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full grid grid-cols-1 lg:grid-cols-3 gap-4">
            {isLoading.insights ? (
              Array.from({ length: 3 }).map((_, index) => (
                <Card key={index} className="flex flex-col p-4">
                  <Skeleton className="h-5 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full mb-4" />
                  <Skeleton className="h-10 w-full" />
                </Card>
              ))
            ) : (
              insights.map((insight) => {
                const styles = insightStyles[insight.priority] || insightStyles.low;
                return (
                  <Card key={insight.insightId} className={cn("flex flex-col w-full transition-shadow hover:shadow-md", styles.card)}>
                    <AccordionItem value={insight.insightId} className="border-b-0 w-full">
                      <AccordionTrigger className="p-4 hover:no-underline">
                        <div className={cn("w-full", language === 'ar' ? 'text-right' : 'text-left')} dir={language === 'ar' ? 'rtl' : 'ltr'}>
                          <h4 className={cn("font-semibold", styles.title)}>{insight.title[language]}</h4>
                          <p className={cn("text-sm mt-1", styles.description)}>{insight.description[language]}</p>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="p-4 pt-0">
                        <p className={cn("text-sm", styles.description)} dir={language === 'ar' ? 'rtl' : 'ltr'}>{insight.details[language]}</p>
                      </AccordionContent>
                    </AccordionItem>
                  </Card>
                );
              })
            )}
          </Accordion>
        </CardContent>
      </Card>


      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
         {isLoading.stats ? <Skeleton className="h-[360px] w-full" /> : <MemoizedLowStockItems items={lowStockItems} />}
         {isLoading.stats ? <Skeleton className="h-[360px] w-full" /> : <MemoizedRecentActivity transactions={memoizedRecentActivity} />}
      </div>
      
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <OverviewChart transactions={recentTransactions} />
        <WarehouseDistributionChart warehouses={warehouses} items={items} />
      </div>
    </div>
  );
}
