
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import type { User } from '@supabase/supabase-js';
import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import type { UserProfile, UserRole } from '@/lib/types';
import { Separator } from '@/components/ui/separator';
import { Eye, EyeOff, PlusCircle, Trash2, Edit } from 'lucide-react';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { createClient } from '@/lib/supabase';
import { Form, FormControl, FormField, FormItem, FormMessage } from '@/components/ui/form';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/contexts/LanguageContext';
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ThemeSwitcher } from '@/components/ThemeSwitcher';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Terminal } from 'lucide-react';

const allRoles: { value: UserRole; labelKey: string }[] = [
  { value: 'worker', labelKey: 'role_worker' },
  { value: 'supervisor', labelKey: 'role_supervisor' },
  { value: 'manager', labelKey: 'role_manager' },
];

const inviteUserFormSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address." }),
  role: z.enum(['manager', 'supervisor', 'worker'], { required_error: "You must select a role." }),
});

type InviteUserFormValues = z.infer<typeof inviteUserFormSchema>;


export default function ProfilePage() {
  const { toast } = useToast();
  const router = useRouter();
  const { t, language } = useLanguage();
  const [currentUser, setCurrentUser] = React.useState<User | null>(null);
  const [userProfileData, setUserProfileData] = React.useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isSavingUsername, setIsSavingUsername] = React.useState(false);
  const [isSavingPassword, setIsSavingPassword] = React.useState(false);

  const [isAddUserDialogOpen, setIsAddUserDialogOpen] = React.useState(false);

  const [showNewPassword, setShowNewPassword] = React.useState(false);
  const [showConfirmNewPassword, setShowConfirmNewPassword] = React.useState(false);
  const supabase = createClient();
  
  const getRoleLabel = (roleValue: string) => {
    if (roleValue === 'owner') return t('role_owner');
    const role = allRoles.find(r => r.value === roleValue);
    return role ? t(role.labelKey as any) : roleValue;
  };

  const usernameFormSchema = z.object({
    newUsername: z.string()
      .min(3, { message: t('usernameLengthError') })
      .regex(/^[a-zA-Z0-9 ]*$/, { message: t('usernameEnglishOnlyError') }),
  });
  type UsernameFormValues = z.infer<typeof usernameFormSchema>;

  const passwordFormSchema = z.object({
    newPassword: z.string().min(6, { message: t('passwordLengthError') }),
    confirmNewPassword: z.string(),
  }).refine((data) => data.newPassword === data.confirmNewPassword, {
    message: t('passwordMismatchError'),
    path: ['confirmNewPassword'],
  });
  type PasswordFormValues = z.infer<typeof passwordFormSchema>;


  const usernameForm = useForm<UsernameFormValues>({
    resolver: zodResolver(usernameFormSchema),
    defaultValues: { newUsername: '' },
  });

  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordFormSchema),
    defaultValues: { newPassword: '', confirmNewPassword: '' },
  });
  
  const inviteUserForm = useForm<InviteUserFormValues>({
    resolver: zodResolver(inviteUserFormSchema),
    defaultValues: {
      email: '',
      role: 'worker',
    },
  });

  const fetchUserData = React.useCallback(async () => {
    setIsLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
        setCurrentUser(user);
        
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (error || !profile) {
          toast({ title: t('error'), description: "Could not load user profile. Please sign in again.", variant: "destructive" });
          await supabase.auth.signOut();
          router.push('/signin');
          return;
        }
        
        setUserProfileData(profile as UserProfile);
        usernameForm.setValue('newUsername', profile.username || '');
    } else {
        setCurrentUser(null);
        setUserProfileData(null);
        toast({ title: t('notAuthenticated'), description: "Redirecting to sign-in page.", variant: "destructive" });
        router.push('/signin');
    }
    setIsLoading(false);
  }, [supabase, router, toast, t, usernameForm]);


  React.useEffect(() => {
    fetchUserData();
  }, [fetchUserData]);

  const handleUsernameChange = async (data: UsernameFormValues) => {
    if (!currentUser || !userProfileData) return;

    if (userProfileData.username_changed) {
      toast({ title: 'Info', description: 'Username has already been changed and cannot be changed again.', variant: 'default' });
      return;
    }
    if (data.newUsername === userProfileData.username) {
      toast({ title: 'Info', description: 'New username is the same as the current one.', variant: 'default' });
      return;
    }

    setIsSavingUsername(true);
    
    const { error: profileUpdateError } = await supabase
      .from('profiles')
      .update({ username: data.newUsername, username_changed: true })
      .eq('id', currentUser.id);

    if (profileUpdateError) {
        console.error('Failed to save username to profile:', profileUpdateError);
        toast({ title: t('error'), description: profileUpdateError.message || 'Could not save username.', variant: 'destructive' });
    } else {
        setUserProfileData((prev) => prev ? { ...prev, username: data.newUsername, username_changed: true } : null);
        usernameForm.setValue('newUsername', data.newUsername);
        toast({ title: t('success'), description: t('usernameChangeSuccess') });
        router.refresh(); 
    }
    setIsSavingUsername(false);
  };

  const handlePasswordChange = async (data: PasswordFormValues) => {
    if (!currentUser) {
        toast({ title: t('error'), description: 'User not authenticated.', variant: 'destructive' });
        return;
    }
    setIsSavingPassword(true);
    const { error } = await supabase.auth.updateUser({ password: data.newPassword });
    
    if (error) {
        console.error('Failed to change password:', error);
        toast({ title: t('error'), description: error.message || 'Could not update password.', variant: 'destructive' });
    } else {
        toast({ title: t('success'), description: t('passwordChangeSuccess') });
        passwordForm.reset();
        await supabase.auth.signOut();
        router.push('/signin');
    }
    setIsSavingPassword(false);
  };
  
  // Kept UI but disabled logic
  async function onInviteUserSubmit(data: InviteUserFormValues) {
    toast({ title: "Feature Disabled", description: "Inviting users is currently disabled for rework.", variant: "default" });
  }

  const canManageUsers = userProfileData?.role === 'owner'; // Simplified for now

  if (isLoading) {
    return <div className="flex justify-center items-center h-screen"><LoadingSpinner size={32} /></div>;
  }

  if (!currentUser || !userProfileData) {
    return null;
  }

  return (
    <>
      <PageHeader title={t('profileTitle')} description={t('profileDescription')} />
      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('accountInfo')}</CardTitle>
              <CardDescription>{t('accountInfoDesc')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="email">{t('emailAddress')}</Label>
                <Input id="email" value={currentUser.email || 'N/A'} disabled className="mt-1 cursor-not-allowed" />
                <p className="text-xs text-muted-foreground mt-1">{t('emailCannotBeChanged')}</p>
              </div>
              <Separator />
              <Form {...usernameForm}>
                <form onSubmit={usernameForm.handleSubmit(handleUsernameChange)} className="space-y-4">
                  <FormField
                    control={usernameForm.control}
                    name="newUsername"
                    render={({ field }) => (
                      <FormItem>
                        <Label htmlFor="username">{t('username')}</Label>
                        <FormControl>
                          <Input
                            id="username"
                            {...field}
                            disabled={userProfileData.username_changed || isSavingUsername}
                            className={userProfileData.username_changed ? 'cursor-not-allowed' : ''}
                          />
                        </FormControl>
                        <p className="text-xs text-muted-foreground">
                          {userProfileData.username_changed
                            ? t('usernameAlreadyChanged')
                            : t('usernameSetOnce')}
                        </p>
                        {!userProfileData.username_changed && language === 'ar' && (
                          <p className="text-xs text-muted-foreground">
                            {t('usernameEnglishOnlyNote')}
                          </p>
                        )}
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  {!userProfileData.username_changed && (
                    <Button type="submit" disabled={isSavingUsername}>
                      {isSavingUsername ? <LoadingSpinner size={16} className="mr-2" /> : null}
                      {t('changeUsername')}
                    </Button>
                  )}
                </form>
              </Form>
            </CardContent>
          </Card>
          
           <Card>
            <CardHeader>
                <CardTitle>{t('theme')}</CardTitle>
                <CardDescription>{t('themeDescription')}</CardDescription>
            </CardHeader>
            <CardContent>
                <ThemeSwitcher />
            </CardContent>
          </Card>

        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('passwordSettings')}</CardTitle>
              <CardDescription>{t('passwordSettingsDesc')}</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...passwordForm}>
                <form onSubmit={passwordForm.handleSubmit(handlePasswordChange)} className="space-y-4">
                  <FormField
                    control={passwordForm.control}
                    name="newPassword"
                    render={({ field }) => (
                      <FormItem>
                        <Label htmlFor="newPassword">{t('newPassword')}</Label>
                        <FormControl>
                          <div className="relative">
                            <Input
                                id="newPassword"
                                type={showNewPassword ? "text" : "password"}
                                placeholder={t('newPasswordPlaceholder')}
                                {...field}
                                disabled={isSavingPassword}
                                className="pr-10"
                            />
                            <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                className="absolute right-1 top-1/2 -translate-y-1/2 h-7"
                                onClick={() => setShowNewPassword(!showNewPassword)}
                            >
                                {showNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                            </Button>
                        </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={passwordForm.control}
                    name="confirmNewPassword"
                    render={({ field }) => (
                      <FormItem>
                        <Label htmlFor="confirmNewPassword">{t('confirmNewPassword')}</Label>
                        <FormControl>
                          <div className="relative">
                              <Input
                                  id="confirmNewPassword"
                                  type={showConfirmNewPassword ? "text" : "password"}
                                  placeholder={t('confirmNewPasswordPlaceholder')}
                                  {...field}
                                  disabled={isSavingPassword}
                                  className="pr-10"
                              />
                              <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  className="absolute right-1 top-1/2 -translate-y-1/2 h-7"
                                  onClick={() => setShowConfirmNewPassword(!showConfirmNewPassword)}
                              >
                                  {showConfirmNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                              </Button>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" disabled={isSavingPassword}>
                    {isSavingPassword ? <LoadingSpinner size={16} className="mr-2" /> : null}
                    {t('changePassword')}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        
          {canManageUsers && (
            <Card>
              <CardHeader>
                <CardTitle>{t('userManagement')}</CardTitle>
                <CardDescription>{t('userManagementDesc')}</CardDescription>
              </CardHeader>
              <CardContent>
                <Alert className="border-yellow-500/50 text-yellow-700 dark:border-yellow-500/50 dark:text-yellow-400 [&>svg]:text-yellow-700 dark:[&>svg]:text-yellow-400">
                  <Terminal className="h-4 w-4" />
                  <AlertTitle className="font-semibold">
                    {language === 'ar' ? 'قيد التطوير' : 'Under Development'}
                  </AlertTitle>
                  <AlertDescription>
                    {t('userManagementUnderDevelopment')}
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}
