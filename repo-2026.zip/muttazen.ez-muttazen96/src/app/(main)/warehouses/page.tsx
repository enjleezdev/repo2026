// src/app/(main)/warehouses/page.tsx
'use client';

import * as React from 'react';
import Link from "next/link";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PlusCircle, Warehouse as WarehouseIcon, Trash2, Download, Eye, Repeat, Search } from "lucide-react";
import { EmptyState } from "@/components/EmptyState";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import type { Warehouse, Item, UserProfile } from '@/lib/types';
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { PrintableWarehouseReport } from '@/components/PrintableWarehouseReport';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { createClient } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import type { User } from '@supabase/supabase-js';
import Image from 'next/image';
import { useLanguage } from '@/contexts/LanguageContext';
import html2pdf from 'html2pdf.js';

const generateFilename = (parts: string[]) => {
  const now = new Date();
  const timestamp = `${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}${now.getHours().toString().padStart(2, '0')}${now.getMinutes().toString().padStart(2, '0')}${now.getSeconds().toString().padStart(2, '0')}`;
  return [...parts, timestamp].join('-').replace(/[^a-zA-Z0-9-]/g, '_');
};

export default function WarehousesPage() {
  const [allActiveWarehouses, setAllActiveWarehouses] = React.useState<Warehouse[]>([]);
  const [warehouseItems, setWarehouseItems] = React.useState<Map<string, Item[]>>(new Map());
  const [isLoading, setIsLoading] = React.useState(true);
  const [isDownloading, setIsDownloading] = React.useState(false);
  const [showAll, setShowAll] = React.useState(false);
  const [selectedWarehouseForArchive, setSelectedWarehouseForArchive] = React.useState<Warehouse | null>(null);
  const [warehouseToDownload, setWarehouseToDownload] = React.useState<Warehouse | null>(null);
  const [searchTerm, setSearchTerm] = React.useState("");
  const { toast } = useToast();
  const { t } = useLanguage();
  const supabase = createClient();
  const router = useRouter();
  const [currentUser, setCurrentUser] = React.useState<User | null>(null);
  const [userProfile, setUserProfile] = React.useState<UserProfile | null>(null);
  const reportContainerRef = React.useRef<HTMLDivElement>(null);


  const canAddWarehouse = true;
  const canArchiveWarehouse = true;

  const loadWarehouses = React.useCallback(async () => {
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      router.push('/signin');
      return;
    }
    setCurrentUser(user);

    const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single();
    setUserProfile(profile as UserProfile);

    setIsLoading(true);

    try {
      
      const { data: warehousesFromSupabase, error: warehousesError } = await supabase
        .from('warehouses')
        .select('*')
        .eq('is_archived', false)
        .order('updated_at', { ascending: false });

      if (warehousesError) throw warehousesError;
      setAllActiveWarehouses(warehousesFromSupabase as Warehouse[]);

      // Fetch items only for the visible warehouses to improve performance
      const displayedWarehouseIds = warehousesFromSupabase.map(wh => wh.id);
      if (displayedWarehouseIds.length > 0) {
        const { data: itemsData, error: itemsError } = await supabase
          .from('items')
          .select('id, name, quantity, warehouse_id')
          .in('warehouse_id', displayedWarehouseIds)
          .eq('is_archived', false);
        
        if (itemsError) throw itemsError;

        const itemsMap = new Map<string, Item[]>();
        warehousesFromSupabase.forEach(wh => itemsMap.set(wh.id, []));
        itemsData.forEach(item => {
          if (itemsMap.has(item.warehouse_id)) {
            itemsMap.get(item.warehouse_id)!.push(item as Item);
          }
        });
        setWarehouseItems(itemsMap);
      } else {
        setWarehouseItems(new Map());
      }

    } catch (error: any) {
      console.error("Error loading warehouses from Supabase: ", error);
      toast({ title: t('error'), description: error.message || "Failed to load warehouses.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }, [toast, supabase, router, t]);

  React.useEffect(() => {
    loadWarehouses();
  }, [loadWarehouses]);

  const handleArchiveWarehouse = async () => {
    if (!selectedWarehouseForArchive) return;
    setIsLoading(true); 
    try {
      // Use a transaction to archive warehouse and its items
      const { error } = await supabase.rpc('archive_warehouse_and_items', {
        p_warehouse_id: selectedWarehouseForArchive.id
      });
      if (error) throw error;
      
      toast({ title: t('warehouseArchived'), description: t('warehouseArchivedDesc', selectedWarehouseForArchive.name) });
      setSelectedWarehouseForArchive(null);
      loadWarehouses(); 
    } catch (error: any) {
      console.error("Error archiving warehouse: ", error);
      toast({ title: t('error'), description: error.message || "Failed to archive warehouse.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleDownloadReport = (warehouseToPrint: Warehouse) => {
    if (!warehouseToPrint) return;
    setWarehouseToDownload(warehouseToPrint);
    setIsDownloading(true);

    setTimeout(() => {
        if (!reportContainerRef.current) {
            toast({ title: t('error'), description: 'Report element not found.', variant: 'destructive'});
            setIsDownloading(false);
            setWarehouseToDownload(null);
            return;
        }

        const filename = generateFilename([warehouseToPrint.name]);
        
        html2pdf().from(reportContainerRef.current).set({
            margin: [15, 15, 15, 15],
            filename: `${filename}.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true, logging: false },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        }).save().then(() => {
            setIsDownloading(false);
            setWarehouseToDownload(null);
        }).catch(err => {
            setIsDownloading(false);
            setWarehouseToDownload(null);
            toast({ title: t('error'), description: 'Failed to generate PDF.', variant: 'destructive'});
            console.error(err);
        });
    }, 500);
  };

  const filteredWarehouses = allActiveWarehouses.filter(warehouse =>
    warehouse.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const displayedWarehouses = showAll ? filteredWarehouses : filteredWarehouses.slice(0, 8);

  if (isLoading && allActiveWarehouses.length === 0) {
    return <div className="flex justify-center items-center h-[calc(100vh-200px)]"><LoadingSpinner size={48} /></div>;
  }

  return (
    <>
      <div style={{ position: 'absolute', left: '-9999px', top: 'auto', width: '210mm', height: 'auto' }}>
        {warehouseToDownload && (
          <div ref={reportContainerRef}>
            <PrintableWarehouseReport
                warehouse={warehouseToDownload}
                items={(warehouseItems.get(warehouseToDownload.id) || []).map(item => ({ name: item.name, quantity: item.quantity }))}
                printedBy={userProfile?.username || currentUser?.email || 'User'}
                printDate={new Date()}
            />
          </div>
        )}
      </div>

      <div>
        <TooltipProvider>
        <AlertDialog open={!!selectedWarehouseForArchive} onOpenChange={(isOpen) => {
          if (!isOpen) {
            setSelectedWarehouseForArchive(null);
          }
        }}>
          <PageHeader
            title={t('warehousesTitle')}
            description={t('warehousesDescription')}
            actions={
              <div className="flex w-full flex-col sm:max-w-xs gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder={t('searchWarehouses')}
                    className="w-full pl-8 h-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                {canAddWarehouse && (
                  <Button asChild className="w-full">
                    <Link href="/warehouses/new">
                      <PlusCircle className="mr-2 h-4 w-4" />
                      {t('addNewWarehouse')}
                    </Link>
                  </Button>
                )}
              </div>
            }
          />
          {filteredWarehouses.length === 0 && !isLoading ? (
            <EmptyState
              IconComponent={WarehouseIcon}
              title={searchTerm ? t('noWarehousesFound') : t('noActiveWarehouses')}
              description={searchTerm ? t('searchNoMatch', searchTerm) : t('noActiveWarehousesDesc')}
              action={!searchTerm && canAddWarehouse ? {
                label: t('addWarehouseAction'),
                href: "/warehouses/new",
                icon: PlusCircle,
              } : undefined}
            />
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {displayedWarehouses.map((warehouse) => (
                  <Card key={warehouse.id} className="flex flex-col rounded-xl shadow-sm hover:shadow-md transition-transform duration-300 hover:-translate-y-1">
                    <Link href={`/warehouses/${warehouse.id}`} className="flex flex-col flex-grow hover:bg-muted/50 transition-colors rounded-t-lg">
                      <CardHeader className="flex-grow p-4"> 
                        <div className="flex items-start justify-between">
                          <CardTitle className="font-semibold text-base mb-2 break-words">{warehouse.name}</CardTitle> 
                          <WarehouseIcon className="h-4 w-4 text-muted-foreground shrink-0" />
                        </div>
                        {warehouse.description && (
                          <CardDescription className="text-xs text-muted-foreground line-clamp-2 break-words mt-1">{warehouse.description}</CardDescription> 
                        )}
                      </CardHeader>
                    </Link>
                    <div className="flex items-center justify-end gap-1 p-2 pt-0 border-t mt-auto"> 
                      <Tooltip>
                        <TooltipTrigger asChild>
                           <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleDownloadReport(warehouse)}
                            disabled={isDownloading && warehouseToDownload?.id === warehouse.id}
                            aria-label={`Download report for ${warehouse.name}`}
                           >
                            {isDownloading && warehouseToDownload?.id === warehouse.id ? <LoadingSpinner size={16}/> : <Download className="h-4 w-4" />}
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>{t('download_report', 'PDF')}</p></TooltipContent>
                      </Tooltip>
                      <AlertDialogTrigger asChild>
                        <Tooltip>
                          <TooltipTrigger asChild>
                              <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => setSelectedWarehouseForArchive(warehouse)} aria-label={`Archive ${warehouse.name}`}>
                                  <Trash2 className="h-4 w-4" />
                              </Button>
                          </TooltipTrigger>
                          <TooltipContent><p>{t('archive')}</p></TooltipContent>
                        </Tooltip>
                      </AlertDialogTrigger>
                    </div>
                  </Card>
                ))}
              </div>
              {filteredWarehouses.length > 8 && (
                <div className="mt-6 flex justify-center">
                  <Button variant="outline" onClick={() => setShowAll(prev => !prev)}>
                    {showAll ? <Repeat className="mr-2 h-4 w-4" /> : <Eye className="mr-2 h-4 w-4" />}
                    {showAll ? t('showLess') : t('viewAllWarehouses')}
                  </Button>
                </div>
              )}
            </>
          )}
          
          {selectedWarehouseForArchive && (
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>{t('archiveWarehouseTitle', selectedWarehouseForArchive.name)}</AlertDialogTitle>
                <AlertDialogDescription>
                  {t('archiveWarehouseDesc')}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setSelectedWarehouseForArchive(null)}>{t('cancel')}</AlertDialogCancel>
                <AlertDialogAction onClick={handleArchiveWarehouse} className="bg-destructive hover:bg-destructive/90">
                  {isLoading ? <LoadingSpinner size={16} className="mr-2"/> : t('archive')}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          )}
        </AlertDialog>
        </TooltipProvider>
      </div>
    </>
  );
}
