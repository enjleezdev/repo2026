
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import Link from 'next/link';
import type { User } from '@supabase/supabase-js';

import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { createClient } from '@/lib/supabase';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { useLanguage } from '@/contexts/LanguageContext';
import type { UserProfile } from '@/lib/types';

const warehouseFormSchema = z.object({
  name: z.string().min(2, {
    message: 'Warehouse name must be at least 2 characters.',
  }),
  description: z.string().optional(),
});

type WarehouseFormValues = z.infer<typeof warehouseFormSchema>;

export default function NewWarehousePage() {
  const router = useRouter();
  const { toast } = useToast();
  const { t } = useLanguage();
  const [isSaving, setIsSaving] = React.useState(false);
  const [currentUser, setCurrentUser] = React.useState<User | null>(null);
  const [isAuthLoading, setIsAuthLoading] = React.useState(true);
  const supabase = createClient();

  const form = useForm<WarehouseFormValues>({
    resolver: zodResolver(warehouseFormSchema),
    defaultValues: {
      name: '',
      description: '',
    },
  });

  React.useEffect(() => {
    const fetchUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setCurrentUser(user);
      } else {
        toast({ title: t('notAuthenticated'), description: "Redirecting to sign-in page.", variant: "destructive" });
        router.push('/signin');
      }
      setIsAuthLoading(false);
    };
    fetchUser();
  }, [router, supabase, toast, t]);

  async function onSubmit(data: WarehouseFormValues) {
    if (!currentUser) {
      toast({
        title: t('error'),
        description: "You must be logged in to create a warehouse.",
        variant: "destructive",
      });
      return;
    }

    setIsSaving(true);
    const { error } = await supabase
      .from('warehouses')
      .insert({ 
        name: data.name,
        description: data.description || '',
        is_archived: false,
        owner_id: currentUser.id,
      });

    if (error) {
      console.error("Error adding warehouse to Supabase: ", error);
      toast({ title: t('error'), description: error.message || "Failed to save warehouse. Please try again.", variant: "destructive" });
      setIsSaving(false);
    } else {
      toast({ title: t('warehouseCreated'), description: t('warehouseCreatedDesc', data.name) });
      router.push('/warehouses');
      router.refresh();
    }
  }

  if (isAuthLoading) {
    return <div className="flex justify-center items-center h-screen"><LoadingSpinner size={32} /></div>;
  }

  return (
    <>
      <PageHeader
        title={t('createNewWarehouse')}
        description={t('createNewWarehouseDesc')}
        actions={
          <Button variant="outline" asChild>
            <Link href="/warehouses">
              <ArrowLeft className="mr-2 h-4 w-4" />
              {t('backToWarehouses')}
            </Link>
          </Button>
        }
      />
      <Card>
        <CardHeader>
          <CardTitle>{t('warehouseDetails')}</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('warehouseName')}</FormLabel>
                    <FormControl>
                      <Input placeholder="" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('warehouseDescription')}</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder=""
                        className="resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => router.push('/warehouses')} disabled={isSaving}>
                  {t('cancel')}
                </Button>
                <Button type="submit" disabled={isSaving}>
                  {isSaving ? <LoadingSpinner size={16} className="mr-2" /> : null}
                  {t('saveWarehouse')}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </>
  );
}
