
'use client';

import * as React from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { format } from 'date-fns';
import { createClient } from '@/lib/supabase';

import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, PackagePlus, Eye, Trash2, PlusCircle, MinusCircle, MapPin } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { EmptyState } from '@/components/EmptyState';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import type { Item, Warehouse, HistoryEntry, UserProfile } from '@/lib/types';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { User } from '@supabase/supabase-js';
import { useLanguage } from '@/contexts/LanguageContext';

const itemFormSchema = z.object({
  name: z.string().min(2, {
    message: 'Item name must be at least 2 characters.',
  }),
  quantity: z.coerce
    .number({ invalid_type_error: 'Quantity must be a number.' })
    .int('Quantity must be an integer.')
    .min(0, { message: 'Quantity must be a non-negative number.'}),
  location: z.string().optional(),
  low_stock_threshold: z.coerce
    .number({ invalid_type_error: 'Threshold must be a number.' })
    .int('Threshold must be an integer.')
    .min(0, { message: 'Threshold must be a non-negative number.'})
    .optional(),
});

type ItemFormValues = z.infer<typeof itemFormSchema>;

const stockAdjustmentFormSchema = z.object({
  adjustmentQuantity: z.coerce
    .number({ invalid_type_error: 'Quantity must be a number.' })
    .int('Quantity must be an integer.')
    .positive({ message: 'Adjustment quantity must be a positive number.' }),
  comment: z.string().optional(),
});

type StockAdjustmentFormValues = z.infer<typeof stockAdjustmentFormSchema>;

const updateWarehouseTimestampInSupabase = async (warehouseId: string) => {
    const supabase = createClient();
  if (!warehouseId) {
    console.error("updateWarehouseTimestampInSupabase: warehouseId is missing");
    return;
  }
  try {
    await supabase.from('warehouses').update({ updated_at: new Date().toISOString() }).eq('id', warehouseId);
  } catch (error) {
    console.error("Failed to update warehouse timestamp in Supabase", error);
  }
};


export default function WarehouseDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const { t } = useLanguage();
  const warehouseIdFromParams = params.warehouseId as string;
  const supabase = createClient();

  const [warehouse, setWarehouse] = React.useState<Warehouse | null>(null);
  const [items, setItems] = React.useState<Item[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isAddItemDialogOpen, setIsAddItemDialogOpen] = React.useState(false);
  
  const [isStockAdjustmentDialogOpen, setIsStockAdjustmentDialogOpen] = React.useState(false);
  const [itemForAdjustment, setItemForAdjustment] = React.useState<Item | null>(null);

  const [adjustmentType, setAdjustmentType] = React.useState<'ADD_STOCK' | 'CONSUME_STOCK' | null>(null);
  const [itemToArchive, setItemToArchive] = React.useState<Item | null>(null);
  const [currentUser, setCurrentUser] = React.useState<User | null>(null);

  const canAddItem = true;
  const canAdjustStock = true;
  const canArchiveItem = true;

  const itemForm = useForm<ItemFormValues>({
    resolver: zodResolver(itemFormSchema),
    defaultValues: {
      name: '',
      quantity: 1,
      location: '',
      low_stock_threshold: 10,
    },
  });

  const stockAdjustmentForm = useForm<StockAdjustmentFormValues>({
    resolver: zodResolver(stockAdjustmentFormSchema),
    defaultValues: {
      adjustmentQuantity: 1,
      comment: '',
    },
  });

  const loadWarehouseAndItems = React.useCallback(async (idToLoad: string) => {
    if (!idToLoad) {
      toast({ title: t('error'), description: "Warehouse ID is missing.", variant: "destructive" });
      router.push('/warehouses');
      return;
    }
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      router.push('/signin');
      return;
    }
    setCurrentUser(user);
    setIsLoading(true);

    try {
      const { data: warehouseData, error: warehouseError } = await supabase
            .from('warehouses')
            .select('*')
            .eq('id', idToLoad)
            .single();

      if (warehouseError || !warehouseData || warehouseData.is_archived) {
        toast({
          title: t('warehousesTitle') + " Not Found",
          description: `The requested warehouse does not exist or has been archived. You will be redirected.`,
          variant: "destructive",
          duration: 4000,
        });
        setTimeout(() => {
          router.push('/warehouses');
        }, 1500);
        setWarehouse(null);
        setItems([]);
        setIsLoading(false);
        return;
      }

      setWarehouse(warehouseData as Warehouse);
      
      const { data: itemsData, error: itemsError } = await supabase
        .from('items')
        .select('*')
        .eq('warehouse_id', idToLoad)
        .eq('is_archived', false);

      if (itemsError) throw itemsError;

      const warehouseItems = (itemsData || []).map(item => ({...item, history: item.history || []})) as Item[];
      setItems(warehouseItems.sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()));

    } catch (error: any) {
      console.error("Failed to load data from Supabase", error);
      toast({ title: t('error'), description: error.message || "Failed to load warehouse data.", variant: "destructive" });
       router.push('/warehouses');
    } finally {
      setIsLoading(false);
    }
  }, [router, toast, supabase, t]); 

  React.useEffect(() => {
    if (warehouseIdFromParams) {
      loadWarehouseAndItems(warehouseIdFromParams);
    }
  }, [warehouseIdFromParams, loadWarehouseAndItems]);


 async function onAddItemSubmit(data: ItemFormValues) {
    if (!warehouseIdFromParams || !warehouse || !currentUser) return;

    const now = new Date().toISOString();
    const initialHistoryEntry: HistoryEntry = {
      id: Date.now().toString() + '-hist-create', 
      type: 'CREATE_ITEM',
      change: data.quantity,
      quantityBefore: 0,
      quantityAfter: data.quantity,
      timestamp: now,
      comment: 'Initial item creation',
    };

    const newItemData = {
      warehouse_id: warehouseIdFromParams,
      name: data.name,
      quantity: data.quantity,
      location: data.location || '',
      history: [initialHistoryEntry], 
      is_archived: false,
      owner_id: currentUser.id,
      low_stock_threshold: data.low_stock_threshold ?? 10,
    };

    try {
        const { error } = await supabase.from('items').insert(newItemData);
        if (error) throw error;

      toast({ title: t('itemAdded'), description: t('itemAddedDesc', data.name, warehouse?.name) });
      setIsAddItemDialogOpen(false); 
      itemForm.reset({ name: '', quantity: 1, location: '', low_stock_threshold: 10 }); 
      loadWarehouseAndItems(warehouseIdFromParams); 
      await updateWarehouseTimestampInSupabase(warehouseIdFromParams);
    } catch (error: any) {
      console.error("Failed to save item to Supabase", error);
      toast({ title: t('error'), description: error.message || "Failed to save item. Please try again.", variant: "destructive" });
    }
  }

  const handleOpenStockAdjustmentDialog = (item: Item, type: 'ADD_STOCK' | 'CONSUME_STOCK') => {
    setItemForAdjustment(item);
    setAdjustmentType(type);
    stockAdjustmentForm.reset({ adjustmentQuantity: 1, comment: '' });
    setIsStockAdjustmentDialogOpen(true);
  };

  async function onStockAdjustmentSubmit(data: StockAdjustmentFormValues) {
    if (!itemForAdjustment || !adjustmentType || !warehouseIdFromParams || !currentUser) return;

    const quantityChange = adjustmentType === 'ADD_STOCK' ? data.adjustmentQuantity : -data.adjustmentQuantity;
    const newQuantity = itemForAdjustment.quantity + quantityChange;
    
    if (adjustmentType === 'CONSUME_STOCK' && newQuantity < 0) {
      stockAdjustmentForm.setError("adjustmentQuantity", {
        type: "manual",
        message: `Cannot consume more than available stock (${itemForAdjustment.quantity}).`,
      });
      return;
    }

    const now = new Date().toISOString();
    const newHistoryEntry: HistoryEntry = {
      id: Date.now().toString() + '-hist-adjust',
      type: adjustmentType,
      change: quantityChange,
      quantityBefore: itemForAdjustment.quantity,
      quantityAfter: newQuantity,
      comment: data.comment || (adjustmentType === 'ADD_STOCK' ? 'Stock added' : 'Stock consumed'),
      timestamp: now,
    };
    
    const updatedHistory = [...itemForAdjustment.history, newHistoryEntry];

    try {
      const { error } = await supabase
        .from('items')
        .update({ 
          quantity: newQuantity,
          history: updatedHistory,
          updated_at: new Date().toISOString()
        })
        .eq('id', itemForAdjustment.id);

      if (error) throw error;
      
      const threshold = itemForAdjustment.low_stock_threshold ?? 10;
      if (adjustmentType === 'CONSUME_STOCK' && newQuantity <= threshold) {
        const notificationData = {
          owner_id: currentUser.id,
          type: 'LOW_STOCK',
          title: `Low Stock: ${itemForAdjustment.name}`,
          message: `Stock for "${itemForAdjustment.name}" in warehouse "${warehouse?.name}" is low (${newQuantity}/${threshold}).`,
        };

        const { error: notificationError } = await supabase
          .from('notifications')
          .insert(notificationData);
        
        if (notificationError) {
          console.error('Failed to create low stock notification:', notificationError);
        }
      }

      toast({ title: t('stockUpdated'), description: t('stockUpdatedDesc', itemForAdjustment.name) });
      setIsStockAdjustmentDialogOpen(false);
      stockAdjustmentForm.reset();
      loadWarehouseAndItems(warehouseIdFromParams); 
      await updateWarehouseTimestampInSupabase(warehouseIdFromParams);
    } catch (error: any) {
      console.error("Failed to update item stock in Supabase", error);
      toast({ title: t('error'), description: error.message || "Failed to update stock. Please try again.", variant: "destructive" });
    }
  }

  const handleArchiveItem = async () => {
    if (!itemToArchive || !warehouseIdFromParams) return;
    
    try {
        const { error } = await supabase
            .from('items')
            .update({ is_archived: true, updated_at: new Date().toISOString() })
            .eq('id', itemToArchive.id);
        
        if (error) throw error;

      toast({ title: t('itemArchived'), description: t('itemArchivedDesc', itemToArchive.name) });
      setItemToArchive(null); 
      loadWarehouseAndItems(warehouseIdFromParams); 
      await updateWarehouseTimestampInSupabase(warehouseIdFromParams);
    } catch (error: any) {
      console.error("Failed to archive item in Supabase", error);
      toast({ title: t('error'), description: error.message || "Failed to archive item.", variant: "destructive" });
    }
  };

  if (isLoading && !warehouse) { 
    return <div className="flex justify-center items-center h-[calc(100vh-200px)]"><LoadingSpinner size={48} /></div>;
  }

  if (!warehouse) {
    return (
       <div className="flex h-full w-full items-center justify-center">
         <p>Warehouse data could not be loaded. You may be redirected shortly.</p>
       </div>
    );
  }

  return (
    <>
      <div>
        <TooltipProvider>
          <AlertDialog open={!!itemToArchive} onOpenChange={(isOpen) => {
            if (!isOpen) setItemToArchive(null);
          }}>
            <PageHeader
              title={warehouse.name}
              description={t('warehouseDetailDesc')}
              actions={
                <div className="flex gap-2">
                  <Button variant="outline" asChild>
                    <Link href="/warehouses">
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      {t('backToWarehouses')}
                    </Link>
                  </Button>
                  {canAddItem && (
                    <Button onClick={() => setIsAddItemDialogOpen(true)}>
                      <PackagePlus className="mr-2 h-4 w-4" />
                      {t('addItem')}
                    </Button>
                  )}
                </div>
              }
            />
            
            <Card>
              <CardHeader>
                <CardTitle>{t('inventoryItems')}</CardTitle>
                <CardDescription>{t('inventoryItemsDesc', warehouse.name)}</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading && items.length === 0 ? <div className="flex justify-center py-4"><LoadingSpinner/></div> :
                items.length === 0 ? (
                  <EmptyState
                    IconComponent={PackagePlus}
                    title={t('noItemsYet')}
                    description={t('noItemsYetDesc')}
                    action={canAddItem ? {
                      label: t('addItem'),
                      onClick: () => setIsAddItemDialogOpen(true),
                      icon: PackagePlus,
                    } : undefined}
                  />
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>{t('itemDetails')}</TableHead>
                          <TableHead className="text-right">{t('actions')}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {items.map((item) => (
                          <TableRow key={item.id} className="hover:bg-muted/50">
                            <TableCell>
                                <div className="font-medium break-words">{item.name}</div>
                                <div className="text-sm text-muted-foreground">
                                    {t('quantity')}: {item.quantity}
                                </div>
                                {item.low_stock_threshold && (
                                    <div className={cn("text-xs", item.quantity <= item.low_stock_threshold ? "text-destructive font-semibold" : "text-muted-foreground")}>
                                        {t('lowStockAt', item.low_stock_threshold)}
                                    </div>
                                )}
                                {item.location && (
                                    <div className="flex items-center text-xs text-muted-foreground mt-0.5">
                                        <MapPin className="h-3 w-3 mr-1.5" />
                                        <span>{item.location}</span>
                                    </div>
                                )}
                            </TableCell>
                            <TableCell className="text-right">
                                <div className="flex items-center justify-end gap-0.5">
                                  {canAdjustStock && (
                                    <>
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <Button variant="ghost" size="icon" onClick={() => handleOpenStockAdjustmentDialog(item, 'ADD_STOCK')} aria-label={`Add stock to ${item.name}`}>
                                            <PlusCircle className="h-5 w-5 text-green-600" />
                                          </Button>
                                        </TooltipTrigger>
                                        <TooltipContent><p>{t('addStock')}</p></TooltipContent>
                                      </Tooltip>
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <Button variant="ghost" size="icon" onClick={() => handleOpenStockAdjustmentDialog(item, 'CONSUME_STOCK')} aria-label={`Consume stock from ${item.name}`}>
                                            <MinusCircle className="h-5 w-5 text-red-600" />
                                          </Button>
                                        </TooltipTrigger>
                                        <TooltipContent><p>{t('consumeStock')}</p></TooltipContent>
                                      </Tooltip>
                                    </>
                                  )}
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button asChild variant="ghost" size="icon" aria-label={`View details for ${item.name}`}>
                                        <Link href={`/warehouses/${warehouse.id}/items/${item.id}`}>
                                            <Eye className="h-5 w-5" />
                                        </Link>
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent><p>{t('viewHistory')}</p></TooltipContent>
                                  </Tooltip>
                                  {canArchiveItem && (
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <AlertDialogTrigger asChild>
                                          <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => setItemToArchive(item)} aria-label={`Archive ${item.name}`}>
                                            <Trash2 className="h-5 w-5" />
                                          </Button>
                                        </AlertDialogTrigger>
                                      </TooltipTrigger>
                                      <TooltipContent><p>{t('archiveItem')}</p></TooltipContent>
                                    </Tooltip>
                                  )}
                                </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>

            <Dialog open={isAddItemDialogOpen} onOpenChange={(isOpen) => {
              setIsAddItemDialogOpen(isOpen);
              if (!isOpen) {
                  itemForm.reset({ name: '', quantity: 1, location: '', low_stock_threshold: 10 });
              }
            }}>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>{t('addItemTo', warehouse?.name)}</DialogTitle>
                  <DialogDescription>
                    {t('addItemDialogDesc')}
                  </DialogDescription>
                </DialogHeader>
                <Form {...itemForm}>
                  <form onSubmit={itemForm.handleSubmit(onAddItemSubmit)} className="space-y-4 py-4">
                    <FormField
                      control={itemForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('itemName')}</FormLabel>
                          <FormControl>
                            <Input placeholder={t('itemNamePlaceholder')} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={itemForm.control}
                      name="quantity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('initialQuantity')}</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder={t('initialQuantityPlaceholder')} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={itemForm.control}
                      name="low_stock_threshold"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('lowStockThreshold')}</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder={t('lowStockThresholdPlaceholder')} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={itemForm.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('itemLocation')}</FormLabel>
                          <FormControl>
                            <Input placeholder={t('itemLocationPlaceholder')} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <DialogFooter>
                      <DialogClose asChild>
                        <Button type="button" variant="outline">{t('cancel')}</Button>
                      </DialogClose>
                      <Button type="submit">{t('saveItem')}</Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>

            <Dialog open={isStockAdjustmentDialogOpen} onOpenChange={(isOpen) => {
              setIsStockAdjustmentDialogOpen(isOpen);
              if (!isOpen) {
                  stockAdjustmentForm.reset(); 
              }
            }}>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>
                    {t(adjustmentType === 'ADD_STOCK' ? 'addStockTo' : 'consumeStockFrom', itemForAdjustment?.name || '')}
                  </DialogTitle>
                  <DialogDescription>
                    {t(adjustmentType === 'ADD_STOCK' ? 'addStockDialogDesc' : 'consumeStockDialogDesc', itemForAdjustment?.quantity || 0)}
                  </DialogDescription>
                </DialogHeader>
                <Form {...stockAdjustmentForm}>
                  <form onSubmit={stockAdjustmentForm.handleSubmit(onStockAdjustmentSubmit)} className="space-y-4 py-4">
                    <FormField
                      control={stockAdjustmentForm.control}
                      name="adjustmentQuantity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t(adjustmentType === 'ADD_STOCK' ? 'quantityToAdd' : 'quantityToConsume')}</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={stockAdjustmentForm.control}
                      name="comment"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('commentOptional')}</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder={t(adjustmentType === 'ADD_STOCK' ? 'commentPlaceholderAdd' : 'commentPlaceholderConsume')}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <DialogFooter>
                      <DialogClose asChild>
                        <Button type="button" variant="outline">{t('cancel')}</Button>
                      </DialogClose>
                      <Button type="submit">
                        {t(adjustmentType === 'ADD_STOCK' ? 'addStock' : 'consumeStock')}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
            {itemToArchive && (
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>{t('archiveItemTitle', itemToArchive.name)}</AlertDialogTitle>
                  <AlertDialogDescription>
                    {t('archiveItemDesc')}
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel onClick={() => setItemToArchive(null)}>{t('cancel')}</AlertDialogCancel>
                  <AlertDialogAction onClick={handleArchiveItem} className="bg-destructive hover:bg-destructive/90">
                    {t('archiveItem')}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            )}
          </AlertDialog>
        </TooltipProvider>
      </div>
    </>
  );
}
