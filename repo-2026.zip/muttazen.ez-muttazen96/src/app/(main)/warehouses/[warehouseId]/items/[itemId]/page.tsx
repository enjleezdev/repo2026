
'use client';

import * as React from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { format } from 'date-fns';
import { createClient } from '@/lib/supabase';
import type { User } from '@supabase/supabase-js';

import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, Download, ListChecks } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { LoadingSpinner } from '@/components/LoadingSpinner';
import type { Item, Warehouse, HistoryEntry, UserProfile } from '@/lib/types';
import { PrintableItemReport } from '@/components/PrintableItemReport';
import { cn } from '@/lib/utils';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useLanguage } from '@/contexts/LanguageContext';
import html2pdf from 'html2pdf.js';
import { EmptyState } from '@/components/EmptyState';

const generateFilename = (parts: string[]) => {
  const now = new Date();
  const timestamp = `${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}${now.getHours().toString().padStart(2, '0')}${now.getMinutes().toString().padStart(2, '0')}${now.getSeconds().toString().padStart(2, '0')}`;
  return [...parts, timestamp].join('-').replace(/[^a-zA-Z0-9-]/g, '_');
};

const FormattedComment = ({ comment }: { comment?: string }) => {
  if (!comment) {
    return <span className="text-muted-foreground">N/A</span>;
  }

  const typeMatch = comment.match(/^\[(.*?)\]/);
  const byMatch = comment.match(/by (.*?)\./);
  const invoiceMatch = comment.match(/Invoice: (.*?)\./);
  const dateMatch = comment.match(/Date: (.*?)\./);
  const userCommentMatch = comment.match(/Comment: (.*)/);

  const type = typeMatch ? `[${typeMatch[1]}]` : null;
  const by = byMatch ? `by ${byMatch[1]}.` : null;
  const invoice = invoiceMatch ? `Invoice: ${invoiceMatch[1]}.` : null;
  const date = dateMatch ? `Date: ${dateMatch[1]}.` : null;
  const userComment = userCommentMatch ? userCommentMatch[1] : null;

  // Check if any structured data was found. If not, display the raw comment.
  if (!type && !by && !invoice && !date && !userComment) {
    return <p className="break-words">{comment}</p>;
  }

  return (
    <div className="flex flex-col text-xs space-y-0.5">
      {type && <div className="font-semibold text-foreground">{type}</div>}
      {by && <div className="text-muted-foreground">{by}</div>}
      {invoice && <div className="text-muted-foreground">{invoice}</div>}
      {date && <div className="text-muted-foreground">{date}</div>}
      {userComment && <div className="pt-1 italic">"{userComment}"</div>}
    </div>
  );
};


export default function ItemHistoryPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const { t } = useLanguage();
  const { warehouseId, itemId } = params as { warehouseId: string; itemId: string };
  const supabase = createClient();

  const [item, setItem] = React.useState<Item | null>(null);
  const [warehouse, setWarehouse] = React.useState<Warehouse | null>(null);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isDownloading, setIsDownloading] = React.useState(false);
  const [currentUser, setCurrentUser] = React.useState<User | null>(null);
  const [userProfile, setUserProfile] = React.useState<UserProfile | null>(null);
  const reportContainerRef = React.useRef<HTMLDivElement>(null);
  
  const isValidDate = (date: any) => date && !isNaN(new Date(date).getTime());

  React.useEffect(() => {
    async function loadData() {
      if (!warehouseId || !itemId) {
        toast({ title: t('error'), description: "ID missing.", variant: "destructive" });
        router.push('/warehouses');
        return;
      }
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/signin');
        return;
      }
      setCurrentUser(user);
      setIsLoading(true);

      try {
        const [itemRes, warehouseRes, profileRes] = await Promise.all([
          supabase.from('items').select('*').eq('id', itemId).single(),
          supabase.from('warehouses').select('*').eq('id', warehouseId).single(),
          supabase.from('profiles').select('*').eq('id', user.id).single()
        ]);

        if (itemRes.error || !itemRes.data) throw new Error("Item not found");
        if (warehouseRes.error || !warehouseRes.data) throw new Error("Warehouse not found");
        
        setItem({ ...itemRes.data, history: itemRes.data.history || [] });
        setWarehouse(warehouseRes.data);
        setUserProfile(profileRes.data as UserProfile);

      } catch (error: any) {
        toast({ title: t('error'), description: error.message, variant: 'destructive' });
        router.push(`/warehouses/${warehouseId}`);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, [itemId, warehouseId, router, supabase, toast, t]);

  const handleDownloadReport = () => {
    if (!item || !warehouse) return;
    setIsDownloading(true);

    setTimeout(() => {
        if (!reportContainerRef.current) {
            toast({ title: t('error'), description: 'Report element not found.', variant: 'destructive'});
            setIsDownloading(false);
            return;
        }

        const filename = generateFilename([warehouse.name, item.name, 'History']);

        html2pdf().from(reportContainerRef.current).set({
            margin: [15, 15, 15, 15],
            filename: `${filename}.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true, logging: false },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        }).save().then(() => {
            setIsDownloading(false);
        }).catch(err => {
            setIsDownloading(false);
            toast({ title: t('error'), description: 'Failed to generate PDF.', variant: 'destructive'});
            console.error(err);
        });
    }, 100);
  };

  if (isLoading || !item) {
    return <div className="flex justify-center items-center h-[calc(100vh-200px)]"><LoadingSpinner size={48} /></div>;
  }

  return (
    <>
      <div className="absolute -z-50 invisible opacity-0">
        <div ref={reportContainerRef}>
          <PrintableItemReport
            warehouseName={warehouse?.name}
            item={item}
            printedBy={userProfile?.username || currentUser?.email || 'User'}
            printDate={new Date()}
          />
        </div>
      </div>
      
      <PageHeader
        title={t('transactionHistoryFor', item.name)}
        description={t('inWarehouse', warehouse?.name || '...')}
        actions={
          <div className="flex gap-2">
            <Button variant="outline" asChild>
              <Link href={`/warehouses/${warehouseId}`}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                {t('back')}
              </Link>
            </Button>
            <Button onClick={handleDownloadReport} disabled={isDownloading}>
                {isDownloading ? <LoadingSpinner size={16} className="mr-2"/> : <Download className="mr-2 h-4 w-4" />}
                {t('download_report', 'PDF')}
            </Button>
          </div>
        }
      />

      <Card>
        <CardContent className="pt-6">
          {isLoading ? (
            <div className="flex justify-center items-center h-[200px]"><LoadingSpinner /></div>
          ) : item.history && item.history.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('date')}</TableHead>
                  <TableHead className="text-center">{t('before_label')}</TableHead>
                  <TableHead className="text-center">{t('after_label')}</TableHead>
                  <TableHead>{t('commentOptional')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[...(item.history || [])].sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).map((entry) => (
                  <TableRow key={entry.id}>
                      <TableCell>
                      {isValidDate(entry.timestamp) ? (
                        <div className="flex flex-col">
                          <span className="font-medium whitespace-nowrap">{format(new Date(entry.timestamp), "P")}</span>
                          <span className="text-xs text-muted-foreground whitespace-nowrap">{format(new Date(entry.timestamp), "p")}</span>
                          <div className={cn(
                            'text-sm font-bold whitespace-nowrap mt-1',
                            entry.change >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                          )}>
                            {entry.change > 0 ? `+${entry.change}` : entry.change}
                          </div>
                        </div>
                      ) : 'Invalid date'}
                    </TableCell>
                    <TableCell className="text-center whitespace-nowrap">{entry.quantityBefore}</TableCell>
                    <TableCell className="text-center font-semibold whitespace-nowrap">{entry.quantityAfter}</TableCell>
                    <TableCell>
                      <FormattedComment comment={entry.comment} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
             <EmptyState
                IconComponent={ListChecks}
                title={t('noTransactionsFound')}
                description={"No transaction history for this item."}
              />
          )}
        </CardContent>
      </Card>
    </>
  );
}
