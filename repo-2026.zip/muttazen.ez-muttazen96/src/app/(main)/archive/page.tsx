
'use client';

import * as React from 'react';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Package, Warehouse as WarehouseIcon, RotateCcw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Warehouse, Item } from '@/lib/types';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { EmptyState } from '@/components/EmptyState';
import { format } from 'date-fns';
import { createClient } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useLanguage } from '@/contexts/LanguageContext';

export default function ArchivePage() {
  const { toast } = useToast();
  const router = useRouter();
  const { t } = useLanguage();
  const [archivedWarehouses, setArchivedWarehouses] = React.useState<Warehouse[]>([]);
  const [allWarehousesMap, setAllWarehousesMap] = React.useState<Map<string, string>>(new Map());
  const [archivedItems, setArchivedItems] = React.useState<Item[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const supabase = createClient();
  
  const canRestore = true; // Simplified for now

  const loadArchivedData = React.useCallback(async () => {
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
        router.push('/signin');
        return;
    }
    setIsLoading(true);

    try {
        
      // Load all warehouses to get names for items
      const { data: allWhData, error: allWhError } = await supabase
        .from('warehouses')
        .select('id, name');
      if (allWhError) throw allWhError;

      const whMap = new Map<string, string>();
      allWhData.forEach(wh => {
        whMap.set(wh.id, wh.name);
      });
      setAllWarehousesMap(whMap);

      // Load archived warehouses
      const { data: archivedWhData, error: archivedWhError } = await supabase
        .from('warehouses')
        .select('*')
        .eq('is_archived', true)
        .order('updated_at', { ascending: false });
      if (archivedWhError) throw archivedWhError;
      setArchivedWarehouses(archivedWhData as Warehouse[]);

      // Load archived items
      const { data: archivedItemsData, error: archivedItemsError } = await supabase
        .from('items')
        .select('*')
        .eq('is_archived', true)
        .order('updated_at', { ascending: false });
      if (archivedItemsError) throw archivedItemsError;
      setArchivedItems(archivedItemsData.map(item => ({...item, history: item.history || []})) as Item[]);

    } catch (error: any) {
      console.error("Failed to load archived data from Supabase", error);
      toast({ title: t('error'), description: error.message || "Failed to load archived data.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }, [toast, supabase, router, t]);

  React.useEffect(() => {
    loadArchivedData();
  }, [loadArchivedData]);

  const getWarehouseName = (warehouseId: string): string => {
    return allWarehousesMap.get(warehouseId) || "Unknown Warehouse";
  };

  const handleRestoreWarehouse = async (warehouseId: string) => {
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('warehouses')
        .update({ is_archived: false, updated_at: new Date().toISOString() })
        .eq('id', warehouseId);
      if (error) throw error;

      toast({ title: t('warehouseRestored'), description: t('warehouseRestoredDesc') });
      loadArchivedData();
    } catch (error: any) {
      console.error("Failed to restore warehouse from Supabase", error);
      toast({ title: t('error'), description: error.message || "Failed to restore warehouse.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRestoreItem = async (itemId: string) => {
    setIsLoading(true);
    try {
        const { data: itemToRestore, error: itemError } = await supabase
            .from('items')
            .select('warehouse_id')
            .eq('id', itemId)
            .single();
        if (itemError) throw itemError;

      const { error } = await supabase
        .from('items')
        .update({ is_archived: false, updated_at: new Date().toISOString() })
        .eq('id', itemId);
      if (error) throw error;

      toast({ title: t('itemRestored'), description: t('itemRestoredDesc') });
      
      if (itemToRestore.warehouse_id) {
        await supabase.from('warehouses').update({updated_at: new Date().toISOString()}).eq('id', itemToRestore.warehouse_id);
      }
      loadArchivedData();
    } catch (error: any) {
      console.error("Failed to restore item from Supabase", error);
      toast({ title: t('error'), description: error.message || "Failed to restore item.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };


  if (isLoading && archivedWarehouses.length === 0 && archivedItems.length === 0) {
    return <div className="flex justify-center items-center h-[calc(100vh-200px)]"><LoadingSpinner size={48} /></div>;
  }

  return (
    <>
      <PageHeader
        title={t('archiveTitle')}
        description={t('archiveDescription')}
      />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle>{t('archivedWarehouses')}</CardTitle>
            <CardDescription>{t('archivedWarehousesDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading && archivedWarehouses.length === 0 ? <LoadingSpinner className="mx-auto my-4" /> :
            archivedWarehouses.length === 0 ? (
              <EmptyState
                IconComponent={WarehouseIcon}
                title={t('noArchivedWarehouses')}
                description={t('noArchivedWarehousesDesc')}
              />
            ) : (
              <div className="h-[400px] w-full rounded-md border">
                <Table>
                  <TableHeader className="sticky top-0 bg-background/90 dark:bg-card/80 backdrop-blur-sm z-10">
                    <TableRow>
                      <TableHead className="py-3 px-4 text-left font-medium text-muted-foreground break-words">{t('name')}</TableHead>
                      <TableHead className="py-3 px-4 text-left font-medium text-muted-foreground break-words">{t('description')}</TableHead>
                       <TableHead className="py-3 px-4 text-left font-medium text-muted-foreground whitespace-nowrap">{t('archivedOn')}</TableHead>
                      <TableHead className="py-3 px-4 text-right font-medium text-muted-foreground whitespace-nowrap">{t('actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {archivedWarehouses.map((wh) => (
                      <TableRow key={wh.id} className="border-b border-border/50 last:border-b-0 hover:bg-muted/10 dark:hover:bg-muted/5">
                        <TableCell className="py-3 px-4 font-medium break-words">{wh.name}</TableCell>
                        <TableCell className="py-3 px-4 text-sm text-muted-foreground break-words">{wh.description || 'N/A'}</TableCell>
                        <TableCell className="py-3 px-4 text-xs whitespace-nowrap">
                          {wh.updated_at ? format(new Date(wh.updated_at), 'P p') : 'N/A'}
                        </TableCell>
                        <TableCell className="py-3 px-4 text-right whitespace-nowrap">
                          {canRestore && (
                            <Button variant="outline" size="sm" onClick={() => handleRestoreWarehouse(wh.id)}>
                              <RotateCcw className="mr-2 h-3 w-3" /> {t('restore')}
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle>{t('archivedItems')}</CardTitle>
            <CardDescription>{t('archivedItemsDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
             {isLoading && archivedItems.length === 0 ? <LoadingSpinner className="mx-auto my-4" /> :
             archivedItems.length === 0 ? (
              <EmptyState
                IconComponent={Package}
                title={t('noArchivedItems')}
                description={t('noArchivedItemsDesc')}
              />
            ) : (
              <div className="h-[400px] w-full rounded-md border">
                 <Table>
                  <TableHeader className="sticky top-0 bg-background/90 dark:bg-card/80 backdrop-blur-sm z-10">
                    <TableRow>
                      <TableHead className="py-3 px-4 text-left font-medium text-muted-foreground break-words">{t('name')}</TableHead>
                      <TableHead className="py-3 px-4 text-left font-medium text-muted-foreground break-words">{t('warehouse')}</TableHead>
                      <TableHead className="py-3 px-4 text-right font-medium text-muted-foreground whitespace-nowrap">{t('quantity')}</TableHead>
                      <TableHead className="py-3 px-4 text-left font-medium text-muted-foreground whitespace-nowrap">{t('archivedOn')}</TableHead>
                      <TableHead className="py-3 px-4 text-right font-medium text-muted-foreground whitespace-nowrap">{t('actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {archivedItems.map((item) => (
                      <TableRow key={item.id} className="border-b border-border/50 last:border-b-0 hover:bg-muted/10 dark:hover:bg-muted/5">
                        <TableCell className="py-3 px-4 font-medium break-words">{item.name}</TableCell>
                        <TableCell className="py-3 px-4 break-words">{getWarehouseName(item.warehouse_id)}</TableCell>
                        <TableCell className="py-3 px-4 text-right whitespace-nowrap">{item.quantity}</TableCell>
                        <TableCell className="py-3 px-4 text-xs whitespace-nowrap">
                          {item.updated_at ? format(new Date(item.updated_at), 'P p') : 'N/A'}
                        </TableCell>
                        <TableCell className="py-3 px-4 text-right whitespace-nowrap">
                          {canRestore && (
                            <Button variant="outline" size="sm" onClick={() => handleRestoreItem(item.id)}>
                              <RotateCcw className="mr-2 h-3 w-3" /> {t('restore')}
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
