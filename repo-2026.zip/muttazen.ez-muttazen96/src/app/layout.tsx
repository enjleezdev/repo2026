'use client'; // Required to use context and hooks

import { Almarai } from 'next/font/google';
import './globals.css';
import { Toaster } from "@/components/ui/toaster";
import { LanguageProvider, useLanguage } from '@/contexts/LanguageContext';
import { useEffect } from 'react';
import { ThemeProvider } from '@/components/ThemeProvider';

const almarai = Almarai({
  weight: ['400', '700'],
  subsets: ['arabic'],
  variable: '--font-almarai',
});

// A wrapper component to apply language settings to the HTML element
function LanguageSetter({ children }: { children: React.ReactNode }) {
  const { language, dir, t } = useLanguage();

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = dir;
    document.title = t('appName'); // Update title dynamically
  }, [language, dir, t]);

  return <>{children}</>;
}


export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <LanguageProvider>
      {/*
        The suppressHydrationWarning is important because we are setting lang/dir
        on the client side, and it might differ from the server-rendered HTML.
      */}
      <html lang="en" suppressHydrationWarning={true} translate="no">
        <head>
          <link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png"/>
          <link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png"/>
          <link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png"/>
          <link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png"/>
          <link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png"/>
          <link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png"/>
          <link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png"/>
          <link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png"/>
          <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png"/>
          <link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png"/>
          <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png"/>
          <link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png"/>
          <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png"/>
          <link rel="manifest" href="/manifest.json" />
          <meta name="msapplication-TileColor" content="#ffffff"/>
          <meta name="msapplication-TileImage" content="/ms-icon-144x144.png"/>
          <meta name="theme-color" content="#ffffff"/>
          <meta name="msapplication-config" content="/browserconfig.xml" />
        </head>
        <body className={`${almarai.variable} font-sans antialiased`}>
          <ThemeProvider
            attribute="class"
            defaultTheme="system"
            enableSystem
            disableTransitionOnChange
          >
            <LanguageSetter>
              {children}
              <Toaster />
            </LanguageSetter>
          </ThemeProvider>
        </body>
      </html>
    </LanguageProvider>
  );
}
