
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { Eye, EyeOff } from 'lucide-react';

const updatePasswordFormSchema = z.object({
  password: z.string().min(6, { message: "Password must be at least 6 characters." }),
  confirmPassword: z.string(),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match.",
  path: ['confirmPassword'],
});

type UpdatePasswordFormValues = z.infer<typeof updatePasswordFormSchema>;

enum AuthState {
  CHECKING,
  AUTHENTICATED,
  ERROR,
}

export default function UpdatePasswordPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [authState, setAuthState] = React.useState<AuthState>(AuthState.CHECKING);
  const [isLoading, setIsLoading] = React.useState(false);
  const [showPassword, setShowPassword] = React.useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = React.useState(false);
  const supabase = createClient();

  React.useEffect(() => {
    // This effect runs only on the client side
    const handleAuth = async () => {
      // Supabase invite links and password recovery links put the token in the URL hash
      const hash = window.location.hash;
      if (!hash) {
        // If there's no hash, maybe the user is already logged in and wants to change password.
        // Let's check for an active session.
        const { data: { session } } = await supabase.auth.getSession();
        if (session) {
            setAuthState(AuthState.AUTHENTICATED);
        } else {
            // No hash and no session, this is an invalid state.
            setAuthState(AuthState.ERROR);
        }
        return;
      }
      
      const params = new URLSearchParams(hash.substring(1)); // remove the '#'
      const accessToken = params.get('access_token');
      const refreshToken = params.get('refresh_token');
      const type = params.get('type');

      if (type === 'recovery' || type === 'invite') {
          if (accessToken && refreshToken) {
              const { error } = await supabase.auth.setSession({
                  access_token: accessToken,
                  refresh_token: refreshToken,
              });

              if (error) {
                  console.error("Error setting session:", error);
                  setAuthState(AuthState.ERROR);
              } else {
                  // Successfully authenticated, user can now update their password.
                  setAuthState(AuthState.AUTHENTICATED);
                  // Clean the URL
                  router.replace('/update-password', { scroll: false });
              }
          } else {
              console.error("Access token or refresh token missing from URL hash.");
              setAuthState(AuthState.ERROR);
          }
      } else {
          // If the type is not recovery or invite, maybe it's a normal logged-in user
          const { data: { session } } = await supabase.auth.getSession();
           if (session) {
               setAuthState(AuthState.AUTHENTICATED);
           } else {
               setAuthState(AuthState.ERROR);
           }
      }
    };

    handleAuth();
  }, [supabase, router]);


  const form = useForm<UpdatePasswordFormValues>({
    resolver: zodResolver(updatePasswordFormSchema),
    defaultValues: {
      password: '',
      confirmPassword: '',
    },
  });

  async function onSubmit(data: UpdatePasswordFormValues) {
    setIsLoading(true);
    
    const { error } = await supabase.auth.updateUser({ password: data.password });

    if (error) {
      toast({
        title: 'Error updating password',
        description: error.message,
        variant: 'destructive',
      });
      setIsLoading(false);
    } else {
      toast({
        title: 'Password updated successfully',
        description: 'You can now sign in with your new password.',
      });
      await supabase.auth.signOut();
      router.push('/signin');
    }
  }

  if (authState === AuthState.CHECKING) {
      return (
          <div className="flex flex-col items-center justify-center p-8 text-center">
              <LoadingSpinner size={32} />
              <p className="mt-4 text-muted-foreground">Verifying authentication...</p>
          </div>
      );
  }
  
  if (authState === AuthState.ERROR) {
      return (
          <Card className="w-full">
              <CardHeader>
                  <CardTitle>Authentication Error</CardTitle>
                  <CardDescription>
                      The link is invalid or has expired. Please request a new one.
                  </CardDescription>
              </CardHeader>
              <CardContent>
                  <Button onClick={() => router.push('/signin')} className="w-full">
                      Back to Sign In
                  </Button>
              </CardContent>
          </Card>
      );
  }


  return (
    <Card className="w-full">
      <CardHeader className="space-y-1 text-center">
        <CardTitle className="text-2xl font-bold">Set Your New Password</CardTitle>
        <CardDescription>
          Please enter and confirm your new password below.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>New Password</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input 
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Enter your new password" 
                        {...field} 
                      />
                       <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 flex items-center pr-3">
                          {showPassword ? <EyeOff className="h-5 w-5 text-muted-foreground" /> : <Eye className="h-5 w-5 text-muted-foreground" />}
                        </button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Confirm New Password</FormLabel>
                  <FormControl>
                     <div className="relative">
                      <Input 
                        type={showConfirmPassword ? 'text' : 'password'}
                        placeholder="Confirm your new password" 
                        {...field} 
                      />
                       <button type="button" onClick={() => setShowConfirmPassword(!showConfirmPassword)} className="absolute inset-y-0 right-0 flex items-center pr-3">
                          {showConfirmPassword ? <EyeOff className="h-5 w-5 text-muted-foreground" /> : <Eye className="h-5 w-5 text-muted-foreground" />}
                        </button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? <LoadingSpinner size={16} className="mr-2" /> : null}
              Update Password and Sign In
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
