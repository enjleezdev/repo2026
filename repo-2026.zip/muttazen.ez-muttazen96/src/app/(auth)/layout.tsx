
import type { PropsWithChildren } from "react";

export default function AuthLayout({ children }: PropsWithChildren) {
  return (
    <div 
      dir="ltr" 
      className="light flex min-h-screen flex-col items-center justify-center p-4 bg-cover bg-center bg-white"
      style={{ backgroundImage: "url('/auth-bg.png')" }}
    >
      <div className="w-full max-w-md">
        {children}
      </div>
    </div>
  );
}
