
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase';
import Image from 'next/image';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { Eye, EyeOff } from 'lucide-react';
import { SplashScreen } from '@/components/SplashScreen';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const signInFormSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address." }),
  password: z.string().min(1, { message: "Password is required." }),
});

type SignInFormValues = z.infer<typeof signInFormSchema>;

export default function SignInPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = React.useState(false);
  const [showPassword, setShowPassword] = React.useState(false);
  const [showSplashScreen, setShowSplashScreen] = React.useState(false);

  const supabase = createClient();

  const form = useForm<SignInFormValues>({
    resolver: zodResolver(signInFormSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  async function onSubmit(data: SignInFormValues) {
    setIsLoading(true);
    const { error } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password,
    });
    
    if (error) {
        toast({
            title: 'Login Failed',
            description: error.message || "Invalid email or password. Please try again.",
            variant: 'destructive',
        });
        setIsLoading(false);
    } else {
        toast({
            title: 'Login Successful',
            description: 'Welcome back!',
        });
        setShowSplashScreen(true);
        setTimeout(() => {
            router.push('/dashboard');
            router.refresh(); 
        }, 2500);
    }
  }

  if (showSplashScreen) {
    return <SplashScreen />;
  }

  return (
    <Card className="w-full bg-white">
      <CardHeader className="text-center">
        <div className="mx-auto mb-4">
          <Image
            src="/logos/ez.png"
            alt="App Logo"
            width={200}
            height={200}
            className="rounded-md object-contain"
            data-ai-hint="warehouse logistics"
            priority
          />
        </div>
        <CardDescription className="font-semibold">
          <span className="text-[#ff3131]">POWERD BY </span>
          <span className="text-[#311955]">ENJLEEZ TECH</span>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel className="text-gray-800">Email</FormLabel>
                            <FormControl>
                            <Input
                                type="email"
                                className="bg-white border-gray-300 shadow-sm text-black"
                                {...field}
                            />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel className="text-gray-800">Password</FormLabel>
                            <FormControl>
                                <div className="relative flex items-center w-full">
                                <Input
                                    type={showPassword ? "text" : "password"}
                                    className="pr-12 bg-white border-gray-300 shadow-sm text-black"
                                    {...field}
                                />
                                <div
                                    onClick={() => setShowPassword(!showPassword)}
                                    className="absolute right-0 flex items-center justify-center h-full px-4 text-gray-500 cursor-pointer"
                                >
                                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                                </div>
                                </div>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                 <div className="text-right text-sm">
                    <Link href="/forgot-password" passHref legacyBehavior>
                        <a className="text-gray-600 hover:text-primary transition-colors underline-offset-4 hover:underline">
                            Forgot password?
                        </a>
                    </Link>
                </div>
                <Button
                    type="submit"
                    className="w-full"
                    disabled={isLoading}
                >
                    {isLoading ? <LoadingSpinner size={20} /> : "Sign In"}
                </Button>
            </form>
        </Form>
      </CardContent>
    </Card>
  );
}
