/*
  DATABASE MIGRATION (IMPORTANT!): Please copy and run this SQL code in your Supabase SQL Editor.
  This update adds supplier tracking to your inventory operations.

  -- Create the suppliers table
  CREATE TABLE public.suppliers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    owner_id uuid NOT NULL,
    name text NOT NULL,
    contact_person text,
    phone text NOT NULL,
    email text,
    address text,
    notes text,
    is_archived boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT suppliers_pkey PRIMARY KEY (id),
    CONSTRAINT suppliers_email_key UNIQUE (email),
    CONSTRAINT suppliers_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES auth.users(id) ON DELETE CASCADE
  );

  -- Enable Row Level Security for the new table
  ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;

  -- RLS Policies for suppliers
  -- Allow users to view all suppliers
  CREATE POLICY "Allow authenticated users to read all suppliers" ON public.suppliers
  FOR SELECT TO authenticated USING (true);

  -- Allow users to insert suppliers for their own account
  CREATE POLICY "Allow authenticated users to insert their own suppliers" ON public.suppliers
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = owner_id);

  -- Allow users to update their own suppliers
  CREATE POLICY "Allow users to update their own suppliers" ON public.suppliers
  FOR UPDATE TO authenticated USING (auth.uid() = owner_id) WITH CHECK (auth.uid() = owner_id);
  
  -- Add a function to set the updated_at timestamp automatically
  CREATE OR REPLACE FUNCTION public.set_updated_at()
  RETURNS TRIGGER AS $$
  BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
  END;
  $$ LANGUAGE plpgsql;

  -- Create a trigger to call the function before any update on suppliers
  CREATE TRIGGER handle_suppliers_updated_at
  BEFORE UPDATE ON public.suppliers
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

  -- Add new columns to the inventory_operations table to link suppliers
  ALTER TABLE public.inventory_operations
  ADD COLUMN IF NOT EXISTS supplier_id uuid,
  ADD COLUMN IF NOT EXISTS supplier_name text;

  -- Add a foreign key constraint to link to the suppliers table
  -- ON DELETE SET NULL means if a supplier is deleted, the operation record is kept but the link is removed.
  ALTER TABLE public.inventory_operations
  ADD CONSTRAINT inventory_operations_supplier_id_fkey FOREIGN KEY (supplier_id)
  REFERENCES public.suppliers(id) ON DELETE SET NULL;
*/

/*
  EXISTING MIGRATION NOTES:
  This version includes 'ON DELETE CASCADE' to ensure data integrity when items or warehouses are deleted.

  -- Allow authenticated users to read their own notifications
  CREATE POLICY "Allow authenticated users to read their own notifications"
  ON public.notifications FOR SELECT
  TO authenticated
  USING (auth.uid() = owner_id);
  
  -- Allow authenticated users to read all warehouses
  CREATE POLICY "Allow authenticated users to read all warehouses"
  ON public.warehouses FOR SELECT
  TO authenticated
  USING (true);

  -- Allow authenticated users to read all items
  CREATE POLICY "Allow authenticated users to read all items"
  ON public.items FOR SELECT
  TO authenticated
  USING (true);


  -- This function is DEPRECATED and no longer used. You can safely drop it.
  -- DROP FUNCTION IF EXISTS public.get_all_operations_in_range(timestamptz, timestamptz);


  CREATE TABLE public.inventory_operations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    type text NOT NULL,
    item_id uuid NOT NULL,
    item_name text NOT NULL,
    warehouse_id uuid NOT NULL,
    warehouse_name text NOT NULL,
    quantity integer NOT NULL,
    user_id uuid NOT NULL,
    user_name text NOT NULL,
    invoice_number text,
    purchase_date timestamp with time zone,
    comment text,
    original_purchase_id uuid,
    CONSTRAINT inventory_operations_pkey PRIMARY KEY (id),
    CONSTRAINT inventory_operations_item_id_fkey FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
    CONSTRAINT inventory_operations_original_purchase_id_fkey FOREIGN KEY (original_purchase_id) REFERENCES inventory_operations(id) ON DELETE SET NULL,
    CONSTRAINT inventory_operations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE,
    CONSTRAINT inventory_operations_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES warehouses(id) ON DELETE CASCADE
  );

  ALTER TABLE public.inventory_operations ENABLE ROW LEVEL SECURITY;

  CREATE POLICY "Allow authenticated users to read operations" ON public.inventory_operations FOR SELECT TO authenticated USING (true);
  CREATE POLICY "Allow authenticated users to insert their own operations" ON public.inventory_operations FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

  -- UPDATED search_all FUNCTION: Please re-run this in your Supabase SQL editor
  -- to enable searching inventory operations.
  CREATE OR REPLACE FUNCTION search_all(keyword text)
  RETURNS TABLE(
      id uuid,
      type text,
      name text,
      context text,
      warehouse_id uuid
  ) AS $$
  BEGIN
      RETURN QUERY
      -- Search warehouses by name or description
      SELECT
          w.id,
          'warehouse' as type,
          w.name,
          w.description as context,
          NULL as warehouse_id
      FROM
          warehouses w
      WHERE
          w.is_archived = false AND (
              w.name ILIKE '%' || keyword || '%' OR
              w.description ILIKE '%' || keyword || '%'
          )
      
      UNION ALL
      
      -- Search items by name or location
      SELECT
          i.id,
          'item' as type,
          i.name,
          w.name as context, -- Context is the warehouse name
          i.warehouse_id
      FROM
          items i
      JOIN
          warehouses w ON i.warehouse_id = w.id
      WHERE
          i.is_archived = false AND
          w.is_archived = false AND (
              i.name ILIKE '%' || keyword || '%' OR
              i.location ILIKE '%' || keyword || '%'
          )

      UNION ALL

      -- Search inventory operations
      SELECT
          io.id,
          'operation' as type,
          io.item_name,
          'Invoice: ' || COALESCE(io.invoice_number, 'N/A') || ' | ' || io.warehouse_name as context,
          io.warehouse_id
      FROM
          inventory_operations io
      WHERE
          io.invoice_number ILIKE '%' || keyword || '%' OR
          io.item_name ILIKE '%' || keyword || '%' OR
          io.comment ILIKE '%' || keyword || '%';
  END;
  $$ LANGUAGE plpgsql;
*/

export interface Warehouse {
  id: string;
  name: string;
  description?: string;
  is_archived: boolean;
  created_at: string;
  updated_at: string;
  owner_id: string; // Simplified: No organization_id
}

export interface Item {
  id:string;
  warehouse_id: string;
  name: string;
  quantity: number;
  location?: string;
  created_at: string;
  updated_at: string;
  history: HistoryEntry[];
  is_archived: boolean;
  owner_id: string; // Simplified: No organization_id
  low_stock_threshold?: number;
}

export type HistoryEntryType =
  | 'CREATE_ITEM'
  | 'ADD_STOCK'
  | 'CONSUME_STOCK'
  | 'ADJUST_STOCK'
  | 'purchase'
  | 'return'
  | 'damaged';


export interface HistoryEntry {
  id: string;
  type: HistoryEntryType;
  change: number;
  quantityBefore: number;
  quantityAfter: number;
  comment?: string;
  timestamp: string; // ISO string date
  itemId?: string;
  warehouseId?: string;
}

export interface FlattenedHistoryEntry extends HistoryEntry {
  itemName: string;
  warehouseName: string;
  itemId: string;
  warehouseId: string;
}

// Kept for UI, but logic is simplified.
export type UserRole = 'owner' | 'manager' | 'supervisor' | 'worker';

export interface UserProfile {
  id: string;
  username: string;
  email?: string;
  role: UserRole; // Role is kept for potential future use
  username_changed: boolean;
  // organization_id removed
}


export interface Notification {
  id: string;
  owner_id: string;
  type: 'LOW_STOCK' | 'INFO' | 'SUCCESS' | 'AI_SUGGESTION';
  title: string;
  message: string;
  is_read: boolean;
  created_at: string;
  metadata?: {
    itemId?: string;
    warehouseId?: string;
    [key: string]: any;
  };
}

export interface InventoryOperation {
  id: string;
  created_at: string;
  type: 'purchase' | 'return' | 'damaged';
  item_id: string;
  item_name: string;
  warehouse_id: string;
  warehouse_name: string;
  quantity: number;
  user_id: string;
  user_name: string;
  invoice_number?: string;
  purchase_date?: string;
  comment?: string;
  original_purchase_id?: string;
  supplier_id?: string;
  supplier_name?: string;
}

export interface Supplier {
  id: string;
  created_at: string;
  updated_at: string;
  owner_id: string;
  name: string;
  contact_person?: string;
  phone: string;
  email?: string;
  address?: string;
  notes?: string;
  is_archived: boolean;
}
