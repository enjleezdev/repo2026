
import { createBrowserClient } from '@supabase/ssr';

// This function creates and returns a Supabase client for use in the browser.
// It expects SUPABASE_URL and SUPABASE_ANON_KEY to be available in the browser environment.
// For Next.js, you MUST expose these variables by prefixing them with NEXT_PUBLIC_
// in your .env file and referencing them here as process.env.NEXT_PUBLIC_...
export function createClient() {
  // These variables are exposed to the browser by Next.js.
  // You MUST define them in your Netlify settings and/or local .env file
  // with the NEXT_PUBLIC_ prefix.
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

  if (!supabaseUrl || !supabaseAnonKey) {
    // This error means the environment variables were not exposed correctly.
    // Ensure they are named NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
    // in your Netlify settings and/or local .env file.
    throw new Error('Supabase URL or Anon Key is missing from client environment variables.');
  }

  return createBrowserClient(supabaseUrl, supabaseAnonKey);
}
