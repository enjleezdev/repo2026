-- 1. Enable Row Level Security (RLS) for the 'profiles' table.
-- RLS is a security feature that ensures users can only access their own data.
-- We will define specific policies later.
alter table "profiles" enable row level security;

-- 2. Define a custom type for user roles.
-- Using a custom type ensures that the 'role' column can only have these specific values.
create type public.user_role as enum ('owner', 'manager', 'supervisor', 'worker');

-- 3. Create the 'organizations' table.
-- Each organization represents a company or a main user account.
create table public.organizations (
    id uuid not null primary key default uuid_generate_v4(),
    name text
);
comment on table public.organizations is 'Represents a company or organization in the system.';


-- 4. Create the 'profiles' table.
-- This table stores additional information for each user, linking them to an organization and a role.
-- It references the 'auth.users' table provided by Supabase authentication.
create table public.profiles (
    id uuid not null primary key references auth.users on delete cascade,
    organization_id uuid references public.organizations on delete cascade,
    username text,
    role public.user_role,
    username_changed boolean default false
);
comment on table public.profiles is 'Stores user-specific data like their role and organization.';

-- 5. Create a security policy for the 'organizations' table.
-- This policy allows users to see their own organization's record.
-- The `auth.uid() = (select organization_id from profiles where profiles.id = auth.uid())` part is a bit indirect.
-- A better way is to check if the user is part of that organization via the profiles table.
-- This policy allows a user to see the organization they belong to.
create policy "Users can view their own organization"
on public.organizations for select
using ( auth.uid() IN (SELECT id FROM profiles WHERE organization_id = public.organizations.id) );


-- 6. Create security policies for the 'profiles' table.
-- Policy 1: Allows users to see all profiles within their own organization.
-- This is useful for managers or owners to see their team members.
create policy "Users can view profiles in their own organization"
on public.profiles for select
using (organization_id = (select organization_id from profiles where id = auth.uid()));

-- Policy 2: Allows users to update their own profile information.
create policy "Users can update their own profile"
on public.profiles for update
using (id = auth.uid());


-- 7. Create a server-side function to handle new user sign-ups.
-- This function will automatically create an organization and a profile for a new user.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  new_organization_id uuid;
  user_email text;
  username_from_email text;
begin
  -- Create a new organization for the new user.
  insert into public.organizations (name)
  values (new.email) -- Or use a default name like 'My Organization'
  returning id into new_organization_id;

  -- Extract username from email
  user_email := new.email;
  username_from_email := split_part(user_email, '@', 1);

  -- Create a profile for the new user, setting them as the 'owner'.
  insert into public.profiles (id, organization_id, role, username, email)
  values (new.id, new_organization_id, 'owner', username_from_email, user_email);

  return new;
end;
$$;

-- 8. Create a trigger that calls the 'handle_new_user' function.
-- This trigger will fire automatically after a new user is created in the 'auth.users' table.
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 9. Create placeholder tables for Warehouses, Items, and Notifications with RLS enabled.
-- This ensures the basic structure is ready for future development.

-- Warehouses Table
create table public.warehouses (
    id uuid not null primary key default uuid_generate_v4(),
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
    owner_id uuid references auth.users on delete cascade,
    name text not null,
    description text,
    is_archived boolean default false
);
alter table public.warehouses enable row level security;
create policy "Users can manage their own warehouses" on public.warehouses for all
using (owner_id = auth.uid());

-- Items Table
create table public.items (
    id uuid not null primary key default uuid_generate_v4(),
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
    owner_id uuid references auth.users on delete cascade,
    warehouse_id uuid references public.warehouses on delete cascade,
    name text not null,
    quantity integer not null,
    low_stock_threshold integer,
    location text,
    is_archived boolean default false,
    history jsonb[]
);
alter table public.items enable row level security;
create policy "Users can manage their own items" on public.items for all
using (owner_id = auth.uid());

-- Notifications Table
create table public.notifications (
    id uuid not null primary key default uuid_generate_v4(),
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    owner_id uuid references auth.users on delete cascade,
    type text not null,
    title text not null,
    message text not null,
    is_read boolean default false,
    metadata jsonb
);
alter table public.notifications enable row level security;
create policy "Users can manage their own notifications" on public.notifications for all
using (owner_id = auth.uid());
