-- 1. Enable Row Level Security (RLS) on the 'profiles' table
-- This ensures that users can only access their own profile data.
alter table public.profiles
  enable row level security;

-- 2. Create policies for the 'profiles' table
-- Policy 1: Allows users to see their own profile.
create policy "Users can view their own profile." on profiles
  for select using (auth.uid() = id);

-- Policy 2: Allows users to update their own profile.
create policy "Users can update their own profile." on profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

-- 3. Create a function to handle new user setup
-- This function will be called by a trigger whenever a new user signs up.
-- It creates a new organization and a profile for the new user, setting them as the owner.
create or replace function public.handle_new_user()
returns trigger as $$
declare
  new_org_id uuid;
begin
  -- Create a new organization for the new user
  insert into public.organizations (name)
  values (new.email)
  returning id into new_org_id;

  -- Create a new profile for the new user and link it to the new organization
  insert into public.profiles (id, org_id, role)
  values (new.id, new_org_id, 'owner');
  
  return new;
end;
$$ language plpgsql security definer;

-- 4. Create a trigger to call the function when a new user is created
-- This trigger fires after a new record is inserted into the 'auth.users' table.
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 5. Add RLS policies for the 'warehouses' table
alter table public.warehouses enable row level security;

create policy "Users can view their own warehouses." on warehouses
  for select using (auth.uid() = owner_id);

create policy "Users can insert their own warehouses." on warehouses
  for insert with check (auth.uid() = owner_id);

create policy "Users can update their own warehouses." on warehouses
  for update using (auth.uid() = owner_id);

create policy "Owner can delete their own warehouses." on warehouses
  for delete using (auth.uid() = owner_id);

-- 6. Add RLS policies for the 'items' table
alter table public.items enable row level security;

create policy "Users can view their own items." on items
  for select using (auth.uid() = owner_id);

create policy "Users can insert their own items." on items
  for insert with check (auth.uid() = owner_id);

create policy "Users can update their own items." on items
  for update using (auth.uid() = owner_id);

create policy "Users can delete their own items." on items
  for delete using (auth.uid() = owner_id);

-- 7. Add RLS policies for the 'notifications' table
alter table public.notifications enable row level security;

create policy "Users can view their own notifications." on notifications
  for select using (auth.uid() = owner_id);

create policy "Users can insert their own notifications." on notifications
  for insert with check (auth.uid() = owner_id);

create policy "Users can update their own notifications." on notifications
  for update using (auth.uid() = owner_id);

create policy "Users can delete their own notifications." on notifications
  for delete using (auth.uid() = owner_id);
