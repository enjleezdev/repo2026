-- This file contains the SQL commands to enable Row Level Security (RLS)
-- and create the policies for the simplified application model.
-- You can run this in the SQL Editor of your new Supabase project
-- AFTER you have created the tables using tables.sql.

-- Enable RLS for all tables
ALTER TABLE public.warehouses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- POLICIES for warehouses table
-- 1. Users can see their own warehouses
CREATE POLICY "Users can view their own warehouses"
ON public.warehouses FOR SELECT
USING (auth.uid() = owner_id);
-- 2. Users can insert new warehouses for themselves
CREATE POLICY "Users can insert their own warehouses"
ON public.warehouses FOR INSERT
WITH CHECK (auth.uid() = owner_id);
-- 3. Users can update their own warehouses
CREATE POLICY "Users can update their own warehouses"
ON public.warehouses FOR UPDATE
USING (auth.uid() = owner_id);
-- 4. Users can delete their own warehouses
CREATE POLICY "Users can delete their own warehouses"
ON public.warehouses FOR DELETE
USING (auth.uid() = owner_id);


-- POLICIES for items table
-- 1. Users can see their own items
CREATE POLICY "Users can view their own items"
ON public.items FOR SELECT
USING (auth.uid() = owner_id);
-- 2. Users can insert new items for themselves
CREATE POLICY "Users can insert their own items"
ON public.items FOR INSERT
WITH CHECK (auth.uid() = owner_id);
-- 3. Users can update their own items
CREATE POLICY "Users can update their own items"
ON public.items FOR UPDATE
USING (auth.uid() = owner_id);
-- 4. Users can delete their own items
CREATE POLICY "Users can delete their own items"
ON public.items FOR DELETE
USING (auth.uid() = owner_id);


-- POLICIES for profiles table
-- 1. Users can see their own profile
CREATE POLICY "Users can view their own profile"
ON public.profiles FOR SELECT
USING (auth.uid() = id);
-- 2. Users can update their own profile
CREATE POLICY "Users can update their own profile"
ON public.profiles FOR UPDATE
USING (auth.uid() = id);


-- POLICIES for notifications table
-- 1. Users can see their own notifications
CREATE POLICY "Users can view their own notifications"
ON public.notifications FOR SELECT
USING (auth.uid() = owner_id);
-- 2. Users can insert new notifications for themselves
CREATE POLICY "Users can insert their own notifications"
ON public.notifications FOR INSERT
WITH CHECK (auth.uid() = owner_id);
-- 3. Users can update their own notifications
CREATE POLICY "Users can update their own notifications"
ON public.notifications FOR UPDATE
USING (auth.uid() = owner_id);
-- 4. Users can delete their own notifications
CREATE POLICY "Users can delete their own notifications"
ON public.notifications FOR DELETE
USING (auth.uid() = owner_id);
