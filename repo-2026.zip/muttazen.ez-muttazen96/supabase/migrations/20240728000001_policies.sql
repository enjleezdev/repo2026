-- This file contains the Row Level Security (RLS) policies for the application.
-- RLS ensures that users can only access their own data.
-- You can run this in the SQL Editor of your Supabase project after creating the tables.

-- Enable RLS for all tables
ALTER TABLE public.warehouses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist, to ensure a clean state
DROP POLICY IF EXISTS "Users can manage their own warehouses" ON public.warehouses;
DROP POLICY IF EXISTS "Users can manage their own items" ON public.items;
DROP POLICY IF EXISTS "Users can view and update their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can manage their own notifications" ON public.notifications;

-- Policies for 'warehouses' table
CREATE POLICY "Users can manage their own warehouses"
ON public.warehouses
FOR ALL
USING (auth.uid() = owner_id);

-- Policies for 'items' table
CREATE POLICY "Users can manage their own items"
ON public.items
FOR ALL
USING (auth.uid() = owner_id);

-- Policies for 'profiles' table
CREATE POLICY "Users can view and update their own profile"
ON public.profiles
FOR ALL
USING (auth.uid() = id);

-- Policies for 'notifications' table
CREATE POLICY "Users can manage their own notifications"
ON public.notifications
FOR ALL
USING (auth.uid() = owner_id);
