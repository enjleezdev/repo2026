
-- Define a custom type for user roles
create type public.user_role as enum ('owner', 'manager', 'supervisor', 'worker');

-- Create the organizations table
create table public.organizations (
    id uuid not null default gen_random_uuid() primary key,
    name text
);
comment on table public.organizations is 'Represents a company or organization in the system.';

-- Create the profiles table to store user-specific data
create table public.profiles (
    id uuid not null primary key,
    updated_at timestamp with time zone,
    username text,
    full_name text,
    avatar_url text,
    website text,
    organization_id uuid not null references public.organizations(id) on delete cascade,
    role public.user_role not null default 'worker',

    constraint username_length check (char_length(username) >= 3),
    foreign key (id) references auth.users(id) on delete cascade
);
comment on table public.profiles is 'Stores public profile information for each user.';

-- Set up Row Level Security (RLS)
alter table public.profiles enable row level security;
alter table public.organizations enable row level security;

-- Create policy for profiles: Users can see their own profile and profiles of others in their organization.
create policy "Users can view their own and team profiles."
on public.profiles for select
using (
  auth.uid() = id OR
  organization_id = (select organization_id from public.profiles where id = auth.uid())
);

-- Create policy for profiles: Users can update their own profile.
create policy "Users can update their own profile."
on public.profiles for update
using (auth.uid() = id);


-- Create policy for organizations: Users can see their own organization's details.
create policy "Users can view their own organization."
on public.organizations for select
using (
  id = (select organization_id from public.profiles where id = auth.uid())
);

-- Inserts a row into public.profiles when a new user signs up.
-- This part is now handled by the trigger in the next migration file.

-- This function helps retrieve the organization ID for the currently authenticated user.
create or replace function public.get_my_organization_id()
returns uuid
language sql
security definer
set search_path = public
as $$
    select organization_id from public.profiles where id = auth.uid();
$$;

-- This function helps retrieve the role for the currently authenticated user.
create or replace function public.get_my_role()
returns public.user_role
language sql
security definer
set search_path = public
as $$
    select role from public.profiles where id = auth.uid();
$$;

