
-- This function is triggered when a new user is created in the auth.users table.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  new_org_id uuid;
begin
  -- Create a new organization for the new user
  insert into public.organizations (name)
  values (new.raw_user_meta_data->>'full_name' || '''s Organization')
  returning id into new_org_id;

  -- Create a profile for the new user, linking them to the new organization and setting their role to 'owner'
  insert into public.profiles (id, organization_id, full_name, role)
  values (new.id, new_org_id, new.raw_user_meta_data->>'full_name', 'owner');
  
  return new;
end;
$$;

-- create the trigger that fires the handle_new_user function
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

