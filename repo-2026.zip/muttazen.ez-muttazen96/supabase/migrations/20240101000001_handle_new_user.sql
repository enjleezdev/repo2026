-- This function handles new user creation.
-- It checks if a user was invited (has app_metadata) and assigns them to an existing organization.
-- If the user was not invited, it does nothing, preventing automatic organization creation for regular sign-ups.

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_organization_id uuid;
  user_role public.user_role;
  username_from_email text;
BEGIN
  -- Check for invitation data in the user's metadata.
  -- The inviting function (Edge Function) will set these values.
  user_organization_id := (new.raw_app_meta_data->>'organization_id')::uuid;
  user_role := (new.raw_app_meta_data->>'role')::public.user_role;

  -- If the user was invited (has an organization_id in metadata), create their profile.
  IF user_organization_id IS NOT NULL THEN
    
    -- Extract username from email as a default
    username_from_email := split_part(new.email, '@', 1);

    -- Insert the new user into the profiles table with the specified role and organization.
    INSERT INTO public.profiles (id, organization_id, role, username)
    VALUES (new.id, user_organization_id, user_role, username_from_email);

  END IF;
  
  -- If the user was not invited (no organization_id in metadata), the function does nothing.
  -- The app owner must manually run a script to create an organization for them.
  
  RETURN new;
END;
$$;

-- Drop the trigger if it exists to avoid errors, then recreate it.
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- This trigger calls the function after a new user is created in auth.users.
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();
