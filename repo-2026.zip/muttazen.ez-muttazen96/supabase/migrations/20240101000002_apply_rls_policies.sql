-- This file applies all the necessary Row Level Security (RLS) policies
-- to ensure that users can only access data they own.

-- 1. Enable RLS on the 'profiles' table and define policies
alter table public.profiles enable row level security;

create policy "Users can view their own profile." on public.profiles
  for select using (auth.uid() = id);

create policy "Users can update their own profile." on public.profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

-- 2. Enable RLS on the 'warehouses' table and define policies
alter table public.warehouses enable row level security;

create policy "Users can view warehouses in their own organization." on public.warehouses
  for select using (exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.org_id = warehouses.org_id
  ));

create policy "Users can insert warehouses into their own organization." on public.warehouses
  for insert with check (exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.org_id = warehouses.org_id
  ));

create policy "Users can update warehouses in their own organization." on public.warehouses
  for update using (exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.org_id = warehouses.org_id
  ));

create policy "Owners can delete warehouses in their organization." on public.warehouses
  for delete using (exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.org_id = warehouses.org_id and profiles.role = 'owner'
  ));

-- 3. Enable RLS on the 'items' table and define policies
alter table public.items enable row level security;

create policy "Users can view items in their own organization." on public.items
  for select using (exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.org_id = items.org_id
  ));

create policy "Users can insert items into their own organization." on public.items
  for insert with check (exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.org_id = items.org_id
  ));

create policy "Users can update items in their own organization." on public.items
  for update using (exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.org_id = items.org_id
  ));

create policy "Users can delete items in their own organization." on public.items
  for delete using (exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.org_id = items.org_id
  ));

-- 4. Enable RLS on the 'notifications' table and define policies
alter table public.notifications enable row level security;

create policy "Users can view their own notifications." on public.notifications
  for select using (auth.uid() = owner_id);

create policy "Users can interact with their own notifications." on public.notifications
  for all using (auth.uid() = owner_id);
