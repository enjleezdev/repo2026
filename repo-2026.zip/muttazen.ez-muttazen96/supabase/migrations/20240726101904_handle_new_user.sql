-- Function to create a new organization and a profile for the new user.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  new_org_id uuid;
begin
  -- Create a new organization for the user
  insert into public.organizations (owner_id, name)
  values (new.id, new.raw_user_meta_data->>'full_name' || '''s Organization')
  returning id into new_org_id;

  -- Create a profile for the new user, linking them to the new organization
  insert into public.profiles (id, organization_id, role, full_name, email)
  values (new.id, new_org_id, 'owner', new.raw_user_meta_data->>'full_name', new.email);
  return new;
end;
$$;

-- Trigger to call the function when a new user is created.
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
