-- This file contains the SQL commands to create the necessary tables
-- for the simplified application model.
-- You can run this in the SQL Editor of your new Supabase project.

-- First, drop the default trigger and table if they exist.
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TABLE IF EXISTS public.profiles;

-- Create warehouses table
CREATE TABLE public.warehouses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name text NOT NULL,
    description text,
    is_archived boolean DEFAULT false NOT NULL,
    owner_id uuid NOT NULL
);
ALTER TABLE public.warehouses OWNER TO postgres;
ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES auth.users(id);
    
-- Create items table
CREATE TABLE public.items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name text NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    location text,
    is_archived boolean DEFAULT false NOT NULL,
    history jsonb,
    warehouse_id uuid NOT NULL,
    owner_id uuid NOT NULL,
    low_stock_threshold integer
);
ALTER TABLE public.items OWNER TO postgres;
ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;
ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES auth.users(id);

-- Create profiles table with our required structure
CREATE TABLE public.profiles (
    id uuid NOT NULL,
    username text,
    email text,
    role text,
    username_changed boolean DEFAULT false NOT NULL
);
ALTER TABLE public.profiles OWNER TO postgres;
ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- Create notifications table
CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    title text NOT NULL,
    message text,
    is_read boolean DEFAULT false NOT NULL,
    owner_id uuid NOT NULL,
    type text,
    metadata jsonb
);
ALTER TABLE public.notifications OWNER TO postgres;
ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES auth.users(id);

-- Function to create a profile for a new user
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, username, role, username_changed)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', SPLIT_PART(NEW.email, '@', 1)),
    COALESCE((NEW.raw_user_meta_data->>'role')::text, 'owner'),
    FALSE
  );
  RETURN NEW;
END;
$$;

-- Trigger to call the function when a new user signs up
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();