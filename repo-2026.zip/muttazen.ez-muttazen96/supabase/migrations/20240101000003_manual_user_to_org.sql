-- This script is intended to be run MANUALLY from the Supabase SQL Editor.
-- Use this after you have created a new user in the Supabase Auth dashboard
-- that you want to be an "owner" of a new organization.

DO $$
DECLARE
    -- This will select all users from the auth table who do not yet have a profile.
    user_record RECORD;
BEGIN
    FOR user_record IN
        SELECT id, email FROM auth.users WHERE id NOT IN (SELECT id FROM public.profiles)
    LOOP
        -- This block will execute for each user found.
        DECLARE
            new_organization_id uuid;
            username_from_email text;
        BEGIN
            -- 1. Create a new organization for the user.
            -- The organization name defaults to the user's email.
            RAISE NOTICE 'Creating organization for user %', user_record.email;
            INSERT INTO public.organizations (name)
            VALUES (user_record.email)
            RETURNING id INTO new_organization_id;

            -- 2. Extract a username from their email to use as a default.
            username_from_email := split_part(user_record.email, '@', 1);

            -- 3. Create a profile for the user, setting their role as 'owner'.
            RAISE NOTICE 'Creating profile for user %', user_record.email;
            INSERT INTO public.profiles (id, organization_id, role, username)
            VALUES (user_record.id, new_organization_id, 'owner', username_from_email);
            
            -- 4. This step is crucial for users who might have created data before
            -- being assigned an organization. It assigns their existing data to their new organization.
            RAISE NOTICE 'Assigning existing data for user % to new organization %', user_record.id, new_organization_id;
            UPDATE public.warehouses SET organization_id = new_organization_id WHERE owner_id = user_record.id AND organization_id IS NULL;
            UPDATE public.items SET organization_id = new_organization_id WHERE owner_id = user_record.id AND organization_id IS NULL;
            UPDATE public.notifications SET organization_id = new_organization_id WHERE owner_id = user_record.id AND organization_id IS NULL;

        END;
    END LOOP;
    RAISE NOTICE 'Manual user-to-org script finished successfully.';
END $$;
