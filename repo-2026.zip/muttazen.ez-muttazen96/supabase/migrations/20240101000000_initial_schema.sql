-- Create the organizations table
-- Each user who signs up will be associated with an organization.
-- This allows for multi-tenancy where each user's data is isolated.
create table public.organizations (
  id uuid not null default gen_random_uuid() primary key,
  name text
);

-- Create the profiles table
-- This table stores user-specific data that is not part of the auth.users table.
-- It links users to their organization and defines their role within it.
create table public.profiles (
  id uuid not null primary key references auth.users(id) on delete cascade,
  org_id uuid not null references public.organizations(id) on delete cascade,
  role text not null default 'owner'::text,
  constraint role_check check (role in ('owner', 'manager', 'supervisor', 'worker'))
);

-- Create the warehouses table
-- This table will store information about each warehouse.
-- It is linked to an owner (a user profile) to ensure data isolation.
create table public.warehouses (
    id uuid not null default gen_random_uuid() primary key,
    name text not null,
    description text,
    is_archived boolean not null default false,
    created_at timestamp with time zone not null default now(),
    updated_at timestamp with time zone not null default now(),
    owner_id uuid not null references auth.users(id) on delete cascade
);

-- Create the items table
-- This table will store all inventory items.
-- Each item belongs to a warehouse and is owned by a user.
create table public.items (
    id uuid not null default gen_random_uuid() primary key,
    warehouse_id uuid not null references public.warehouses(id) on delete cascade,
    name text not null,
    quantity integer not null default 0,
    location text,
    history jsonb[] not null default '{}'::jsonb[],
    is_archived boolean not null default false,
    created_at timestamp with time zone not null default now(),
    updated_at timestamp with time zone not null default now(),
    owner_id uuid not null references auth.users(id) on delete cascade,
    low_stock_threshold integer
);

-- Create the notifications table
-- This table will store notifications for users, such as low stock alerts.
create table public.notifications (
    id uuid not null default gen_random_uuid() primary key,
    owner_id uuid not null references auth.users(id) on delete cascade,
    type text not null,
    title text not null,
    message text not null,
    is_read boolean not null default false,
    created_at timestamp with time zone not null default now(),
    metadata jsonb
);

-- Note: Row Level Security (RLS) policies and database functions/triggers
-- will be added in subsequent migration files to keep concerns separated.
