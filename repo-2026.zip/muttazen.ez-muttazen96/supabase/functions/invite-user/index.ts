// This file is intentionally left empty to disable the cloud function.
// You can re-implement the logic here in the future if needed.
// For now, user creation will be handled by the default Supabase auth signup.
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';

serve(async (req: Request) => {
  return new Response(
    JSON.stringify({ error: 'This feature is currently disabled.' }),
    { status: 404, headers: { 'Content-Type': 'application/json' } }
  );
});
