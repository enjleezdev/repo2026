// This file is intentionally kept simple. The `next-pwa` package will automatically generate a more robust service worker.
// This file can be used for custom service worker logic in the future if needed.

self.addEventListener('fetch', (event) => {
  // Basic fetch handler, can be extended.
});
