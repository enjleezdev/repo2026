-- DATABASE MIGRATION (Safe to re-run)

-- Create the suppliers table only if it doesn't exist
CREATE TABLE IF NOT EXISTS public.suppliers (
  id uuid DEFAULT gen_random_uuid() NOT NULL,
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  owner_id uuid NOT NULL,
  name text NOT NULL,
  contact_person text,
  phone text NOT NULL,
  email text,
  address text,
  notes text,
  is_archived boolean DEFAULT false NOT NULL,
  updated_at timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT suppliers_pkey PRIMARY KEY (id),
  CONSTRAINT suppliers_email_key UNIQUE (email),
  CONSTRAINT suppliers_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Enable Row Level Security for the new table
ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;

-- RLS Policies for suppliers
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policy WHERE polname = 'Allow authenticated users to read all suppliers' AND polrelid = 'public.suppliers'::regclass) THEN
    CREATE POLICY "Allow authenticated users to read all suppliers" ON public.suppliers
    FOR SELECT TO authenticated USING (true);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_policy WHERE polname = 'Allow authenticated users to insert their own suppliers' AND polrelid = 'public.suppliers'::regclass) THEN
    CREATE POLICY "Allow authenticated users to insert their own suppliers" ON public.suppliers
    FOR INSERT TO authenticated WITH CHECK (auth.uid() = owner_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_policy WHERE polname = 'Allow users to update their own suppliers' AND polrelid = 'public.suppliers'::regclass) THEN
    CREATE POLICY "Allow users to update their own suppliers" ON public.suppliers
    FOR UPDATE TO authenticated USING (auth.uid() = owner_id) WITH CHECK (auth.uid() = owner_id);
  END IF;
END;
$$;

-- Add a function to set the updated_at timestamp automatically
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to call the function before any update on suppliers
DROP TRIGGER IF EXISTS handle_suppliers_updated_at ON public.suppliers;
CREATE TRIGGER handle_suppliers_updated_at
BEFORE UPDATE ON public.suppliers
FOR EACH ROW
EXECUTE FUNCTION public.set_updated_at();

-- Add new columns to the inventory_operations table to link suppliers
ALTER TABLE public.inventory_operations
ADD COLUMN IF NOT EXISTS supplier_id uuid,
ADD COLUMN IF NOT EXISTS supplier_name text;

-- Add a foreign key constraint to link to the suppliers table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'inventory_operations_supplier_id_fkey' AND conrelid = 'public.inventory_operations'::regclass
  ) THEN
    ALTER TABLE public.inventory_operations
    ADD CONSTRAINT inventory_operations_supplier_id_fkey FOREIGN KEY (supplier_id)
    REFERENCES public.suppliers(id) ON DELETE SET NULL;
  END IF;
END;
$$;
